CONDUCTOR-GAP RESEARCH SUMMARY
As of 15 October 2026

Open Conductor_Gap_Research_Summary.pdf (6 pages).
Proposed next steps are on page 5. Exact current curves are on page 3.

Rebuild the report: python build_summary.py
Dependencies: Python, ReportLab, Matplotlib, NumPy, and DejaVu fonts.

The evidence directory contains small source snapshots, summaries, pilot records and certificates. evidence-manifest.json gives original workspace paths and SHA-256 digests. E20-E25 add reference/source arithmetic and public pilot inputs.

This is a report/evidence bundle, not a complete benchmark or million-curve dataset export. Full raw datasets and executable benchmark dependencies remain at the original workspace paths. Rebuildable report source uses the included snapshots only.

Status: the 100-pair rho, prefix MITM2 and prefix MITM3 campaigns completed. The orbit-folded pilot completed and independently verified both endpoints. The full 100-pair orbit-folded campaign is prepared but has not run.
