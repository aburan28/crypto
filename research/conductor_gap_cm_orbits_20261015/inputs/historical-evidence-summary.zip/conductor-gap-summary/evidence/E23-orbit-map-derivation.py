import pathlib,json,sys,csv
from sympy import sqrt_mod
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent))
from prepare_workloads import add,mul
def derive(v):
 p,n,ell,t=v['p'],v['N'],v['ell'],v['t'];a,b=v['a0'],v['b0'];M=p+1+t
 def root(x):
  if p%4==3:
   y=pow(x,(p+1)//4,p);return y if y*y%p==x%p else None
  return sqrt_mod(x,p)
 if 'twist_a' in v:at,bt,scale=v['twist_a'],v['twist_b'],v['twist_d']
 else:
  d=next(d for d in range(2,100) if pow(d,(p-1)//2,p)==p-1);at=a*d*d%p;bt=b*d*d*d%p;scale=pow(d,-1,p)
 assert M%5==0
 for x in range(1000):
  y=root((x**3+at*x+bt)%p)
  if y is None:continue
  K=mul(M//5,(x,int(y)),at,p)
  if K is not None:break
 assert K is not None and mul(5,K,at,p) is None
 K2=mul(2,K,at,p);xs=[scale*P[0]%p for P in [K,K2]];ts=[(3*x*x+a)%p for x in xs];ys2=[(x**3+a*x+b)%p for x in xs]
 A=(a-10*sum(ts))%p;B=(b-14*sum((5*x**3+3*a*x+2*b)%p for x in xs))%p
 c=B*a*pow(A*b,-1,p)%p;u=int(root(c));assert u*u%p==c and a*c*c%p==A and b*c*c*c%p==B
 inv_c=pow(c,-1,p);inv_cu=pow(c*u,-1,p)
 def phi(P):
  if P is None:return None
  x,y=P;out=x;derivative=1
  for k,T,Y2 in zip(xs,ts,ys2):
   d=pow((x-k)%p,-1,p);out=(out+2*T*d+4*Y2*d*d)%p;derivative=(derivative-2*T*d*d-8*Y2*d*d*d)%p
  return out*inv_c%p,y*derivative*inv_cu%p
 G=tuple(v['G0']);lam0=(1+(2-t)*pow(ell,-1,n))*pow(2,-1,n)%n
 choices=[lam0,(-lam0)%n,(1-lam0)%n,(lam0-1)%n];matches=[L for L in choices if mul(L,G,a,p)==phi(G)];assert len(matches)==1;L=matches[0]
 for k in [1,2,3,7,19,12345]:
  P=mul(k,G,a,p);Q=phi(P);assert (Q[1]**2-Q[0]**3-a*Q[0]-b)%p==0 and Q==mul(L,P,a,p)
 trace=1 if (L*L-L+5)%n==0 else -1;assert (L*L-trace*L+5)%n==0
 return {'pair':v['index'],'p':p,'r':n,'ell':ell,'t':t,'a':a,'b':b,'twist_a':at,'twist_b':bt,'twist_order':M,'twist_kernel':K,'twist_kernel_order':5,'kernel_xs_on_original':xs,'kernel_t':ts,'kernel_rhs':ys2,'codomain_a':A,'codomain_b':B,'isomorphism_c':c,'isomorphism_u':u,'inverse_c':inv_c,'inverse_cu':inv_cu,'lambda':L,'trace':trace,'degree':5,'public_generator_checks':'PASS'}
def params(v):return ' '.join(map(str,[v['p'],v['r'],v['pair'],v['lambda'],v['inverse_c'],v['inverse_cu']]+v['kernel_xs_on_original']+v['kernel_t']+v['kernel_rhs']))+'\n'
if __name__=='__main__':
 small={'index':1000000,'p':343073,'N':342833,'ell':263,'t':241,'a0':36086,'b0':72172,'G0':[0,2882],'a1':43182,'b1':57354,'G1':[2,20047]}
 s=derive(small);(R/'control').mkdir(exist_ok=True)
 for d in ['factor-bases','relations']:(R/'control'/d).mkdir(exist_ok=True)
 (R/'control/cm5.json').write_text(json.dumps(s,indent=2)+'\n');(R/'control/params.txt').write_text(params(s))
 rows=[];audit=[]
 for role in [0,1]:
  a,b=small['a'+str(role)],small['b'+str(role)];G=small['G'+str(role)];Q=mul(12345,tuple(G),a,small['p']);rows.append([role,small['index'],role,small['p'],small['N'],a,b,*G,*Q,1234567890123456,0]);audit.append({'job':role,'scalar':12345})
 with (R/'control/workloads.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['job','pair','role','p','r','a','b','Gx','Gy','Qx','Qy','seed','repeat']);w.writerows(rows)
 (R/'control/audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 big=next(v for v in json.loads((R.parent/'pairs.json').read_text()) if v['index']==46);v=derive(big);(R/'cm5.json').write_text(json.dumps(v,indent=2)+'\n');(R/'cm_params.txt').write_text(params(v))
 print('Verified degree-5 maps on both small control and 53-bit crater')
