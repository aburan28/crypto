# Larger prime conductor gaps, up to 96-bit fields — 2026-10-12

## Request and outcome

User objective: determine whether much larger prime conductor gaps have varied ECDLP hardness.
The original ceiling was under 83 field bits; the user explicitly raised it to 96 bits.
No prime-gap size or benchmark count was stipulated. This run searches a larger parameter
ladder and constructs an explicit pair at ell=33554509, rather than equating an order stratum
with a usable curve. Hardness comparisons remain unrun, not implicitly satisfied by construction.

**Verified new pair:** ell=33554509 in a 53-bit field, a conductor ratio
255.944 times larger than the prior 131101 pair. Both endpoints are explicit and independently checked.
**Larger proved parameters:** up to ell=129149576694539 (log2=46.876036) in a
96-bit field. Its crater is explicit; its floor curve has not been constructed.

## Complete search ladder

| Prime gap ell | Field bits | log2 gap | Floor status |
|---:|---:|---:|---|
| 33554509 | 53 | 25.000 | verified explicit model |
| 1073742259 | 63 | 30.000 | order stratum only; curve model not constructed |
| 34359738641 | 73 | 35.000 | order stratum only; curve model not constructed |
| 1099511627791 | 83 | 40.000 | order stratum only; curve model not constructed |
| 17592186044611 | 91 | 44.000 | order stratum only; curve model not constructed |
| 70368744179179 | 95 | 46.000 | order stratum only; curve model not constructed |
| 129149576694539 | 96 | 46.876 | order stratum only; curve model not constructed |

Each row uses D_K=-19, h(-19)=1, p=(t²+19 ell²)/4, prime p, prime N=p+1−t,
and prime opposite-twist order N_t=p+1+t. PARI `isprime` rigorously proved all four
primalities per row (including ell). `t²−4p=-19 ell²` is exact. All source crater models
have j=-884736 modulo p; their nonzero prime-order point certificate proves #E=N by
Hasse uniqueness. The conductor of End at the crater is 1. Every other curve with
that trace has conductor ell because f_pi=ell is prime and h(-19)=1.
The maximal-endomorphism order alone does not establish faster ECDLP.

![Prime gap ladder and the explicit pair](large-gaps.svg)

## New explicit 53-bit pair

p=5348049109955291, t=5425, prime group order N=5348049109949867, cofactor 1.
Equation on each endpoint: y²=x³+a x+b modulo p.

| Role | a | b | j | ICV1 slug |
|---|---:|---:|---:|---|
| crater | 5338637670593243 | 72571855647584 | 5348049109070555 | icv1-fp53-t5425-2d53f848 |
| floor | 3804860669494204 | 4416289275713699 | 1975510593253698 | icv1-fp53-t5425-8907fc8e |

Full canonical identities, generator coordinates, model SHA-256 hashes, discriminants and
run evidence are in `verified-large-gap-pair.json`. Generators were independently selected;
they are not claimed to be transported through a map. No EC1 registration or final IC
candidate is assigned. The ICV1 path records the derived prime degree/direction only.

## Construction and verification

`search_floor.cpp`, with specialized projective arithmetic in `group.hpp`, samples a,x,y
and defines b=y²−x³−a x so that (x,y) is rational. It rejects singular curves, tests [N]P,
and also tests the opposite trace via [N]P+[2t]P=O. Both orders are prime. A hit of opposite
trace is quadratically twisted to the chosen trace, and a new generator is certified.
The source CRT-like point sampling is not a uniform model sampler; that affects search
yield, not the exact point-order certificate. The prime gap and floor identity are
checked after a hit, and j equal to the unique crater is rejected.

The four-thread search found one floor after **28,004,300 candidates**
in **49.2166 process wall seconds**. This is a single construction run,
not a throughput estimate with uncertainty, a speedup, or an ECDLP benchmark. The successful
thread, seed, local attempt number and pre-candidate RNG state are preserved in the raw JSON.
The run had a 1200-second limit and completed before it. All candidates and group tests
are included in that search interval; compilation, parameter selection and independent
PARI verification are excluded and kept separate. No amortized construction claim is made.

Independent PARI/GP 2.15.2 rechecked the new floor's exact point count (`ellcard`),
j-invariant, generator equation and [N]G=O, primalities, and discriminant. All passed.
It verified all ladder crater certificates as well. This is independent arithmetic from
the C++ producer. No Sage was invoked. Source/executable hashes and commands are retained.

## The near-limit 96-bit target

ell=129149576694539, p=79228162511798403263235114731, prime N=79228162511798403263235112627.
This is approximately 2^46.876 in conductor ratio.
For this particular D_K=-19 family, ell²=(4p−t²)/19 implies
ell < sqrt(4*2^96/19), whose log2 is 46.876036. This target is near that family bound;
it is not claimed to maximize all CM families or all allowed traces.

The order of conductor ell exists in the ordinary isogeny class, but its explicit
curve, kernel and point map were **not constructed**. Straight model sampling has
heuristic expected search work on the order of p/(ell−(-19/ell)), about 19 ell/4
when t is small. This is a derived density estimate, not a measured time bound or a
proof that another construction cannot work. No larger floor search was launched.
Avoid calling these higher rows benchmark-ready pairs.

## Hardness experiment still owed

The new explicit pair is ready for a frozen matched IC/rho experiment. Preserve the
actual usable base size, quotient columns, backend, arity, symmetry policy, resource
envelope, fresh public target distribution, and isomorphic-model controls. Charge all
relation/rank and LA work; separate setup and online clocks and report complete cold costs.
Report per-method measured differences, not intrinsic/asymptotic hardness. An explicit
prime-degree isogeny is unnecessary to compare target distributions, but required before
claiming point transport or effective DLP equivalence by an executable route.
No new IC or rho solve has been performed in this run. The earlier 263/8209 results
remain finite negative controls, not evidence about these much larger gaps.

## Requirement status and canonical graph review

| Requirement | Status | Evidence or remaining obligation |
|---|---|---|
| Find much larger prime conductor gaps under the raised 96-bit ceiling | verified complete within this recorded CM ladder | all prime proofs and discriminant certificates |
| Provide an explicit pair beyond ell=131101 | verified complete at ell=33554509 | independent point count and subgroup certificate |
| Provide far-side curves at the largest 96-bit gaps | not constructed | need a concrete j/model with a prime-order certificate and non-crater j |
| Construct an explicit prime-degree map | not attempted | kernel, map and subgroup-preservation checks remain absent |
| Determine changed ECDLP/IC hardness | not run | matched complete solves and held-out/model controls still owed |

The existing CM pair study, IC curve catalog, and conductor-gap graph records were reviewed.
The earlier 2^20 volcano is unaffected. A new local pair/order-stratum diagram is provided;
no verified map edge is added. No remote registry, graph, paper or PR was modified.
Existing graph files remain current because their recorded instances/routes are unchanged.

Sources: [CM pair construction and prior results](https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/README.md),
[original constructor](https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/gap_pairs.rs),
[ICV1 specification](https://github.com/aburan28/crypto/blob/main/docs/curves/ICV1.md).
