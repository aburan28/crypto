import pathlib,json,csv,sys,time
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent))
from prepare_workloads import add,mul
def main(control=False):
 folder=R/'control' if control else R;start=time.process_time()
 work={int(w['job']):{k:int(v) for k,v in w.items()} for w in csv.DictReader((folder/'workloads.csv').open())}
 results=list(map(json.loads,(folder/'results.jsonl').read_text().splitlines()));assert len(results)==len(work)==2
 if control:audit={v['job']:v['scalar'] for v in json.loads((folder/'audit.json').read_text())}
 else:
  audit0={(v['pair'],v['role']):v['scalar'] for v in json.loads((R.parent/'workloads-audit.json').read_text())};audit={j:audit0[(w['pair'],w['role'])] for j,w in work.items()}
 relation_count=0;orbit_points=0;negative=None
 for result in results:
  w=work[result['job']];p,a,b,n=w['p'],w['a'],w['b'],w['r'];C=result['columns']
  base=[{k:int(v) for k,v in row.items()} for row in csv.DictReader((folder/'factor-bases'/f"job-{w['job']}.csv").open())];assert len(base)==result['B']
  seeds={v['column']:(v['x'],v['y']) for v in base if v['coefficient']==1}
  assert len(seeds)==C
  for v in base:
   assert (v['y']**2-v['x']**3-a*v['x']-b)%p==0 and v['y']==min(v['y'],p-v['y'])
   assert mul(v['coefficient'],seeds[v['column']],a,p)==(v['x'],v['y']);orbit_points+=1
  rows=list(map(json.loads,(folder/'relations'/f"job-{w['job']}.jsonl").read_text().splitlines()));pivots={};seen=set()
  for v in rows:
   i,j=base[v['i']],base[v['j']];P=(i['x'],v['si']*i['y']%p);S=(j['x'],v['sj']*j['y']%p)
   assert add(P,S,a,p)==(v['Rx'],v['Ry'])
   assert add(mul(v['alpha'],(w['Gx'],w['Gy']),a,p),(w['Qx'],w['Qy']),a,p)==(v['Rx'],v['Ry'])
   if negative is None:
    assert add((P[0],-P[1]%p),S,a,p)!=(v['Rx'],v['Ry']);negative='REJECTED'
   part={}
   for B,sign in [(i,v['si']),(j,v['sj'])]:part[B['column']]=(part.get(B['column'],0)+sign*B['coefficient'])%n
   part={k:c for k,c in part.items() if c};inverse=pow(part[min(part)],-1,n);signature=tuple((k,c*inverse%n) for k,c in sorted(part.items()));assert signature not in seen;seen.add(signature)
   row=dict(part);row[C]=n-1;row[C+1]=-v['alpha']%n;independent=False
   for k in range(C+1):
    if not row.get(k):continue
    if k not in pivots:
     inv=pow(row[k],-1,n);pivots[k]={z:c*inv%n for z,c in row.items()};independent=True;break
    f=row[k]
    for z,c in pivots[k].items():
     row[z]=(row.get(z,0)-f*c)%n
     if not row[z]:del row[z]
   if not independent:assert not row.get(C+1)
   assert independent==v['independent'] and len(pivots)==v['rank'];relation_count+=1
  assert len(pivots)==result['rank'] and len(rows)==result['hits']-result['rejected_duplicate_columns']
  if result['status']=='PASS':
   d=result['recovered'];assert result['verified'] and d==audit[w['job']] and (-pivots[C].get(C+1,0))%n==d
   assert mul(d,(w['Gx'],w['Gy']),a,p)==(w['Qx'],w['Qy'])
  else:assert C not in pivots and not result['verified']
 summary={'jobs':len(results),'recoveries':sum(v['verified'] for v in results),'verified_orbit_points':orbit_points,'verified_relations':relation_count,'rank_checks':'PASS','mutated_relation':negative,'independent_replay_cpu_seconds':time.process_time()-start}
 (folder/'verification.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main('--control' in sys.argv)
