# Large prime conductor gaps and ECDLP hardness — 2026-10-12

**Outcome:** existing experiments provide no detectable conductor-gap effect for the
tested IC method at ell=263 and ell=8209. They do not settle intrinsic ECDLP hardness,
larger prime gaps, or algebraic PDP complexity. The next concrete pair is ell=131101.

## The current million-curve volcano is a different experiment

The earlier GF(68150031691554233) graph has f_pi=2^20. Its large conductor ratio
is smooth and consists of twenty inexpensive degree-2 steps, not a large prime
barrier. All generated models remain useful for layer/representation controls,
but they cannot directly test the user's prime-gap question. The degree-2 map
pilot was stopped at 1,000 source vertices; no complete gap-map claim was made.

## What was already measured

| Prime gap ell | Field / group size | Existing IC result | Interpretation |
|---:|---:|---|---|
| 263 | 19 bits | floor/crater 0.998, source 95% interval [0.970,1.026] | no detectable difference in 16-target follow-up |
| 8209 | 29 bits | floor/crater 0.958, source 95% interval [0.865,1.071] | no detectable difference in 16-target follow-up |
| 131101 | 37 bits | IC not reported; generic solver panel only | next IC comparison |

Sources: [pair study](https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/README.md), [full tables](https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/results/crater_vs_floor.md),
and [original protocol](https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/PROTOCOL.md). These are committed operation-count
stage diagnostics; no new IC or rho solve was run in this session. The first
four-target signals did not survive the sixteen-target follow-ups. Source intervals
are reported as written; they are not newly calibrated or a population-hardness proof.

The [later round-2 study](https://github.com/aburan28/crypto/blob/main/research/isogeny_conductor_gap_round2_20261011/README.md)
found a spurious crater/floor setup difference caused by subgroup-closure accounting.
After correction, cost at matched subgroup size was equal. Other differences were
explained by available fiber sizes or automorphisms, not an unexplained ring-index effect.
This is a reason to freeze those controls, not a theorem about all non-generic methods.

![Prime-gap structure and reported IC evidence](prime-gap-evidence.svg)

## Exact next pair, independently checked here

Both models have p=81640512137, trace=277, prime order r=81640511861 and cofactor 1.
The Frobenius discriminant is t^2-4p=-19*(131101)^2.

| Role | a | b | j | End conductor | ICV1 slug |
|---|---:|---:|---:|---:|---|
| crater | 6206588639 | 31351229805 | 81639627401 | 1 | icv1-fp37-t277-91fd6e29 |
| floor | 6064550680 | 68678790390 | 15573395165 | 131101 | icv1-fp37-t277-090dc414 |

Equation: y^2=x^3+a*x+b over GF(p). `verified-pairs.json` supplies their full ICV1
strings, canonical model hashes and deterministic prime-order generators, together
with all eleven previously constructed models across the three gap sizes.
In this session PARI/GP 2.15.2 recomputed every point count and j-invariant,
and verified a nonzero point annihilated by the prime group order for every model.
Primality and discriminant equations were checked independently in Python/SymPy.
The conductor certificate follows h(-19)=1 and prime f_pi=ell: the unique maximal-order
j is -884736; every other j in the trace class has conductor ell. All checks passed.
The ICV1 path records the derived prime step; explicit maps and kernels remain absent.

## Proposed comparison (not run)

`PROTOCOL.json` freezes the proposed question, population and measurements. Start with
the 37-bit pair above and add three independently selected floor curves plus two
isomorphic-model controls. Freeze 64 new public targets per curve; the known scalars
are validation-only sidecars. Match actual usable factor-base points, quotient columns,
arity, solver backend, source/binary hashes, trial budgets and hardware resources.
Compare IC with same-point negation-aware rho within each curve; then compare normalized
crater/floor costs. Without a map, this matches workload distributions, not transported points.

Primary cost is a complete cold one-target solve, including preparation, failed searches,
independent rank collection, matrix construction and solution, target recovery and scalar
replay. Also retain online and setup costs separately, verified relation yield, seconds per
new independent relation, rank, PDP cost, failures and memory. A changed factor-base count,
coordinate representation, torsion fiber or exploited symmetry must be controlled explicitly.
Use held-out floor/model controls and replication at a second prime gap before attributing
a residual effect to conductor strata. Retain censoring and avoid a hardness conclusion
from a solver failure or a single favorable model.

The current MITM oracle tests one implementation's IC cost; it does not settle algebraic
solving hardness. A separate prime-field Semaev/PDP arm requires an implemented and
cross-checked algebraic backend before activation. No such execution is claimed here.
Results can establish measured-method differences, not prove absolute or asymptotic hardness.

## Larger prime-gap leads under 83 field bits

The existing Koblitz scan has 11 (degree,prime-factor) hits with m<83 and a
prime factor of at least 20 bits. `koblitz-under83-prime-gaps.json` records them all.
All 119 source recurrences and complete prime factorizations were rechecked here.
The largest under-83 hits are m=71, ell=31797598073 and m=73, ell=23369856751.
Their far-side curves and explicit maps are not supplied by the scan. They are
destination-order leads, not usable hardness pairs. The theoretical large-prime case
remains open; see [JMV review](https://github.com/aburan28/crypto/blob/main/research/jmv_self_reducibility_20261008/README.md).

## Graph review and remaining work

Existing curve catalog, degree-263 routes, CM-pair records, tall-volcano summary and
round-2 evidence were reviewed. No new isogeny edge or route was constructed here,
so canonical graphs are unchanged. The diagram depicts order strata with an unconstructed
map, not a certified point transport. No remote registry or paper was modified.
Remaining work: additional exact floor controls, frozen candidate/factor-base manifests,
the 37-bit IC run, and independent replication. Sources, arithmetic verification and
the proposed protocol are retained beside this report.
