from pathlib import Path
import json,math,os,html,hashlib
os.environ.setdefault('MPLCONFIGDIR','/tmp/conductor-summary-mpl')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/conductor-summary-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4

R=Path(__file__).resolve().parent
E=R/'evidence';F=R/'figures'
def read(name):return json.loads((E/name).read_text())
rho=read('E05-rho-summary.json');m2=read('E06-mitm2-summary.json');m3=read('E07-mitm3-summary.json')
pilot=list(map(json.loads,(E/'E08-orbit-pilot-results.jsonl').read_text().splitlines()))
cr=next(v for v in pilot if v['role']==0);fl=next(v for v in pilot if v['role']==1)
pair=next(v for v in read('E12-pairs.json') if v['index']==46);cm=read('E11-cm5-map.json')
findings=json.loads((R/'derived-findings.json').read_text())
graph=read('E01-volcano-graph-verification.json');models=read('E02-volcano-model-manifest.json')
assert graph['vertices']==models['models']==1048576
assert rho['primary_verified_solves']==200 and m3['primary']['recoveries']==0
assert sum(v['recoveries'] for v in m2['primary_endpoints'])==0
assert all(v['verified'] and v['status']=='PASS' for v in pilot)
assert (cm['lambda']**2+cm['lambda']+5)%pair['N']==0

# Standalone figures; exact counts are loaded from the verified snapshots.
teal='#167b9c';orange='#d26b32';navy='#18324b';grey='#a9b2bc'
fig,axs=plt.subplots(1,2,figsize=(10,3.35),gridspec_kw={'width_ratios':[1.05,1]},layout='constrained')
counts=graph['level_counts'];levels=np.arange(21)
axs[0].barh(levels,counts,color=teal,height=.75);axs[0].invert_yaxis();axs[0].set_xscale('log',base=2)
axs[0].set(yticks=[0,5,10,15,20],ylabel='Volcano level',xlabel='Exact vertex count (log scale)',title='Smooth conductor: twenty degree-2 steps')
axs[0].set_xticks([1,32,1024,32768,524288],['1','32','1,024','32,768','524,288'])
axs[0].tick_params(axis='x',labelsize=8);axs[0].annotate('524,288 floor models',xy=(524288,20),xytext=(260,16),arrowprops={'arrowstyle':'->','color':navy},fontsize=9,bbox={'facecolor':'white','alpha':.9,'edgecolor':'none','pad':2})
axs[1].set(xlim=(0,1),ylim=(0,1));axs[1].axis('off')
for x,y,label,color in [(.5,.81,'Crater: conductor 1',teal),(.5,.25,'Floor: conductor ℓ',orange)]:
 axs[1].scatter([x],[y],s=1100,c=color);axs[1].text(x,y+.12,label,ha='center',fontsize=11,color=navy)
axs[1].annotate('',xy=(.5,.34),xytext=(.5,.72),arrowprops={'arrowstyle':'->','lw':2,'color':navy})
axs[1].text(.55,.53,'One prime-degree step\nℓ ≈ 33.6–35.3 million',va='center',fontsize=10,color=navy)
axs[1].text(.5,.04,'100 verified pairs; one floor per gap\nFull prime-degree volcanoes were not enumerated.',ha='center',fontsize=9)
axs[1].set_title('Large prime conductor: a different structure')
fig.savefig(F/'search-structures.png',dpi=190);fig.savefig(F/'search-structures.svg');plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(10,3.1),layout='constrained')
for i,(v,col) in enumerate([(cr,teal),(fl,orange)]):
 axs[0].bar(i,v['setup_cpu_seconds'],color=grey,label='Setup, including orbit' if i==0 else None)
 axs[0].bar(i,v['collection_cpu_seconds'],bottom=v['setup_cpu_seconds'],color=col,label='Collection + matrix + recovery' if i==0 else None)
 axs[0].text(i,v['cpu_seconds']+.7,f"{v['cpu_seconds']:.2f}s",ha='center',fontsize=10)
 axs[1].bar(i,1000*v['orbit_cpu_seconds'],color=col)
 axs[1].text(i,1000*v['orbit_cpu_seconds']+.7,f"{1000*v['orbit_cpu_seconds']:.2f} ms",ha='center',fontsize=10)
for ax in axs:ax.set_xticks([0,1],['Crater','Floor'])
axs[0].set(ylabel='Thread CPU seconds',ylim=(0,61),title='Completed solves: one target per endpoint');axs[0].legend(fontsize=8,loc='upper left')
axs[1].set(ylabel='Thread CPU milliseconds',ylim=(0,47),title='Orbit construction alone: 8,192 points')
fig.savefig(F/'pilot-costs.png',dpi=190);fig.savefig(F/'pilot-costs.svg');plt.close(fig)

font=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('DV','DejaVuSans.ttf'),('DV-Bold','DejaVuSans-Bold.ttf'),('DV-Italic','DejaVuSans-Oblique.ttf'),('DVM','DejaVuSansMono.ttf')]:pdfmetrics.registerFont(TTFont(name,str(font/file)))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-Bold',italic='DV-Italic',boldItalic='DV-Bold')
S={
 'title':ParagraphStyle('title',fontName='DV-Bold',fontSize=25,leading=30,textColor=colors.HexColor(navy),spaceAfter=13),
 'chapter':ParagraphStyle('chapter',fontName='DV-Bold',fontSize=17,leading=22,textColor=colors.HexColor(navy),spaceAfter=13),
 'h':ParagraphStyle('h',fontName='DV-Bold',fontSize=11,leading=15,textColor=colors.HexColor(teal),spaceBefore=10,spaceAfter=5),
 'body':ParagraphStyle('body',fontName='DV',fontSize=9.3,leading=13.7,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='DV',fontSize=8.0,leading=11.5,spaceAfter=6,textColor=colors.HexColor('#465362')),
 'table':ParagraphStyle('table',fontName='DV',fontSize=8.1,leading=11.2),
 'thead':ParagraphStyle('thead',fontName='DV-Bold',fontSize=8.1,leading=11.2,textColor=colors.white),
 'code':ParagraphStyle('code',fontName='DVM',fontSize=8.0,leading=12,spaceAfter=6,wordWrap='CJK'),
 'callout':ParagraphStyle('callout',fontName='DV-Bold',fontSize=11.2,leading=16,textColor=colors.HexColor(navy),spaceAfter=9),
}
story=[]
def p(text,style='body'):return Paragraph(text,S[style])
def add(text,style='body'):story.append(p(text,style))
def head(text):add(text,'h')
def table(rows,widths):
 data=[[p(str(c),'thead' if i==0 else 'table') for c in row] for i,row in enumerate(rows)]
 t=Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(navy)),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f0f4f7'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#cad4df'))]));story.append(t);story.append(Spacer(1,8))
def page(title):story.append(PageBreak());add(title,'chapter')

add('Conductor gaps:<br/>what we searched and found','title')
add('Elliptic-curve volcanoes • crater versus floor • evidence through 15 October 2026','small')
add('The strongest current lead is a cheap degree-5 CM endomorphism on the crater. It made orbit construction faster in one verified pilot; an ECDLP hardness difference has not been established.','callout')
add('The original search began below 83 field bits and was extended to a 96-bit ceiling. Completed paired benchmarks use 53-bit fields. The question is whether conductor strata have distinct structure or measurable computational behavior, rather than assuming a large conductor ratio makes one endpoint harder.')
head('Completed measurements at a glance')
table([
 ['Experiment','Scope','Recovered','Observed crater / floor result'],
 ['Pollard rho','100 pairs','200 / 200','Mean CPU: 4.4604s / 4.5140s. Floor/crater ratio 1.012; paired 95% interval [0.897, 1.141]. [E05]'],
 ['Prefix MITM2 IC','100 pairs','0 / 200','55 / 57 primary relations. All attempts reached 100 million queries; no completed IC solve times. [E06]'],
 ['Prefix MITM3 IC','100 pairs','0 / 200','37 / 38 relations. 15 CPU seconds per endpoint, including setup; ranks at most 3 of 8,193. [E07]'],
 ['Orbit-folded MITM','Pair 46 pilot','2 / 2','Completed CPU: 21.983s / 51.698s. Orbit-only CPU: 5.18ms / 39.52ms. One target per endpoint. [E08–E11]'],
],[102,67,65,277])
head('What is established')
add('• A separate depth-20 degree-2 volcano was completely enumerated, including 1,048,576 explicit models and every intermediate stratum.<br/>• One hundred distinct large-prime conductor gaps have explicit, independently certified endpoints.<br/>• The tested generic rho solver showed no clear mean crater/floor timing difference.<br/>• The orbit-folded pilot solved both endpoints, and its factor-base arithmetic and target recoveries passed independent replay.')
head('What remains open')
add('The full 100-pair orbit-folded solve campaign is <b>prepared but not run</b>. The 96-bit near-limit candidate has no constructed floor. Neither prefix-IC failure nor the single folded pilot settles intrinsic ECDLP hardness, algebraic IC complexity, or behavior across all curve families.')
add('This PDF summarizes existing evidence and proposes experiments. It does not count proposed, prepared or censored work as completed solves. Evidence IDs map to the snapshots and hashes in the accompanying evidence manifest.','small')

page('1. Search path and verified volcanoes')
add('For an ordinary curve, write the Frobenius discriminant as t² − 4p = D<sub>K</sub> f<sub>π</sub>². Endomorphism-order conductors divide f<sub>π</sub>. Here “conductor gap” means the ratio of endpoint conductors; it differs from volcano depth and from isogeny-evaluation cost.')
story.append(Image(str(F/'search-structures.png'),width=511,height=171))
head('The tall, smooth volcano: completely exported')
add(graph['root_icv1'],'code')
add('Field p = 68150031691554233, trace t = 522103850, D<sub>K</sub> = −7 and f<sub>π</sub> = 2²⁰. The complete rational degree-2 component has 21 levels, 1,048,576 vertices, 1,048,575 vertical edges and 524,288 floor vertices. Every j vertex has an explicit chosen-trace model and verified prime-order subgroup generator; all intermediate strata are present. Modular-polynomial edges and all serialized model identities were checked. [E01–E02]')
add('This is a smooth conductor ratio traversed by twenty small-degree steps. It is a different experiment from a single large prime barrier. Complete explicit point maps and generator transport were not certified for all million-curve edges. Short display slugs have 121 collisions; use full ICV1 identities, full hashes or vertex IDs.','small')
add('The separate 100-pair benchmark family uses p = 5ℓ² − ℓ + 1, t = ℓ − 2 and prime N = 5ℓ² − 2ℓ + 4. Its 100 distinct prime gaps span <b>33,555,419–35,282,963</b>, with D<sub>K</sub> = −19 and endpoint conductors 1 and ℓ. Both endpoint orders and the large-kernel witnesses were independently certified. [E12–E13]','small')
head('Larger prime gaps and the 96-bit ladder')
table([
 ['Prime conductor ratio ℓ','Field bits','Far-side status'],
 ['33,554,509','53','One explicit verified pair (separate initial search).'],
 ['1,073,742,259','63','Order stratum; floor model not constructed.'],
 ['34,359,738,641','73','Order stratum; floor model not constructed.'],
 ['1,099,511,627,791','83','Order stratum; floor model not constructed.'],
 ['17,592,186,044,611','91','Order stratum; floor model not constructed.'],
 ['70,368,744,179,179','95','Order stratum; floor model not constructed.'],
 ['129,149,576,694,539','96','Crater explicit; floor model not constructed.'],
],[171,59,281])
add('The ladder uses D<sub>K</sub> = −19 with rigorous prime/discriminant certificates. It establishes candidate strata, not benchmark-ready pairs at its upper end. A reviewed binary/Koblitz scan yielded 11 leads under 83 bits; the largest prime factor was 31,797,598,073 at m = 71. Those far-side curves were not supplied. [E03–E04, E16–E17]','small')

page('2. The current curve and structural lead')
add('The successful folded pilot uses <b>pair 46</b> from the 100-pair dataset. Both curves have prime order and cofactor 1. Their endomorphism conductors are 1 and ℓ = 34,489,703. [E11–E13]')
table([
 ['Common parameter','Exact value'],
 ['Field p','5947698030651343'],
 ['Prime group order N = r','5947697996161643'],
 ['Trace t','34489701'],
 ['Fundamental discriminant / Frobenius conductor','D<sub>K</sub> = −19; f<sub>π</sub> = 34489703'],
],[190,321])
head('Exact models over GF(p)')
add('Crater: y² = x³ + 5757116383569871 x<br/>                 + 3560173328417442','code')
add('Floor:  y² = x³ + 2087370704375809 x<br/>                 + 1402887937802154','code')
head('A structural distinction with a concrete implementation')
add('The crater has a degree-5 self-isogeny α. A rational order-5 kernel on its quadratic twist supplies a Vélu map; an isomorphism returns the codomain to the same curve. Its action on the prime-order subgroup is multiplication by λ = 2973849084305078, with λ² + λ + 5 = 0 modulo r. Kernel order, curve equations, isomorphism and public-generator action were checked.')
add('The floor order is ℤ + ℓ O<sub>K</sub>. With ω = (1 + √−19)/2, a noninteger element has norm (a + bℓ/2)² + 19b²ℓ²/4, where b ≠ 0. This exceeds 5 at the present ℓ; integer norms are squares. Thus the floor has no degree-5 endomorphism. Ordinary scalar multiplication [λ] remains available on its prime-order group.')
head('How the folded relation solver uses the map')
table([
 ['Step','Construction or verification'],
 ['Four seeds','Choose four public seed points whose logs relative to G are unknown.'],
 ['2,048 orbit levels each','Crater: apply α. Floor control: apply [λ] by scalar multiplication. Track each point’s coefficient relative to its seed log.'],
 ['8,192 factor-base points','The point set has four seed-log unknowns, rather than 8,192 independent log columns.'],
 ['Pair sums and a matrix','Query R = Q + [a]G; decompose into signed base points; eliminate four seed logs plus target d. Five unknowns in total.'],
 ['Verified recovery','Reject scalar-proportional column parts. Accept d only after [d]G = Q and independent audit replay.'],
],[128,383])
add('This is an orbit-folded MITM relation solver. Its scalar-orbit floor control is executable with generic group arithmetic too. Successful recovery therefore does not by itself establish a crater-exclusive attack or a subgeneric IC complexity improvement.','small')

page('3. What the measurements do—and do not—show')
story.append(Image(str(F/'pilot-costs.png'),width=511,height=159))
table([
 ['Pair 46 pilot metric','Crater','Floor'],
 ['Orbit construction only',f"{1000*cr['orbit_cpu_seconds']:.3f} ms",f"{1000*fl['orbit_cpu_seconds']:.3f} ms"],
 ['Total native setup (includes orbit)',f"{cr['setup_cpu_seconds']:.3f} s",f"{fl['setup_cpu_seconds']:.3f} s"],
 ['Collection, elimination and recovery',f"{cr['collection_cpu_seconds']:.3f} s",f"{fl['collection_cpu_seconds']:.3f} s"],
 ['Complete native solve',f"{cr['cpu_seconds']:.3f} s",f"{fl['cpu_seconds']:.3f} s"],
 ['Queries / retained independent relations',f"{cr['queries']:,} / 5",f"{fl['queries']:,} / 5"],
 ['Collection CPU per query',f"{findings['pilot_collection_ns_per_query_crater']:.2f} ns",f"{findings['pilot_collection_ns_per_query_floor']:.2f} ns"],
],[263,124,124])
add(f"Orbit construction was <b>{findings['pilot_orbit_floor_over_crater']:.2f}× faster on the crater</b> in this single trial. The absolute saving was {1000*findings['pilot_orbit_saved_seconds']:.2f} ms. The complete floor solve took {findings['pilot_total_floor_over_crater']:.2f}× as much CPU, but used {findings['pilot_queries_floor_over_crater']:.2f}× as many queries. Similar per-query costs and the differing search counts prevent attributing that end-to-end gap to the conductor.")
head('Independent checks and timing boundary')
add('Both native recoveries passed independent Python scalar replay and held-out answer checks. All 16,384 pilot base points were checked on curve and against their claimed scalar multiples of the four seeds; all 10 retained relations and both rank-5 matrices were rechecked. The floor had six hits, one rejected as a proportional column part. Two small folded controls also solved; a corrupted relation was rejected. [E08–E11, E15]')
add('Native timings include orbit construction, pair-table setup, collection, elimination, witness logging and in-process target verification. Prior curve construction, CM-map derivation, compile/launch, input parsing and independent replay are outside those intervals. Independent pilot replay cost 3.230 CPU seconds across both endpoints. One worker ran the pilot; no qualifying host-isolation receipt is available.','small')
head('Other searches constrain the interpretation')
add('The two prefix-IC campaigns remained relation-starved; their censored times are not solve times. The MITM3 arm changed both factor-base size and arity, so its comparison does not isolate arity. No prime-field F4/SAT backend was run. Prior repository 16-target studies reported floor/crater IC ratios 0.998 [0.970, 1.026] at ℓ = 263 and 0.958 [0.865, 1.071] at ℓ = 8,209; these are prior source results, not new local measurements. [E04, E06–E07]','small')

page('4. Proposed next steps, in priority order')
head('A. Isolate the endomorphism advantage first')
add('<b>Run three orbit-generation arms on all 100 pairs:</b> crater with α, the same crater with [λ], and floor with [λ]. Use identical public seeds, orbit length, canonical signs and point count. Verify that the two crater arms produce identical point/coefficient records. Repeat each arm, randomize order, and report CPU per orbit step plus cold and warm costs. This directly separates a cheap-map advantage from coordinate and timing noise.')
head('B. Complete the 100-pair orbit-folded solve comparison')
add('The 100 CM maps have been derived and checked, and the multi-pair executable passed the small controls. <b>The 200-target primary campaign has not run.</b> Freeze its source/binary, inputs, four seed columns, 2,048 levels, proportional-row guard, method order and resource caps before launch. Charge full cold setup and record orbit, table, collection, rank, recovery and replay separately. Use the same public targets as rho initially.')
add(f"Planning estimate only: extrapolating the two pilot costs gives {findings['pilot_extrapolated_full200_cpu_hours']:.2f} CPU-hours for 100 pairs, or about {findings['pilot_extrapolated_full200_wall_minutes_four_cores']:.0f} minutes on four effective cores before replay and contention. This is not a measured runtime bound. Four 8,192-point pair tables require about 6 GiB plus auxiliary storage.",'small')
head('C. Replicate before interpreting any solve-time gap')
add('Start repeated fresh targets and query seeds on the pilot and a frozen subset, then expand across pairs. Include isomorphic-coordinate models, multiple floor vertices per gap and a second CM family. Compare relation yield per unit work, query counts, per-query CPU and complete solve CPU. Use paired or hierarchical bootstrap intervals that respect curve-level clustering. Preserve all failures and censored runs; do not compute a successful-only speed ratio.')
head('D. Separate structural effects from generic solver behavior')
add('Add the crater-[λ] control to the solver panel, alongside crater-α, floor-[λ] and rho. A reproducible α-versus-[λ] difference on the same crater identifies an implementation benefit of the endomorphism. A residual crater/floor solve difference needs replication after adjusting for query counts, models and setup. Any algebraic IC claim requires a separately implemented, cross-checked prime-field Semaev/PDP backend; MITM alone does not measure that complexity.')
head('E. Pursue larger prime gaps after constructing both endpoints')
add('Use the rational-torsion family and evaluate a fast large-degree isogeny method, such as square-root Vélu, against the known 53-bit pairs before attempting the 96-bit range. Certify every new floor model, point count and endomorphism conductor. An order discriminant or target stratum alone is insufficient for a paired benchmark. A second CM family would also test whether observed behavior is specific to D<sub>K</sub> = −19.')
add('Decision rule: first establish a repeated phase-specific structural effect; then ask whether it changes total verified ECDLP work. At present, a cheap crater map is concrete, while a general hardness gap remains unestablished.','callout')

page('5. Evidence, provenance and scope ledger')
add('The PDF is built from existing local receipts, immutable source snapshots and raw pilot records. The evidence bundle contains the JSON/CSV summaries, source reports, figure sources and a SHA-256 manifest. Large graph/model datasets remain in their original workspace locations; their recorded digests and exact counts are included.')
table([
 ['Evidence','What it supports'],
 ['E01–E02','Complete degree-2 graph, all 1,048,576 chosen-trace models, intermediate strata, subgroup and identity checks.'],
 ['E03, E16','Larger-gap ladder through 96 bits; prime proofs and the distinction between explicit endpoints and unconstructed floor strata.'],
 ['E04, E17','Reviewed prior CM-gap experiments and binary/Koblitz leads; prior study ratios are source-reported.'],
 ['E05','100-pair completed rho benchmark, 20 repeat controls, timing scope and paired confidence interval.'],
 ['E06','Prefix MITM2 settings, censored results, relation counts and independent replay summary.'],
 ['E07, E14, E19','Prefix MITM3 settings/results, independent rank/point checks and collision-free query-stream audit.'],
 ['E08–E11, E15','Raw folded pilot, independent replay, pre-run freeze, degree-5 map parameters and small controls.'],
 ['E12–E13','Exact models, prime conductor gaps, group generators, kernel witnesses and independent PARI certificates for 100 pairs.'],
 ['E18','100 derived CM maps. Preparation evidence only; it contains no full folded-campaign solve results.'],
],[97,414])
head('Repository sources reviewed')
links=[
 ('Original tall-volcano construction','https://github.com/aburan28/crypto/blob/main/research/volcano_descent_dataset_20261011/volcano_descent.py'),
 ('CM conductor-gap pair study','https://github.com/aburan28/crypto/blob/main/research/conductor_gap_cm_pairs_20261010/README.md'),
 ('Earlier subgroup-accounting / representation controls','https://github.com/aburan28/crypto/blob/main/research/isogeny_conductor_gap_round2_20261011/README.md'),
 ('Prime-field IC oracle and relation framework','https://github.com/aburan28/cryptanalysis/blob/main/src/cryptanalysis/ic_boundary.rs'),
 ('ICV1 identity specification','https://github.com/aburan28/crypto/blob/main/docs/curves/ICV1.md')]
for label,url in links:add('• <link href="'+html.escape(url,quote=True)+'" color="#167b9c">'+html.escape(label)+'</link>','small')
head('Scope ledger')
add('• “All curves” means every chosen-trace j vertex of the original rational degree-2 volcano, not every alternate model or every possible isogeny degree.<br/>• The large-prime dataset contains one crater and one floor per gap, not entire prime-degree volcanoes.<br/>• All completed large-gap timing comparisons are in 53-bit fields. The 96-bit ceiling is a search allowance, not a completed 96-bit ECDLP benchmark.<br/>• No remote registry, canonical graph or paper was modified. Full isogeny point transport and dual-map certification were not completed.','small')
add('Rebuild: python build_summary.py. The report reads only its evidence snapshots and derived-findings.json. See evidence-manifest.json for source paths and content hashes.','small')

W,H=A4
def frame(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(colors.HexColor('#d7e0e8'));canvas.line(42,H-30,W-42,H-30)
 canvas.setFillColor(colors.HexColor(navy));canvas.setFont('DV',7.5);canvas.drawString(42,H-23,'CONDUCTOR-GAP RESEARCH  /  EVIDENCE SUMMARY')
 canvas.setFont('DV',7);canvas.setFillColor(colors.HexColor('#64717e'));canvas.drawString(42,23,'15 October 2026  •  Measured results and proposed work are distinguished')
 canvas.drawRightString(W-42,23,str(doc.page));canvas.restoreState()
doc=SimpleDocTemplate(str(R/'Conductor_Gap_Research_Summary.pdf'),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=47,bottomMargin=42,title='Conductor gaps: research summary and next steps',author='Research workspace',subject='Verified volcanoes, conductor-gap benchmarks and the degree-5 CM endomorphism lead')
doc.build(story,onFirstPage=frame,onLaterPages=frame)
print('Created',R/'Conductor_Gap_Research_Summary.pdf')
