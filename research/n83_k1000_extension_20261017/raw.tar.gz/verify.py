#!/usr/bin/env python3
"""Independently replay local N83 base, relation and scalar controls."""

import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


producer = module('n83_layout_producer', HERE / 'run_one.py')
arithmetic = module('n83_layout_arithmetic',
                    ROOT / 'research/n83_root11_dynamic_20261016/verify.py')
flags = module('n83_layout_flags_replay',
               ROOT / 'research/n83_root11_dynamic_20261016/run.py')
target_path = ROOT / 'research/n83_cold_factor_base_20261016/targets.jsonl'
answer_path = ROOT / 'research/n83_cold_factor_base_20261016/answers.jsonl'
target = json.loads(target_path.read_text())
scalar = int(json.loads(answer_path.read_text())['scalar'])
point = arithmetic.group.point_from_json(target)
if (digest(producer.SOURCE) != producer.SOURCE_SHA256 or
        digest(target_path) != producer.TARGET_SHA256 or
        arithmetic.group.multiply(arithmetic.group.G, scalar) != point):
    raise ValueError('source or exposed point differs')

rows = []
for folder in sorted(HERE.glob('k*root*')):
    if not folder.is_dir():
        continue
    receipt = json.loads((folder / 'receipt.json').read_text())
    k, layout = receipt['k'], receipt['layout']
    summary = json.loads((folder / 'stdout.jsonl').read_text())
    result = json.loads((folder / 'targets_result.jsonl').read_text())
    base_dump = json.loads((folder / 'base_dump.jsonl').read_text())
    expected_flags = {key: value for key, value in
                      flags.environment(folder, layout).items()
                      if key.startswith('KIC_')}
    if (receipt['status'] != 'EXIT_0' or receipt['exit_code'] != 0 or
            receipt['source_sha256'] != producer.SOURCE_SHA256 or
            receipt['binary_sha256'] != producer.BINARY_SHA256 or
            receipt['target_sha256'] != producer.TARGET_SHA256 or
            receipt['environment_flags'] != expected_flags or
            receipt['command'] != [str(producer.BINARY),
                                   f'construct:83:1:{k}', str(target_path),
                                   '29', str(folder / 'targets_result.jsonl')] or
            summary['orbit_columns'] != k or summary['rank'] != k or
            summary['factor_base_points'] != 166 * k or
            summary['targets_solved'] != 1 or summary['targets_failed'] != 0 or
            result['target'] != target or result['group_verified'] is not True or
            int(result['recovered_scalar']) != scalar or
            (folder / 'stderr.log').read_bytes()):
        raise ValueError(f'{folder.name}: source, command, rank or scalar differs')
    base = arithmetic.group.replay_base(base_dump, summary)
    indices = result['point_indices']
    if (len(base) != 166 * k or len(indices) != 4 or any(
            not isinstance(i, int) or not 0 <= i < len(base) for i in indices)):
        raise ValueError(f'{folder.name}: base or witness differs')
    relation = None
    for index in indices:
        relation = arithmetic.group.add(relation, base[index])
    if relation != point:
        raise ValueError(f'{folder.name}: relation differs')
    phases = [float(result[key]) for key in (
        'target_query_ms', 'target_pdp_ms', 'target_relation_check_ms',
        'target_descent_ms', 'target_recovery_check_ms')]
    online = float(result['target_ms'])
    if (not math.isfinite(online) or online <= 0 or
            any(not math.isfinite(v) or v < 0 for v in phases) or
            abs(math.fsum(phases) - online) > 1):
        raise ValueError(f'{folder.name}: online phase sum differs')
    rows.append({'name': folder.name, 'k': k, 'layout': layout,
                 'status': 'PASS_INDEPENDENT_ARITHMETIC_REPLAY',
                 'base_hash': summary['base_hash'],
                 'actual_usable_points': len(base), 'effective_columns': k,
                 'index_build_ms': summary['timing_ms']['index_build'],
                 'rank_stage_ms': summary['timing_ms']['rank_stage'],
                 'cold_process_ms': summary['timing_ms']['process_total'],
                 'target_online_ms': online,
                 'target_probes': result['probes'],
                 'receipt_sha256': digest(folder / 'receipt.json'),
                 'stdout_sha256': digest(folder / 'stdout.jsonl'),
                 'base_dump_sha256': digest(folder / 'base_dump.jsonl'),
                 'target_result_sha256': digest(folder / 'targets_result.jsonl')})

output = {'schema': 'n83.local-k1000-extension-replay/v1',
          'source_sha256': producer.SOURCE_SHA256,
          'binary_sha256': producer.BINARY_SHA256,
          'target_sha256': producer.TARGET_SHA256,
          'answer_sha256': digest(answer_path),
          'status': 'PASS_INDEPENDENT_ARITHMETIC_REPLAY' if rows else 'NO_RUNS',
          'rows': rows}
blob = json.dumps(output, sort_keys=True, indent=2) + '\n'
destination = HERE / 'replay.json'
if destination.exists() and destination.read_text() != blob:
    raise ValueError('frozen replay summary differs')
destination.write_text(blob)
print(json.dumps({'status': output['status'], 'rows': len(rows)}, sort_keys=True))
