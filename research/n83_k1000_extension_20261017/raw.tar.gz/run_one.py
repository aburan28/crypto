#!/usr/bin/env python3
"""Run one exact-source N83 exposed-point factor-base layout control."""

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')
HERE = Path(__file__).resolve().parent
BINARY = Path('/private/tmp/n83-k3072-current-source-20261017/target/release/examples/koblitz_orbit_dlp_fast')
TARGET = ROOT / 'research/n83_cold_factor_base_20261016/targets.jsonl'
SOURCE = ROOT / 'examples/koblitz_orbit_dlp_fast.rs'
SOURCE_SHA256 = '8a2fe55dd90dc33892c197d27260182bf783fc8212fb485d8297daf2bbba8e12'
BINARY_SHA256 = 'd71a9662c9d4e2dde58443bfc646a05737c6b9ca6b3d5e831b632ce09384c906'
TARGET_SHA256 = '2c068d2f659588edcdbaa685fc73bb146e2bfee3be123d377d537658f8021c6d'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('k', type=int)
    parser.add_argument('layout', choices=('root11_dynamic', 'root22_dynamic'))
    args = parser.parse_args()
    if (digest(SOURCE), digest(BINARY), digest(TARGET)) != (
            SOURCE_SHA256, BINARY_SHA256, TARGET_SHA256):
        raise ValueError('source, binary or exposed point differs')
    spec = importlib.util.spec_from_file_location(
        'n83_layout_flags', ROOT / 'research/n83_root11_dynamic_20261016/run.py')
    flags_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(flags_module)
    folder = HERE / f'k{args.k}{args.layout.split("_")[0]}'
    folder.mkdir(exist_ok=False)
    environment = flags_module.environment(folder, args.layout)
    command = [str(BINARY), f'construct:83:1:{args.k}', str(TARGET), '29',
               str(folder / 'targets_result.jsonl')]
    started = time.monotonic()
    with (folder / 'stdout.jsonl').open('wb') as stdout, \
            (folder / 'stderr.log').open('wb') as stderr:
        try:
            result = subprocess.run(command, env=environment, cwd=ROOT,
                                    stdout=stdout, stderr=stderr, timeout=480,
                                    check=False)
            code, status = result.returncode, 'EXIT_0' if result.returncode == 0 else 'NONZERO_EXIT'
        except subprocess.TimeoutExpired:
            code, status = None, 'TIMEOUT_480S'
    receipt = {'schema': 'n83.local-k992-layout-screen/v1',
               'k': args.k, 'layout': args.layout, 'command': command,
               'environment_flags': {key: value for key, value in environment.items()
                                     if key.startswith('KIC_')},
               'source_sha256': SOURCE_SHA256, 'binary_sha256': BINARY_SHA256,
               'target_sha256': TARGET_SHA256,
               'wall_seconds': time.monotonic() - started,
               'exit_code': code, 'status': status}
    (folder / 'receipt.json').write_text(json.dumps(receipt, indent=2,
                                                     sort_keys=True) + '\n')
    print(json.dumps({'folder': str(folder), 'status': status,
                      'wall_seconds': receipt['wall_seconds']}, sort_keys=True))
    return 0 if code == 0 else 2


if __name__ == '__main__':
    raise SystemExit(main())
