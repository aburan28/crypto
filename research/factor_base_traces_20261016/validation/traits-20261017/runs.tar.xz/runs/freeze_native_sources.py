"""Record exact tracked build inputs; metadata only."""
import json
from pathlib import Path
import subprocess

root = Path('/workspace/crypto-pr1975-current')
out = Path('/workspace/pr1975-traits-fix-20261017')
inputs = json.loads((out / 'native-input-paths.json').read_text())
index = {}
for line in subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root).decode().split('\0'):
    if line:
        meta, path = line.split('\t', 1)
        mode, sha, stage = meta.split()
        assert stage == '0'
        index[path] = (mode, sha)
paths = set(inputs['sources']) | set(inputs['embedded'])
paths.update(p for p in index if p.startswith('.cargo/') or p.startswith('rust-toolchain'))
paths.update(p for p in ('Cargo.toml', 'Cargo.lock', 'build.rs') if p in index)
paths = sorted(paths)
actual = subprocess.check_output(['git', 'hash-object', '--stdin-paths'], cwd=root,
    input=''.join(json.dumps(p) + '\n' for p in paths).encode()).decode().splitlines()
assert len(actual) == len(paths)
rows = []
for path, sha in zip(paths, actual):
    assert index[path][1] == sha, path
    rows.append({'path': path, 'mode': index[path][0], 'git_blob': sha,
                 'bytes': (root / path).stat().st_size})
text = json.dumps(rows, indent=2) + '\n'
manifest = out / 'native-source-manifest.json'
if (out / 'native-source-manifest.frozen').exists():
    assert manifest.read_text() == text, 'native inputs changed after validation began'
else:
    manifest.write_text(text)
    (out / 'native-source-manifest.frozen').write_text('Exact merged-index inputs pinned before publication.\n')
print(f'{len(rows)} tracked native build inputs match the merged index and frozen manifest.')
