"""Accept only the diagnosed generated description repair; no curve arithmetic."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspace/crypto-pr1975-current'); out=Path('/workspace/pr1975-traits-fix-20261017')
assert (out/'regenerate.exit').read_text().strip()=='0'
a=json.loads((out/'traits-before.json').read_text());b=json.loads((out/'traits-regenerated.json').read_text())
assert a.keys()==b.keys()
assert len(a['curves'])==len(b['curves'])==2336
assert all(a[k]==b[k] for k in a if k!='curves')
changes=[]
for before,after in zip(a['curves'],b['curves']):
    assert before['slug']==after['slug']
    if before==after:continue
    wanted=json.loads(json.dumps(before))
    assert before['slug']=='icv1-fp24-t925-8af643e2'
    assert wanted['endomorphism']['levels'][0]['method']=='Frobenius is a scalar on E[ℓ]: above the floor'
    wanted['endomorphism']['levels'][0]['method']='Frobenius is a scalar on E[ℓ]: the crater'
    assert wanted==after,'Unexpected mathematical/metadata difference; review required'
    changes.append({'slug':before['slug'],'path':'endomorphism.levels[0].method','before':before['endomorphism']['levels'][0]['method'],'after':after['endomorphism']['levels'][0]['method']})
assert len(changes)==1,'Unexpected diff; review required'
base=json.loads((out/'main-traits.json').read_text());by_slug={c['slug']:c for c in b['curves']}
assert all(by_slug[c['slug']]==c for c in base['curves'])
assert a['factor_budget']==b['factor_budget']==262144
before=(out/'traits-before.json').read_bytes();after=(out/'traits-regenerated.json').read_bytes()
assert before!=after
receipt={'records':len(b['curves']),'changed_fields':changes,'base_records_unchanged':len(base['curves']),'budget':b['factor_budget'],'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'byte_comparison_exit':1}
(out/'regeneration-diff.json').write_text(json.dumps(receipt,indent=2)+'\n')
(root/'docs/curves/traits.json').write_bytes(after)
print(json.dumps(receipt,indent=2))
