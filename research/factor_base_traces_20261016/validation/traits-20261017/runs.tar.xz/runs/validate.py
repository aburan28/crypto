"""Native validation orchestration, with source/fixture pinned before compilation."""
import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/crypto-pr1975-current');out=Path('/workspace/pr1975-traits-fix-20261017')
env={**os.environ,'CARGO_HOME':'/workspace/pr1963-toolchain/cargo','RUSTUP_HOME':'/workspace/pr1963-toolchain/rustup','CARGO_TARGET_DIR':'/workspace/crypto-pr1963/target','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2'}
env['PATH']='/workspace/pr1963-toolchain/cargo/bin:'+env['PATH']
def run(name,args,check=True):
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    (out/(name+'.exit')).write_text(str(result.returncode)+'\n')
    print(name,result.returncode,flush=True)
    if check and result.returncode:raise RuntimeError(name+' failed; retain logs')
    return result.returncode
while not (out/'regenerate.exit').exists():
    try:os.kill(15217,0)
    except ProcessLookupError:raise RuntimeError('Original generation process ended without success marker; inspect logs')
    time.sleep(2)
run('apply-regeneration',['python3',str(out/'apply_regeneration.py')])
run('fixture-commit',['git','add','docs/curves/traits.json'])
run('source-commit',['git','commit','-m','Regenerate stale native historical-model trait description'])
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
(out/'native-source-commit.txt').write_text(sha+'\n')
run('freeze-native-inputs',['python3',str(out/'freeze_native_sources.py')])
# Compile tests while the native catalog check runs. Run actual tests only after
# both finish, avoiding resource competition with timed/budgeted unit tests.
with (out/'library-compile.log').open('w') as compile_log:
    compile_proc=subprocess.Popen(['cargo','test','--release','--lib','--no-run'],cwd=root,env=env,stdout=compile_log,stderr=subprocess.STDOUT)
    catalog_status=run('traits-check',['/workspace/crypto-pr1963/target/release/curve_traits','check'],check=False)
    compile_status=compile_proc.wait()
(out/'library-compile.exit').write_text(str(compile_status)+'\n')
if catalog_status or compile_status:raise RuntimeError('Catalog or unit compilation failed; retain logs')
run('library',['cargo','test','--release','--lib','--','--test-threads=1'])
binary=Path('/workspace/crypto-pr1963/target/release/deps/crypto_lib-c808bf6a09f96bab')
fixture=(root/'docs/curves/traits.json').read_bytes();data=binary.read_bytes();assert fixture in data
(out/'final-binary.json').write_text(json.dumps({'source_commit':sha,'binary':str(binary),'binary_bytes':len(data),'binary_sha256':hashlib.sha256(data).hexdigest(),'fixture_sha256':hashlib.sha256(fixture).hexdigest(),'exact_fixture_embedded':True},indent=2)+'\n')
run('native-trace-build',['cargo','build','--release','--bin','factor_base_trace'])
run('trace-tests',['cargo','test','--release','--bin','factor_base_trace'])
run('trace-verify',['/workspace/crypto-pr1963/target/release/factor_base_trace','verify','/workspace/factor_base_evaluation/results/generic.json','/workspace/factor-base-trace-registered'])
run('all-targets',['cargo','check','--all-targets'])
run('clippy',['cargo','clippy','--release','--bin','factor_base_trace','--','-D','warnings'])
run('final-input-check',['python3',str(out/'freeze_native_sources.py')])
run('preservation-final',['python3',str(out/'check_preservation.py')])
(out/'pipeline.exit').write_text('0\n')
print('All final native validation completed successfully on',sha,flush=True)
