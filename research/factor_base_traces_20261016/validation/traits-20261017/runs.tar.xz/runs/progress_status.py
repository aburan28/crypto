"""Read native validation logs; partial counts are not completed results."""
from pathlib import Path
import re,json
out=Path('/workspace/pr1975-traits-fix-20261017')
log=(out/'library.log').read_text() if (out/'library.log').exists() else ''
print(json.dumps({'library_observed_ok':len(re.findall(r'\.\.\. ok$',log,re.M)),'library_observed_failed':len(re.findall(r'\.\.\. FAILED$',log,re.M)),'library_observed_ignored':len(re.findall(r'\.\.\. ignored',log)),'completed_summary':re.findall(r'test result:.*',log),'pipeline_tail':(out/'pipeline.log').read_text().splitlines()[-6:]},indent=2))
