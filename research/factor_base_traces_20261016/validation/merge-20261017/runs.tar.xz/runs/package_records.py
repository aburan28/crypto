"""Package completed validation evidence; no experiments or measurements."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil

source = Path('/workspace/pr1975-final-validation')
destination = Path('/workspace/crypto-pr1975-current/research/factor_base_traces_20261016/validation/merge-20261017/runs')
assert (source / 'pipeline.exit').read_text().strip() == '0', 'native pipeline not confirmed successful'
assert not destination.exists(), 'do not rewrite an existing evidence snapshot'
destination.mkdir()
members = []
suffixes = {'.log', '.txt', '.json', '.py', '.sha256', '.status', '.exit', '.frozen'}
for path in sorted(source.iterdir()):
    if not path.is_file() or path.name == 'continuation.json' or path.suffix not in suffixes:
        continue
    data = path.read_bytes()
    if re.search(rb'(?:AKIA|ASIA)[A-Z0-9]{16}', data):
        raise RuntimeError('credential-shaped value in ' + path.name)
    if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', data):
        raise RuntimeError('private-key-shaped value in ' + path.name)
    shutil.copyfile(path, destination / path.name)
    members.append({'member': 'runs/' + path.name, 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest(),
                    'original_modified_utc': datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
(destination / 'archive-member-manifest.json').write_text(json.dumps(members, indent=2) + '\n')
print(f'Copied {len(members)} completed validation records, {sum(r["bytes"] for r in members)} bytes before compression.')
