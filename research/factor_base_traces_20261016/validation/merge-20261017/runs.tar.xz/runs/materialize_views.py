"""Materialize tracked presentation inputs from the merged index, read-only."""
import ast
import fnmatch
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/crypto-pr1975-current')
OUT = Path('/workspace/pr1975-final-validation')
sys.path.insert(0, str(ROOT / 'scripts'))
from check_ic_leaderboard_paths import glob_regex

def git(*args, **kwargs):
    return subprocess.check_output(['git', *args], cwd=ROOT, **kwargs)

def constants(path):
    result = {}
    for node in ast.parse((ROOT / path).read_text()).body:
        if isinstance(node, ast.Assign):
            try:
                value = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    result[target.id] = value
    return result

rows = {}
for line in git('ls-files', '--stage', '-z').decode().split('\0'):
    if not line:
        continue
    meta, path = line.split('\t', 1)
    mode, oid, stage = meta.split()
    if stage == '0':
        rows[path] = oid

browser = constants('scripts/build_lab_browser.py')
board = constants('scripts/build_ic_leaderboard.py')
patterns = [glob_regex(p) for p in browser['IC1_SCAN_GLOBS']]
chosen = set(board['SOURCES'].values()) | {board['LEDGER']}
for key in ('REGISTRY', 'COVERS', 'COVER_LINKS', 'STANDARDS_COVERAGE', 'LEADERBOARD'):
    chosen.add(browser[key])
for path in rows:
    if any(pat.fullmatch(path) for pat in patterns):
        chosen.add(path)
    if path.startswith(browser['TOURNAMENT_RUNS'] + '/') and path.endswith(('.json', '.jsonl', '.md')):
        chosen.add(path)
    if '/sessions/' in path and any(fnmatch.fnmatchcase(path.rsplit('/', 1)[0], pat)
                                  for pat in browser['ECBENCH_SESSIONS_GLOBS']):
        if Path(path).name in ('session.json', 'records.jsonl', 'spec.json'):
            chosen.add(path)
old = Path('/workspace/pr1975-ci-fix/leaderboard-input-paths.txt')
for path in old.read_text().splitlines():
    if path in rows:
        chosen.add(path)
chosen = sorted(p for p in chosen if p in rows and not (ROOT / p).exists())
oids = sorted({rows[p] for p in chosen})
env = {**os.environ, 'GIT_NO_LAZY_FETCH': '1'}
checks = git('cat-file', '--batch-check=%(objectname) %(objecttype)',
             input=('\n'.join(oids) + '\n').encode(), env=env).decode().splitlines() if oids else []
missing = [line.split()[0] for line in checks if line.endswith(' missing')]
(OUT / 'view-input-paths.txt').write_text('\n'.join(chosen) + '\n')
if missing:
    subprocess.run(['git', '-c', 'fetch.negotiationAlgorithm=noop', 'fetch',
                    '--no-tags', '--no-write-fetch-head', '--recurse-submodules=no',
                    '--filter=blob:none', 'origin', '--stdin'], input='\n'.join(missing) + '\n',
                   text=True, cwd=ROOT, check=True)
if chosen:
    manifest = OUT / 'view-input-paths.nul'
    manifest.write_bytes(('\0'.join(chosen) + '\0').encode())
    subprocess.run(['git', 'restore', '--worktree', '--ignore-skip-worktree-bits',
                    '--pathspec-from-file=' + str(manifest), '--pathspec-file-nul'],
                   cwd=ROOT, check=True)
print(f'Materialized {len(chosen)} tracked presentation inputs; fetched {len(missing)} missing blobs.')
