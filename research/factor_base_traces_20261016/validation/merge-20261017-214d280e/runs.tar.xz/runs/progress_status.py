from pathlib import Path
import json,re
out=Path('/workspace/pr1975-merge-final-20261017')
s=(out/'library.log').read_text() if (out/'library.log').exists() else ''
print(json.dumps({'partial_ok':len(re.findall(r'\.\.\. ok$',s,re.M)),'partial_failed':len(re.findall(r'\.\.\. FAILED$',s,re.M)),'partial_ignored':len(re.findall(r'\.\.\. ignored',s)),'completed_library_summary':re.findall(r'test result:.*',s),'pipeline':(out/'pipeline.log').read_text().splitlines()[-9:]},indent=2))
