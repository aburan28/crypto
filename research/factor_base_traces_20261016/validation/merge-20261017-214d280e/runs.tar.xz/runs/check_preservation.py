"""Read-only three-way metadata/immutable-blob audit; no curve arithmetic."""
import copy,json,subprocess,sys
from pathlib import Path
ROOT=Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip())
HEAD='b6f55641aa9650c19abe78c9dd18f96dd92f09db'
MAIN='214d280ebea1443f850d4dd233a603c0ae531b01'
PRIOR='d78eed09a48bec50b8fab3cafc9c0203fb7d5b99'
CREATION='0b4a7451c7bb080642f03fccb641066dd11f795d'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def old(ref,path):return json.loads(git('show',ref+':'+path))
def cur(path):return json.loads((ROOT/path).read_text())
def tree(ref):return {r.split('\t',1)[1]:r.split()[2] for r in git('ls-tree','-r',ref).decode().splitlines()}
index={}
for row in git('ls-files','--stage','-z').decode().split('\0'):
 if row:
  meta,path=row.split('\t',1);mode,sha,stage=meta.split()
  if stage=='0':index[path]=sha
paths=git('diff-tree','--no-commit-id','--name-only','-r',PRIOR+'^2',PRIOR).decode().splitlines()
containers={'docs/curves/registry.json','src/cryptanalysis/curve_aliases.json','store/index.json'}
fixed=[p for p in paths if p not in containers];assert len(fixed)==53
before=tree(PRIOR);assert all(index[p]==before[p] for p in fixed)
for p in fixed:
 if (ROOT/p).exists():assert git('hash-object','--',p).decode().strip()==index[p],p
frozen={p:s for p,s in tree(CREATION).items() if p.startswith('research/factor_base_evaluation_20261015/')}
assert len(frozen)==27 and all(index[p]==s for p,s in frozen.items())
print('All53immutable prior payload blobs and27frozen historical evaluation blobs unchanged.')
r=cur('docs/curves/registry.json');models={x['slug']:x for x in r['curves']};assert len(models)==len(r['curves'])==2177
main={x['slug']:x for x in old(MAIN,'docs/curves/registry.json')['curves']};prev={x['slug']:x for x in old(HEAD,'docs/curves/registry.json')['curves']}
assert all(models[k]==v for k,v in main.items())
historical=prev.keys()-main.keys();assert len(historical)==48
for key,row in prev.items():
 now=models[key];assert all(now[k]==row[k] for k in ('slug','icv1','model_json','order')),(key,'identity')
 for k in ('aliases','sources','standard_names','representations'):assert all(v in now.get(k,[]) for v in row.get(k,[])),(key,k)
 if key in historical:assert now==row,key
aliases=cur('src/cryptanalysis/curve_aliases.json');stores=cur('store/index.json')['entries']
for ref in (HEAD,MAIN):
 a=old(ref,'src/cryptanalysis/curve_aliases.json');assert all(aliases['aliases'][k]==v for k,v in a['aliases'].items()),ref
 assert all(stores[k]==v for k,v in old(ref,'store/index.json')['entries'].items()),ref
print('Both parents retained:2177models,',len(aliases['aliases']),'aliases,',len(stores),'stores; all48historical model records exact.')
def measured(doc):
 doc=copy.deepcopy(doc);doc.pop('roster');doc['sources']['registry'].pop('sha256');return doc
assert measured(cur('docs/ic/leaderboard.json'))==measured(old(MAIN,'docs/ic/leaderboard.json'))
card={p:s for p,s in tree(MAIN).items() if p.startswith('backlog/XP-20261016-prime-base-oracle-tuning/')};assert card and all(index[p]==s for p,s in card.items())
c=cur('backlog/XP-20261016-prime-base-oracle-tuning/card.json');assert c['status']=='draft' and c['cairn']['funding']['units']==0 and c['protocol']=={'path':None,'blob':None} and c['checkpoint']=={'file':None,'resume_flag':None} and c['run']['argv']==['TODO-freeze-native-ecbench-spec-and-command']
print('Every measured leaderboard field matches main; draft/zero-funded/unrun planning card unchanged.')
if '--pre' in sys.argv:raise SystemExit(0)
assert not git('diff','--name-only','--diff-filter=U').strip(),'Unresolved merge'
browser=cur('docs/browser/data.json');keys={'curves':'slug','methods':'method_id','factor_bases':'fb_id','candidates':'candidate_id','rounds':'round','sessions':'dir'}
for ref in (HEAD,MAIN):
 prior=old(ref,'docs/browser/data.json')
 for field,key in keys.items():
  now={r[key]:r for r in browser[field]};assert all(r[key] in now for r in prior[field]),(ref,field)
  if field in ('sessions','rounds'):assert all(now[r[key]]==r for r in prior[field]),(ref,field)
 assert all(r in browser['yields'] for r in prior['yields']),ref
print('Both parents browser identities, exact sessions/rounds and yields retained:',json.dumps(browser['counts'],sort_keys=True))
traits=cur('docs/curves/traits.json');by={r['slug']:r for r in traits['curves']};assert traits['factor_budget']==262144
previous_traits={r['slug']:r for r in old(HEAD,'docs/curves/traits.json')['curves']};main_traits={r['slug']:r for r in old(MAIN,'docs/curves/traits.json')['curves']}
assert by.keys()==previous_traits.keys()|main_traits.keys()
assert all(by[k]==v for k,v in main_traits.items())
assert all(by[k]==previous_traits[k] for k in historical)
assert all(by[k]==v for k,v in previous_traits.items() if k not in main_traits)
upstream_changed=[k for k,v in previous_traits.items() if k in main_traits and v!=main_traits[k]]
print('All48historical trait rows and all main-parent traits retained exactly;',len(by),'records, unchanged262144budget. Upstream-changed shared traits:',json.dumps(upstream_changed))
