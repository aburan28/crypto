"""Join native-computed catalog records and refresh metadata; no curve arithmetic."""
from pathlib import Path
import copy,json,subprocess,sys
root=Path('/workspace/crypto-pr1975-current');out=Path('/workspace/pr1975-merge-final-20261017')
sys.path.insert(0,str(root/'scripts'))
import curve_id
import update_curve_standards as tools
head='b6f55641aa9650c19abe78c9dd18f96dd92f09db';main='214d280ebea1443f850d4dd233a603c0ae531b01';base='a95fcd95305af6ac98773011e7730203e927ae70'
def previous(ref,path):return json.loads(subprocess.check_output(['git','show',ref+':'+path],cwd=root))
reg=json.loads((root/'docs/curves/registry.json').read_text())
reg=tools.merge(reg,json.loads((root/'docs/curves/standards/registry.json').read_text()))
models={r['slug']:r for r in reg['curves']};assert len(models)==len(reg['curves'])==2177
main_models={r['slug']:r for r in previous(main,'docs/curves/registry.json')['curves']}
old_models={r['slug']:r for r in previous(head,'docs/curves/registry.json')['curves']}
assert all(models[k]==v for k,v in main_models.items()),'Main canonical model changed'
for slug,old in old_models.items():
 now=models[slug];assert all(now[k]==old[k] for k in ('slug','icv1','model_json','order')),slug
 for key in ('aliases','standard_names','sources','representations'):
  assert all(value in now.get(key,[]) for value in old.get(key,[])),(slug,key)
 if slug not in main_models:assert old==now,slug
(root/'docs/curves/registry.json').write_text(json.dumps(reg,indent=1,ensure_ascii=False)+'\n')
text=curve_id.alias_map_text(reg);aliases=json.loads(text)
for ref in (head,main):
 old=previous(ref,'src/cryptanalysis/curve_aliases.json')
 assert all(aliases['aliases'][k]==v for k,v in old['aliases'].items()),('Alias replacement',ref)
 assert all(aliases[k]==v for k,v in old.items() if k!='aliases'),ref
(root/'src/cryptanalysis/curve_aliases.json').write_text(text)
store=json.loads((root/'store/index.json').read_text())['entries']
for ref in (head,main):assert all(store[k]==v for k,v in previous(ref,'store/index.json')['entries'].items()),ref

def measured(doc):
 doc=copy.deepcopy(doc);doc.pop('roster');doc['sources']['registry'].pop('sha256');return doc
assert measured(previous(head,'docs/ic/leaderboard.json'))==measured(previous(base,'docs/ic/leaderboard.json'))
# The feature never changed measured fields: use latest-main canonical input,
# then the existing metadata renderer refreshes only roster and registry hash.
canonical=previous(main,'docs/ic/leaderboard.json')
(root/'docs/ic/leaderboard.json').write_text(json.dumps(canonical,indent=1,ensure_ascii=False)+'\n')
for path,rendered in tools.catalog_displays().items():path.write_text(rendered)
assert measured(json.loads((root/'docs/ic/leaderboard.json').read_text()))==measured(canonical)
summary={'head':head,'main':main,'models':len(models),'aliases':len(aliases['aliases']),'store_entries':len(store),'historical_only_models_unchanged':len(old_models.keys()-main_models.keys()),'all_main_models_exact':True,'all_previous_alias_mappings_and_store_entries':True,'all_main_measured_fields_exact':True}
(out/'metadata-resolution.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
