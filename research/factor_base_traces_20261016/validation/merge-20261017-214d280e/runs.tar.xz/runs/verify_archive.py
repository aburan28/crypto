from pathlib import Path
import hashlib,json,subprocess,tarfile,tempfile
base=Path('/workspace/crypto-pr1975-current/research/factor_base_traces_20261016/validation/merge-20261017-214d280e')
archive=base/'runs.tar.xz'
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers()
 assert all(m.name=='runs' or (m.name.startswith('runs/') and '..' not in Path(m.name).parts) for m in members)
 assert all(m.isdir() or m.isfile() for m in members)
 manifest=json.load(tar.extractfile('runs/archive-member-manifest.json'))
 actual={m.name for m in members if m.isfile()}
 assert actual=={r['member'] for r in manifest}|{'runs/archive-member-manifest.json'}
 for row in manifest:
  data=tar.extractfile(row['member']).read()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['member']
 with tempfile.TemporaryDirectory(prefix='pr1975-archive-',dir='/workspace') as td:
  tar.extractall(td,filter='data')
  repack=Path(td)/'repacked.tar.xz'
  with repack.open('wb') as target:
   p=subprocess.Popen(['tar','--sort=name',"--mtime=2026-10-17 00:00:00Z",'--owner=0','--group=0','--numeric-owner','--mode=u+rwX,go+rX,go-w','--format=gnu','-cf','-','runs'],cwd=td,stdout=subprocess.PIPE)
   q=subprocess.run(['xz','-6','-T1'],stdin=p.stdout,stdout=target);p.stdout.close();assert p.wait()==0 and q.returncode==0
  assert repack.read_bytes()==archive.read_bytes(),'Extracted-tree deterministic repack differs'
print(json.dumps({'verified_members':len(manifest),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'extracted_tree_repack_byte_identical':True},indent=2))
