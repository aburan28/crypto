"""Validate the frozen two-parent integration source; no research experiment."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/crypto-pr1975-current');out=Path('/workspace/pr1975-merge-final-20261017')
env={**os.environ,'CARGO_HOME':'/workspace/pr1963-toolchain/cargo','RUSTUP_HOME':'/workspace/pr1963-toolchain/rustup','CARGO_TARGET_DIR':'/workspace/crypto-pr1963/target','CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2'};env['PATH']='/workspace/pr1963-toolchain/cargo/bin:'+env['PATH']
def run(name,args,check=True):
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.exit')).write_text(str(r.returncode)+'\n');print(name,r.returncode,flush=True)
 if check and r.returncode:raise RuntimeError(name+' failed; preserve logs and inspect')
 return r.returncode
# Only native generation completion is awaited here. CI is never polled.
while not (out/'generation.exit').exists():
 if any(p.exists() and p.read_text().strip()!='0' for p in out.glob('*-build.exit')):raise RuntimeError('Native generation failed; inspect logs')
 time.sleep(2)
run('browser-build',['python3','scripts/build_lab_browser.py'])
paths=['docs/browser/data.json','docs/curves/cover-links.yaml','docs/curves/covers.json','docs/curves/jacobian-transfers.json','docs/curves/registry.json','docs/curves/traits.json','docs/ic-leaderboard.html','docs/ic/LEADERBOARD.md','docs/ic/leaderboard.json','src/cryptanalysis/curve_aliases.json']
run('stage-metadata',['git','add','--sparse',*paths])
run('preservation',['python3',str(out/'check_preservation.py')])
run('display-check',['python3','scripts/update_curve_standards.py','--check'])
run('browser-check',['python3','scripts/build_lab_browser.py','--check'])
run('leaderboard-check',['python3','scripts/build_ic_leaderboard.py','--check'])
run('source-commit',['git','commit','-m','Merge main and regenerate additive historical factor-base catalogs'])
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();(out/'native-source-commit.txt').write_text(sha+'\n')
parents=subprocess.check_output(['git','show','-s','--format=%P','HEAD'],cwd=root,text=True).split();assert parents==['b6f55641aa9650c19abe78c9dd18f96dd92f09db','214d280ebea1443f850d4dd233a603c0ae531b01'],parents
run('freeze-native-inputs',['python3',str(out/'freeze_native_sources.py')])
checks={'traits-check':['/workspace/crypto-pr1963/target/release/curve_traits','check'],'jacobian-check':['/workspace/crypto-pr1963/target/release/jacobian_transfers','check'],'covers-check':['/workspace/crypto-pr1963/target/release/curve_cover_check','--check'],'library-compile':['cargo','test','--release','--lib','--no-run']}
jobs=[]
for name,args in checks.items():
 log=(out/(name+'.log')).open('w');jobs.append((name,subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT),log))
results={}
for name,proc,log in jobs:
 status=proc.wait();log.close();(out/(name+'.exit')).write_text(str(status)+'\n');results[name]=status;print(name,status,flush=True)
assert all(v==0 for v in results.values()),'Retain failed checks/compile; no tests run against unaccepted fixture'
# Run the full suite only after every competing catalog computation finishes.
run('library',['cargo','test','--release','--lib','--','--test-threads=1'])
binary=Path('/workspace/crypto-pr1963/target/release/deps/crypto_lib-c808bf6a09f96bab');data=binary.read_bytes();fixture=(root/'docs/curves/traits.json').read_bytes();assert fixture in data
(out/'final-library-binary.json').write_text(json.dumps({'source_commit':sha,'binary_bytes':len(data),'binary_sha256':hashlib.sha256(data).hexdigest(),'fixture_sha256':hashlib.sha256(fixture).hexdigest(),'exact_fixture_embedded':True},indent=2)+'\n')
run('trace-build-final',['cargo','build','--release','--bin','factor_base_trace'])
run('trace-tests',['cargo','test','--release','--bin','factor_base_trace'])
run('trace-verify',['/workspace/crypto-pr1963/target/release/factor_base_trace','verify','/workspace/factor_base_evaluation/results/generic.json','/workspace/factor-base-trace-registered'])
run('all-targets',['cargo','check','--all-targets'])
run('clippy',['cargo','clippy','--release','--bin','factor_base_trace','--','-D','warnings'])
run('final-input-check',['python3',str(out/'freeze_native_sources.py')])
run('preservation-final',['python3',str(out/'check_preservation.py')])
run('names',['python3','scripts/check_curve_names.py','--diff','214d280ebea1443f850d4dd233a603c0ae531b01'])
run('whitespace',['git','diff','--check'])
(out/'pipeline.exit').write_text('0\n');print('Final integration source validated:',sha,flush=True)
