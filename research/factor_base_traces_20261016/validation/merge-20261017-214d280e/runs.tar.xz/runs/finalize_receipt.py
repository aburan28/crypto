from pathlib import Path
import json,re
out=Path('/workspace/pr1975-merge-final-20261017');root=Path('/workspace/crypto-pr1975-current')
assert (out/'pipeline.exit').read_text().strip()=='0'
log=(out/'library.log').read_text();matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',log)
assert len(matches)==1 and matches[0][1]=='0';passed,failed,ignored,measured,filtered=map(int,matches[0])
binary=json.loads((out/'final-library-binary.json').read_text());assert binary['exact_fixture_embedded'] and binary['source_commit']=='49da4912f97e3f9e39f3119adffc3992ee36b97e'
statuses={p.stem:int(p.read_text()) for p in out.glob('*.exit')};assert statuses['merge']==1 and statuses['stage-metadata-initial-sparse']==1;assert filtered==0
assert all(v==0 for k,v in statuses.items() if k not in {'merge','stage-metadata-initial-sparse','executing-binary-diagnostic'})
summary={'source_commit':binary['source_commit'],'source_tree':'785431229b3609fe56c7661b3a24a6c104afabc2','library':{'passed':passed,'failed':failed,'ignored':ignored,'measured':measured,'filtered_out':filtered,'one_command':True},'native_inputs':1384,'binary':binary,'command_exits':statuses,'retained_nonzero_outcomes':{'merge':1,'stage-metadata-initial-sparse':1,'executing-binary-diagnostic':1},'historical_generator_rerun':False,'s3_operation':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p=root/'research/factor_base_traces_20261016/MERGE_VALIDATION_20261017_214d280e.md'
s=p.read_text();old='Final native checks and the full suite are in progress. No running or\npartial command is a passing result. Actual outcomes and the final unit\nbinary/fixture proof will be recorded after completion.'
new=f'''The complete `cargo test --release --lib -- --test-threads=1` command
passed **{passed:,} tests, zero failures and {ignored} existing ignores**. Nothing
was filtered out. It ran with networking, including loopback, enabled.
The final unit binary SHA-256 is
`{binary['binary_sha256']}`;
a byte check confirms it embeds the exact frozen trait fixture above.
Native trait, Jacobian and cover freshness checks, the production trace
build, all four trace tests, verification of all 384 source-backed records
and signed caches, all-target compilation, strict trace Clippy, naming,
whitespace, 20 existing metadata regression tests and final
preservation/input-manifest audits all passed.

The original nine-conflict merge exit and a sparse-checkout staging failure
are retained. Staging was retried with `git add --sparse` and passed without
changing generated outputs or sparsity. An optional `/proc` executable
read was denied by the sandbox; its failed diagnostic is retained and
is not a validation pass. No test assertion, limit or ignore
was changed. All 1,384 native inputs still match the pre-compilation manifest.'''
assert old in s;p.write_text(s.replace(old,new).replace('manifests will be retained as one deterministic','manifests are retained as one deterministic'))
with (out/'commands.txt').open('a') as f:
 f.write('\nFinal source '+binary['source_commit']+'; all final inputs frozen before compilation.\n')
 f.write('python3 validate_final.py records exact subprocess argv, per-command logs and exits.\n')
 f.write('Native checks: curve_traits check; jacobian_transfers check; curve_cover_check --check.\n')
 f.write('cargo test --release --lib --no-run; then cargo test --release --lib -- --test-threads=1\n')
 f.write(f'One complete library command: {passed}passed,{failed}failed,{ignored}existingignores,{filtered}filtered. Exact embedded fixture verified in final unit binary.\n')
 f.write('cargo build --release --bin factor_base_trace; cargo test --release --bin factor_base_trace\n')
 f.write('/workspace/crypto-pr1963/target/release/factor_base_trace verify /workspace/factor_base_evaluation/results/generic.json /workspace/factor-base-trace-registered\n')
 f.write('cargo check --all-targets; cargo clippy --release --bin factor_base_trace -- -D warnings\n')
 f.write('python3 freeze_native_sources.py; python3 check_preservation.py; python3 scripts/check_curve_names.py --diff 214d280ebea1443f850d4dd233a603c0ae531b01; git diff --check\n')
 f.write('All required pipeline exits0. Expected initial merge exit1, sparse staging failure1 and optional sandbox-denied executable diagnostic1 preserved; no assertions/budgets/ignores changed.\n')
print(json.dumps(summary,indent=2))
