"""Package one completed validation snapshot; preserve original failed attempts."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,re,shutil
source=Path('/workspace/pr1975-merge-final-20261017');destination=Path('/workspace/crypto-pr1975-current/research/factor_base_traces_20261016/validation/merge-20261017-214d280e/runs')
assert (source/'pipeline.exit').read_text().strip()=='0','Final native pipeline must complete successfully first'
assert not destination.exists(),'Never rewrite an existing evidence snapshot'
destination.mkdir(parents=True)
rows=[]
for prefix,folder in [('',source),('b6-before-merge-',Path('/workspace/pr1975-b6-final-validation'))]:
 for path in sorted(folder.iterdir()):
  if not path.is_file() or path.suffix not in {'.py','.json','.log','.txt','.exit','.frozen','.sha256'}:continue
  if path.name.startswith('continuation'):continue
  data=path.read_bytes()
  assert not re.search(rb'(?:AKIA|ASIA)[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data),'Credential-shaped data in '+path.name
  name=prefix+path.name;shutil.copyfile(path,destination/name)
  rows.append({'member':'runs/'+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'original_modified_utc':datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat()})
(destination/'archive-member-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print('Preserved',len(rows),'records,',sum(r['bytes'] for r in rows),'bytes before compression.')
