#!/usr/bin/env sage -python
"""Frozen, bounded experiment. Run with SageMath 10.6 from this directory."""
import argparse, ctypes as C, hashlib, itertools, json, math, os, random, signal
import sys, time, resource, traceback
from multiprocessing import Pipe
from pathlib import Path
from sage.all import GF, EllipticCurve, PolynomialRing, ZZ, matrix, version

ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'protocol.json').read_text())
SEED=P['seed']
INF=(1<<64)-1
OUT=ROOT/'results'
OUT.mkdir(exist_ok=True)

def digest(*args):
    return hashlib.sha256(('|'.join(map(str,(SEED,)+args))).encode()).hexdigest()
def rng(*args): return random.Random(int(digest(*args),16))
def write(name,obj):
    path=OUT/name
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(obj,indent=2,sort_keys=True))
    temporary.replace(path)
def event(event_name,**kwargs): print(json.dumps(dict(event=event_name,**kwargs)),flush=True)
def pack(x,y): return (int(x)<<32)|int(y)
def unpack(point): return (point>>32,point&((1<<32)-1))

class Native:
    def __init__(self):
        self.lib=C.CDLL(str(ROOT/'native.so'))
        self.lib.fb_add.argtypes=[C.c_uint32,C.c_int32,C.c_uint64,C.c_uint64]
        self.lib.fb_add.restype=C.c_uint64
        self.lib.fb_neg.argtypes=[C.c_uint32,C.c_uint64]
        self.lib.fb_neg.restype=C.c_uint64
        self.lib.fb_pairs.argtypes=[C.c_uint32,C.c_int32,C.POINTER(C.c_uint64),C.c_int32,C.POINTER(C.c_uint64)]
        self.lib.fb_pairs.restype=C.c_void_p
        self.lib.fb_free.argtypes=[C.c_void_p]
        self.lib.fb_decompose.argtypes=[C.c_uint32,C.c_int32,C.POINTER(C.c_uint64),C.c_int32,C.c_void_p,C.c_uint64,C.c_uint64,C.POINTER(C.c_int32),C.c_uint64]
        self.lib.fb_decompose.restype=C.c_uint64
    def add(self,p,A,B): return int(self.lib.fb_add(p,-3,A,B))
    def neg(self,p,A): return int(self.lib.fb_neg(p,A))
    def total(self,p,base,terms):
        value=INF
        for t in terms:
            point=base[abs(t)-1]
            value=self.add(p,value,point if t>0 else self.neg(p,point))
        return value
N=Native()

class Join:
    def __init__(self,p,base):
        self.p=p; self.base=base
        self.array=(C.c_uint64*len(base))(*base)
        length=C.c_uint64()
        self.table=N.lib.fb_pairs(p,-3,self.array,len(base),C.byref(length))
        if not self.table: raise MemoryError('pair allocation failed')
        self.length=int(length.value)
    def solve(self,target):
        capacity=1024
        while True:
            output=(C.c_int32*(3*capacity))()
            count=int(N.lib.fb_decompose(self.p,-3,self.array,len(self.base),self.table,self.length,target,output,capacity))
            if count<=capacity:
                return [tuple(output[3*i+j] for j in range(3)) for i in range(count)]
            capacity=count
    def close(self):
        if self.table: N.lib.fb_free(self.table); self.table=None
    def __del__(self): self.close()

class Rank:
    def __init__(self,m,r): self.m=m;self.r=r;self.pivots={};self.rows=[]
    def add(self,sparse):
        row=[0]*self.m
        for index,value in sparse.items(): row[index]=value%self.r
        for col in sorted(self.pivots):
            v=row[col]
            if v:
                pivot=self.pivots[col]
                for j in range(col,self.m): row[j]=(row[j]-v*pivot[j])%self.r
        col=next((i for i,v in enumerate(row) if v),None)
        if col is None:return False
        inverse=pow(row[col],-1,self.r)
        self.pivots[col]=[(v*inverse)%self.r for v in row]
        self.rows.append({str(i):int(v) for i,v in sparse.items() if v})
        return True
    def cycles(self,p,base,target,decompositions):
        for terms in decompositions:
            assert len(set(map(abs,terms)))==3
            assert N.total(p,base,terms)==target
        if not decompositions:return 0
        anchor=decompositions[0]
        gained=0
        for terms in decompositions[1:8]:
            sparse={}
            for multiplier,rep in [(1,terms),(-1,anchor)]:
                for t in rep:
                    i=abs(t)-1
                    sparse[i]=sparse.get(i,0)+multiplier*(1 if t>0 else -1)
            if self.add(sparse): gained+=1
        return gained

def curve_record(bits,field_index,curve_index,p):
    K=GF(p); stream=rng('curve',bits,field_index,curve_index)
    failures=[]
    for attempt in range(10000):
        b=stream.randrange(1,p)
        try:E=EllipticCurve(K,[-3,b])
        except ArithmeticError:
            failures.append([b,'singular']);continue
        if E.discriminant()==0:
            failures.append([b,'singular']);continue
        r=int(E.cardinality()); t=p+1-r
        if not ZZ(r).is_prime(proof=True):
            failures.append([b,'composite_order']);continue
        if r==p or t%p==0 or E.j_invariant() in [K(0),K(1728)]:
            failures.append([b,'special_curve']);continue
        if any(pow(p,k,r)==1 for k in range(1,65)):
            failures.append([b,'embedding_degree']);continue
        return dict(bits=bits,field=field_index,curve=curve_index,p=p,b=b,r=r,t=t,
                    embedding_degree=int(GF(r)(p).multiplicative_order()),
                    attempts=attempt+1,failures=failures)
    raise RuntimeError('curve admission exhausted')

def prepare():
    before=time.process_time(); curves=[]
    for bits in P['field_bits']:
        k=P['subgroup_exponents'][str(bits)]; d=1<<k
        candidates=list(range(((1<<(bits-1))+d-1)//d,((1<<bits)-1)//d+1))
        rng('fields',bits).shuffle(candidates)
        primes=[]
        for q in candidates:
            p=q*d+1
            if p.bit_length()==bits and ZZ(p).is_prime(proof=True): primes.append(p)
            if len(primes)==P['fields_per_size']:break
        assert len(primes)==P['fields_per_size']
        for fi,p in enumerate(primes):
            for ci in range(P['curves_per_field']):
                record=curve_record(bits,fi,ci,p)
                curves.append(record)
                event('curve_admitted',bits=bits,field=fi,curve=ci,p=p,r=record['r'])
    write('curves.json',curves)
    write('environment.json',dict(sage=version(),python=sys.version,cpu_affinity=sorted(os.sched_getaffinity(0)),
                                protocol_sha256=hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),
                                preparation_cpu_seconds=time.process_time()-before))

def point_from_x(K,b,x):
    x=int(x); rhs=K(x)**3-3*K(x)+b
    if not rhs.is_square():return None
    y=int(rhs.sqrt());y=min(y,int(K.order())-y)
    return pack(x,y)

def base_build(record,coset_seed,kind,m=None):
    started=time.process_time();p=record['p'];b=record['b'];bits=record['bits']
    K=GF(p);stream=rng('base',bits,record['field'],record['curve'],coset_seed,kind)
    base=[]; seen=set();extra={}
    if kind=='coset':
        k=P['subgroup_exponents'][str(bits)];d=1<<k
        h=int(K.multiplicative_generator()**((p-1)//d))
        c=stream.randrange(1,p);x=c
        assert pow(h,d,p)==1 and pow(h,d//2,p)!=1
        for _ in range(d):
            point=point_from_x(K,b,x)
            if point is not None:base.append(point)
            x=x*h%p
        extra=dict(k=k,d=d,h=h,c=c,gamma=pow(c,d,p))
        assert len({Q>>32 for Q in base})==len(base)
    elif kind=='low_x':
        for x in range(p):
            point=point_from_x(K,b,x)
            if point is not None:base.append(point)
            if len(base)==m:break
    elif kind=='random':
        while len(base)<m:
            x=stream.randrange(p)
            if x in seen:continue
            seen.add(x);point=point_from_x(K,b,x)
            if point is not None:base.append(point)
    elif kind=='low_digit_weight':
        radix=4 if bits==16 else 8
        drawn=0
        for support in range(9):
            candidates=[]
            for positions in itertools.combinations(range(8),support):
                for coefficients in itertools.product([-2,-1,1,2],repeat=support):
                    value=sum(a*radix**i for a,i in zip(coefficients,positions))
                    height=sum(map(abs,coefficients))
                    tie=digest('digit',bits,record['field'],record['curve'],coset_seed,positions,coefficients)
                    candidates.append((height,tie,value))
            candidates.sort()
            for _,_,value in candidates:
                drawn+=1;x=value%p
                if x in seen:continue
                seen.add(x);point=point_from_x(K,b,x)
                if point is not None:base.append(point)
                if len(base)==m:break
            if len(base)==m:break
        extra=dict(radix=radix,digit_candidates_drawn=drawn)
    else:raise ValueError(kind)
    assert base and (m is None or len(base)==m)
    stream.shuffle(base)
    return dict(kind=kind,base=base,setup_cpu=time.process_time()-started,extra=extra)

def uniform_targets(record,bases,coset_seed,n):
    p=record['p'];K=GF(p);stream=rng('targets',record['bits'],record['field'],record['curve'],coset_seed)
    excluded=set()
    for B in bases:
        for Q in B['base']:excluded.update([Q,N.neg(p,Q)])
    result=[];used=set()
    while len(result)<n:
        point=point_from_x(K,record['b'],stream.randrange(p))
        if point is None:continue
        if stream.randrange(2):point=N.neg(p,point)
        if point in excluded or point in used:continue
        result.append(point);used.add(point)
    return result,len(excluded)

def generic():
    curves=json.loads((OUT/'curves.json').read_text()); all_results=[]
    for record in curves:
      for seed in range(P['coset_seeds_per_curve']):
        coset=base_build(record,seed,'coset');m=len(coset['base'])
        bases=[coset]+[base_build(record,seed,kind,m) for kind in P['bases'][1:]]
        targets,excluded=uniform_targets(record,bases,seed,P['targets_per_panel'])
        order=list(range(4));rng('run_order',record['bits'],record['field'],record['curve'],seed).shuffle(order)
        for bi in order:
            B=bases[bi];base=B['base'];rank=Rank(m,record['r']);start=time.process_time()
            table=Join(record['p'],base);table_cpu=time.process_time()-start
            results=[];checkpoint=None
            threshold=min(16,max(1,m//4))
            for ti,target in enumerate(targets):
                before=time.process_time();decos=table.solve(target)
                gained=rank.cycles(record['p'],base,target,decos)
                elapsed=time.process_time()-before
                results.append(dict(target=target,decompositions=[list(t) for t in decos],count=len(decos),
                                    rank_gain=gained,cpu=elapsed,rank=len(rank.rows)))
                if checkpoint is None and len(rank.rows)>=threshold:
                    checkpoint=dict(rank=len(rank.rows),target_index=ti,
                                    cpu=B['setup_cpu']+table_cpu+sum(t['cpu'] for t in results))
            table.close()
            row=dict(**{k:record[k] for k in ['bits','field','curve','p','b','r']},coset_seed=seed,
                     kind=B['kind'],m=m,F=2*m,base=base,base_extra=B['extra'],
                     base_setup_cpu=B['setup_cpu'],pair_table_cpu=table_cpu,
                     pair_entries=2*m*(m-1),target_excluded_points=excluded,
                     target_results=results,independent_rows=rank.rows,rank=len(rank.rows),
                     total_cpu=B['setup_cpu']+table_cpu+sum(t['cpu'] for t in results),
                     checkpoint=checkpoint,rank_checkpoint=threshold)
            all_results.append(row)
            event('generic_case',bits=record['bits'],field=record['field'],curve=record['curve'],
                  seed=seed,kind=B['kind'],m=m,covered=sum(t['count']>0 for t in results),
                  rank=row['rank'],cpu=round(row['total_cpu'],4))
        write('generic.json',all_results)
    return all_results

class BudgetExpired(Exception):pass
def expired(signum,frame):raise BudgetExpired()

def supervise(search,cap):
    """Charge parent+worker CPU; kill native work using an external supervisor."""
    started=time.process_time();receiver,sender=Pipe(duplex=False);parent_pid=os.getpid()
    pid=os.fork()
    if pid==0:
        receiver.close()
        try:
            # Ensure a terminated supervisor cannot leave an orphan search.
            C.CDLL(None).prctl(1,signal.SIGKILL,0,0,0)
            if os.getppid()!=parent_pid:os._exit(128)
            hard=max(1,int(math.ceil(cap))+1)
            resource.setrlimit(resource.RLIMIT_CPU,(hard,hard))
            def progress(decompositions,calls):
                sender.send(('progress',dict(decompositions=decompositions,pair_calls=calls)))
            result=search(progress);sender.send(('done',result));sender.close();os._exit(0)
        except BaseException:
            try:sender.send(('error',traceback.format_exc()))
            finally:os._exit(1)
    sender.close();state=dict(decompositions=[],pair_calls=0);done=None;error=None;eof=False;killed=False;reaped=False
    def drain():
        nonlocal done,error,eof,state
        while not eof and receiver.poll():
            try:kind,value=receiver.recv()
            except EOFError:eof=True;break
            if kind=='progress':state=value
            elif kind=='done':done=value;state=value
            elif kind=='error':error=value
    try:
        while True:
            drain()
            waited,status,usage=os.wait4(pid,os.WNOHANG)
            if waited:reaped=True;break
            try:
                stat=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
                child_cpu=(int(stat[11])+int(stat[12]))/os.sysconf('SC_CLK_TCK')
            except FileNotFoundError:continue
            if child_cpu>=cap:
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
                waited,status,usage=os.wait4(pid,0);reaped=True;killed=True;break
            time.sleep(.002)
        drain()
    finally:
        if not reaped:
            try:os.kill(pid,signal.SIGKILL)
            except ProcessLookupError:pass
            os.wait4(pid,0)
        receiver.close()
    if error:raise RuntimeError(error)
    if done is None and not killed:
        if os.WIFSIGNALED(status) and os.WTERMSIG(status) in [signal.SIGKILL,signal.SIGXCPU]:killed=True
        else:raise RuntimeError(f'worker exited without a result, status={status}')
    child_cpu=usage.ru_utime+usage.ru_stime;parent_cpu=time.process_time()-started
    return dict(decompositions=state['decompositions'],pair_calls=state['pair_calls'],
                completed=bool(done and done['completed']),timeout=killed,
                cpu=child_cpu+parent_cpu,worker_cpu=child_cpu,wrapper_cpu=parent_cpu,
                cpu_cap=cap,cap_overshoot=max(0,child_cpu-cap))

class NormSolver:
    """Exact two-point elimination in Fp[x,y]/(x^d-gamma,y^2-f(x))."""
    def __init__(self,record,base,extra):
        self.p=record['p'];self.b=record['b'];self.base=base;self.extra=extra
        self.K=GF(self.p);self.R=PolynomialRing(self.K,'x');self.x=self.R.gen()
        self.L=self.x**extra['d']-extra['gamma']
        self.f=self.x**3-3*self.x+self.b
        self.lookup={}
        for i,Q in enumerate(base):self.lookup[Q]=i+1;self.lookup[N.neg(self.p,Q)]=-(i+1)
        self.signed=[]
        for i,Q in enumerate(base):self.signed.extend([(i+1,Q),(-(i+1),N.neg(self.p,Q))])
    def pairs(self,target):
        if target==INF:return []
        tx,ty=unpack(target);L=self.L;x=self.x;found=set()
        if L(tx)==0:
            L=L//(x-tx)
            for Q in [pack(tx,ty),N.neg(self.p,pack(tx,ty))]:
                a=self.lookup.get(Q);b=self.lookup.get(N.add(self.p,target,N.neg(self.p,Q)))
                if a and b and abs(a)!=abs(b):found.add(tuple(sorted((a,b),key=abs)))
        if L.degree()<=0:return sorted(found)
        f=self.f%L
        inverse=((x-tx)**2).inverse_mod(L)
        alpha=((self.f+ty*ty)*inverse-x-tx)%L
        beta=(2*ty*inverse)%L
        for _ in range(self.extra['k']):
            alpha,beta=(alpha*alpha+beta*beta*f)%L,(2*alpha*beta)%L
        alpha=(alpha-self.extra['gamma'])%L
        norm=(alpha*alpha-f*beta*beta)%L
        candidates=L.gcd(norm)
        for root,_multiplicity in candidates.roots():
            point=point_from_x(self.K,self.b,int(root))
            if point is None:continue
            for Q in [point,N.neg(self.p,point)]:
                a=self.lookup.get(Q);b=self.lookup.get(N.add(self.p,target,N.neg(self.p,Q)))
                if a and b and abs(a)!=abs(b):found.add(tuple(sorted((a,b),key=abs)))
        return sorted(found)
    def _search(self,target,limit,stop_first,progress):
        found=set();calls=0
        for a,Q in self.signed:
            pairs=self.pairs(N.add(self.p,target,N.neg(self.p,Q)));calls+=1
            if calls%16==0:progress(sorted(found),calls)
            for b,c in pairs:
                if len({abs(a),abs(b),abs(c)})<3:continue
                terms=tuple(sorted((a,b,c),key=abs))
                assert N.total(self.p,self.base,terms)==target
                if terms not in found:
                    found.add(terms);progress(sorted(found),calls)
                if (stop_first and found) or len(found)>=limit:
                    return dict(decompositions=sorted(found),completed=False,pair_calls=calls)
        return dict(decompositions=sorted(found),completed=True,pair_calls=calls)
    def solve(self,target,cap,limit=8,stop_first=False):
        return supervise(lambda progress:self._search(target,limit,stop_first,progress),cap)

def planted_targets(case,n):
    p=case['p'];base=case['base'];stream=rng('planted',case['bits'],case['field'],case['curve'],case['coset_seed'])
    excluded={Q for Q in base}|{N.neg(p,Q) for Q in base};out=[];used=set()
    while len(out)<n:
        terms=[(i+1)*stream.choice([-1,1]) for i in stream.sample(range(len(base)),3)]
        target=N.total(p,base,terms)
        if target==INF or target in excluded or target in used:continue
        out.append(dict(target=target,planted_terms=terms));used.add(target)
    return out

def algebraic():
    generic=json.loads((OUT/'generic.json').read_text());gates=[];fresh=[];continue_scaling=True
    for bits in P['field_bits']:
        if not continue_scaling:break
        selected=[c for c in generic if c['kind']=='coset' and c['bits']==bits and c['field'] in P['gate_fields']
                  and c['curve']==0 and c['coset_seed']==0]
        by_type={name:[0,0] for name in ['planted','known_positive_uniform','known_negative_uniform']}
        for case in selected:
            before=time.process_time();solver=NormSolver(case,case['base'],case['base_extra']);setup=time.process_time()-before
            samples=[dict(target=t['target'],type='planted') for t in planted_targets(case,8)]
            # Build the two conditional gate panels from a separate uniform stream.
            # A fixed batch of 64 can contain fewer than eight negative targets.
            label_start=time.process_time();oracle=Join(case['p'],case['base'])
            siblings=[c for c in generic if (c['bits'],c['field'],c['curve'],c['coset_seed'])==
                      (case['bits'],case['field'],case['curve'],case['coset_seed'])]
            excluded={Q for c in siblings for A in c['base'] for Q in [A,N.neg(case['p'],A)]}
            stream=rng('gate_uniform',bits,case['field']);K=GF(case['p']);seen=set();panels={True:[],False:[]}
            while min(map(len,panels.values()))<8:
                target=point_from_x(K,case['b'],stream.randrange(case['p']))
                if target is None:continue
                if stream.randrange(2):target=N.neg(case['p'],target)
                if target in excluded or target in seen:continue
                seen.add(target);positive=bool(oracle.solve(target))
                if len(panels[positive])<8:panels[positive].append(target)
            oracle.close();label_cpu=time.process_time()-label_start
            for positive,name in [(True,'known_positive_uniform'),(False,'known_negative_uniform')]:
                samples += [dict(target=target,type=name) for target in panels[positive]]
            outputs=[]
            for sample in samples:
                result=solver.solve(sample['target'],P['gate_cpu_seconds_per_target'][str(bits)],stop_first=True)
                positive=sample['type']!='known_negative_uniform'
                assert positive or not result['decompositions']
                success=bool(result['decompositions']) if positive else result['completed']
                by_type[sample['type']][0]+=int(success);by_type[sample['type']][1]+=1
                outputs.append(dict(**sample,**result,success=success))
            gates.append(dict(bits=bits,field=case['field'],curve=0,base_setup_cpu=case['base_setup_cpu'],
                              solver_setup_cpu=setup,oracle_label_cpu=label_cpu,oracle_uniform_draws=len(seen),outputs=outputs))
            event('algebraic_gate_case',bits=bits,field=case['field'],counts=by_type)
            write('gates.json',gates)
        pass_gate=(by_type['planted'][0]/by_type['planted'][1]>=.8 and
                   by_type['known_positive_uniform'][0]/by_type['known_positive_uniform'][1]>=.7)
        event('algebraic_gate_decision',bits=bits,passed=pass_gate,counts=by_type)
        if not pass_gate:continue_scaling=False;continue
        cases=[c for c in generic if c['kind']=='coset' and c['bits']==bits and c['field'] in P['fresh_algebraic_fields']
               and c['curve']==0 and c['coset_seed']==0]
        for case in cases:
            before=time.process_time();solver=NormSolver(case,case['base'],case['base_extra']);setup=time.process_time()-before
            rank=Rank(case['m'],case['r']);outputs=[]
            for target_record in case['target_results'][:P['fresh_algebraic_targets']]:
                result=solver.solve(target_record['target'],P['gate_cpu_seconds_per_target'][str(bits)])
                before=time.process_time();gained=rank.cycles(case['p'],case['base'],target_record['target'],result['decompositions'])
                verification_cpu=time.process_time()-before
                outputs.append(dict(target=target_record['target'],oracle_count=target_record['count'],
                                    **result,rank_gain=gained,rank=len(rank.rows),verification_cpu=verification_cpu))
            row=dict(bits=bits,field=case['field'],curve=0,coset_seed=0,p=case['p'],b=case['b'],r=case['r'],
                     m=case['m'],base=case['base'],base_extra=case['base_extra'],base_setup_cpu=case['base_setup_cpu'],
                     solver_setup_cpu=setup,outputs=outputs,rank=len(rank.rows),independent_rows=rank.rows,
                     total_cpu=case['base_setup_cpu']+setup+sum(t['cpu']+t['verification_cpu'] for t in outputs))
            fresh.append(row);write('algebraic_fresh.json',fresh)
            event('algebraic_fresh_case',bits=bits,field=case['field'],rank=row['rank'],
                  cpu=round(row['total_cpu'],4),timeouts=sum(t['timeout'] for t in outputs))
    write('gates.json',gates);write('algebraic_fresh.json',fresh)

def validate():
    checks={'native_additions':0,'native_scalar_identities':0,'small_complete_decompositions':0,
            'norm_pair_sets':0,'norm_triple_sets':0,'sage_rank_checks':0,'sage_independent_identities':0}
    stream=rng('validation')
    curves=json.loads((OUT/'curves.json').read_text())
    for record in curves:
        p=record['p'];K=GF(p);E=EllipticCurve(K,[-3,record['b']])
        points=[]
        while len(points)<20:
            Q=point_from_x(K,record['b'],stream.randrange(p))
            if Q is not None:points.append(Q)
        points.append(INF)
        for A,B in zip(points,points[1:]+points[:1]):
            A_s=E(0) if A==INF else E(unpack(A));B_s=E(0) if B==INF else E(unpack(B))
            for Z,expected in [(N.add(p,A,B),A_s+B_s),(N.add(p,A,A),2*A_s),
                               (N.add(p,A,N.neg(p,A)),E(0))]:
                actual=E(0) if Z==INF else E(unpack(Z));assert actual==expected
                checks['native_additions']+=1
        Q=E(unpack(points[0]));assert record['r']*Q==E(0);checks['native_scalar_identities']+=1
    # Independent tiny finite fields; exhaustively enumerate every eligible triple and target.
    for p,d in [(97,8),(193,8),(257,8),(577,16)]:
        K=GF(p)
        for b in range(1,p):
            try:E=EllipticCurve(K,[-3,b])
            except ArithmeticError:continue
            if E.discriminant()!=0 and ZZ(E.cardinality()).is_prime(proof=True) and int(E.cardinality())!=p:break
        record=dict(p=p,b=b,r=int(E.cardinality()))
        h=int(K.multiplicative_generator()**((p-1)//d));c=3
        base=[]
        for i in range(d):
            Q=point_from_x(K,b,c*pow(h,i,p)%p)
            if Q is not None:base.append(Q)
        if len(base)<3:continue
        extra=dict(k=int(math.log2(d)),d=d,gamma=pow(c,d,p),h=h,c=c)
        solver=NormSolver(record,base,extra);table=Join(p,base)
        universe=[Q for x in range(p) for Q in ([point_from_x(K,b,x)] if point_from_x(K,b,x) is not None else [])]
        universe=[Q for A in universe for Q in [A,N.neg(p,A)]]+[INF]
        exhaustive={target:set() for target in universe}
        for indices in itertools.combinations(range(len(base)),3):
            for signs in itertools.product([-1,1],repeat=3):
                terms=tuple(s*(i+1) for s,i in zip(signs,indices))
                sage_total=sum((s*E(unpack(base[i])) for s,i in zip(signs,indices)),E(0))
                target=INF if sage_total.is_zero() else pack(sage_total[0],sage_total[1])
                exhaustive[target].add(terms)
        for target in universe:
            expected_pairs=set()
            for i,j in itertools.combinations(range(len(base)),2):
                for si,sj in itertools.product([-1,1],repeat=2):
                    terms=(si*(i+1),sj*(j+1))
                    if N.total(p,base,terms)==target:expected_pairs.add(terms)
            assert set(solver.pairs(target))==expected_pairs,(p,target)
            checks['norm_pair_sets']+=1
            expected_triples=exhaustive[target]
            assert set(table.solve(target))==expected_triples
            checks['small_complete_decompositions']+=1
            result=solver.solve(target,10,limit=10000)
            assert result['completed'] and set(result['decompositions'])==expected_triples
            checks['norm_triple_sets']+=1
        table.close()
        event('validation_tiny_field',p=p,m=len(base),targets=len(universe))
    timeout_checks=[]
    for cap in [.05,.1]:
        def native_cpu_burn(progress):
            hashlib.pbkdf2_hmac('sha256',b'cpu-wrapper-test',b'public-salt',100000000)
            return dict(decompositions=[],pair_calls=0,completed=True)
        result=supervise(native_cpu_burn,cap)
        assert result['timeout'] and not result['completed']
        assert cap-.02<=result['worker_cpu']<=cap+.15,result
        timeout_checks.append(result)
    write('wrapper_validation.json',timeout_checks)
    write('validation.json',checks);event('validation_complete',checks=checks)

def verify_saved():
    checks=json.loads((OUT/'validation.json').read_text())
    groups=json.loads((OUT/'generic.json').read_text())+json.loads((OUT/'algebraic_fresh.json').read_text())
    for case in groups:
        E=EllipticCurve(GF(case['p']),[-3,case['b']]);base=[E(unpack(Q)) for Q in case['base']]
        rows=[]
        for row in case['independent_rows']:
            dense=[0]*case['m'];total=E(0)
            for i,v in row.items():dense[int(i)]=v;total+=int(v)*base[int(i)]
            assert total==E(0);rows.append(dense);checks['sage_independent_identities']+=1
        assert (int(matrix(GF(case['r']),rows).rank()) if rows else 0)==case['rank']
        checks['sage_rank_checks']+=1
    write('validation.json',checks);event('saved_results_verified',checks=checks)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('stage',choices=['prepare','validate','generic','algebraic','verify'])
    args=parser.parse_args();os.sched_setaffinity(0,{0})
    globals()[{'verify':'verify_saved'}.get(args.stage,args.stage)]()
if __name__=='__main__':main()
