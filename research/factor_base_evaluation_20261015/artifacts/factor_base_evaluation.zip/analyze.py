#!/usr/bin/env python3
"""Aggregate frozen experiment outputs; create CSV, HTML, PDF and plots."""
import csv, hashlib, html, json, math, os, platform, statistics, sys, zipfile
from pathlib import Path
import numpy as np
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parent/'.plot-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
KINDS=['coset','low_x','low_digit_weight','random']
LABEL={'coset':'Coset','low_x':'Low x','low_digit_weight':'Low digit weight','random':'Random'}
def read(name):return json.loads((OUT/name).read_text())
def save(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True))
def rate(rows):return sum(c['rank'] for c in rows)/sum(c['total_cpu'] for c in rows)
def interval_ratio(left,right,endpoint='throughput',iterations=10000,seed=20261015):
    fields=sorted({c['field'] for c in left})
    def totals(rows):
        result=[]
        for f in fields:
            cases=[c for c in rows if c['field']==f]
            if endpoint=='throughput':result.append([sum(c['rank'] for c in cases),sum(c['total_cpu'] for c in cases)])
            else:result.append([sum(t['count']>0 for c in cases for t in c['target_results']),sum(len(c['target_results']) for c in cases)])
        return np.array(result,dtype=float)
    a=totals(left);b=totals(right)
    generator=np.random.default_rng(seed);draws=generator.integers(0,len(fields),(iterations,len(fields)))
    sa=a[draws].sum(axis=1);sb=b[draws].sum(axis=1)
    numerator=sa[:,0]/sa[:,1];denominator=sb[:,0]/sb[:,1]
    values=numerator/denominator;values=values[np.isfinite(values)]
    point=(a[:,0].sum()/a[:,1].sum())/(b[:,0].sum()/b[:,1].sum())
    return dict(ratio=float(point),lower=float(np.quantile(values,.025)),upper=float(np.quantile(values,.975)),
                fields=len(fields),bootstrap_draws=iterations)

def summarize():
    generic=read('generic.json');fresh=read('algebraic_fresh.json');gates=read('gates.json')
    summary={'generic':[],'contrasts':[],'gates':[],'algebraic':[]}
    for bits in [16,20,24]:
        for kind in KINDS:
            cases=[c for c in generic if c['bits']==bits and c['kind']==kind]
            targets=[t for c in cases for t in c['target_results']]
            checkpoints=[c['checkpoint']['cpu'] for c in cases if c['checkpoint']]
            item=dict(bits=bits,kind=kind,cases=len(cases),fields=len({c['field'] for c in cases}),
                      m_min=min(c['m'] for c in cases),m_max=max(c['m'] for c in cases),
                      covered=sum(t['count']>0 for t in targets),targets=len(targets),
                      coverage=sum(t['count']>0 for t in targets)/len(targets),
                      decompositions=sum(t['count'] for t in targets),rank=sum(c['rank'] for c in cases),
                      total_cpu=sum(c['total_cpu'] for c in cases),rank_per_cpu=rate(cases),
                      base_cpu=sum(c['base_setup_cpu'] for c in cases),pair_cpu=sum(c['pair_table_cpu'] for c in cases),
                      search_verify_rank_cpu=sum(sum(t['cpu'] for t in c['target_results']) for c in cases),
                      saturated=sum(c['rank']==c['m']-1 for c in cases),
                      checkpoints_reached=len(checkpoints),median_checkpoint_cpu=statistics.median(checkpoints) if checkpoints else None)
            summary['generic'].append(item)
        coset=[c for c in generic if c['bits']==bits and c['kind']=='coset']
        for kind in KINDS[1:]:
            control=[c for c in generic if c['bits']==bits and c['kind']==kind]
            summary['contrasts'].append(dict(bits=bits,control=kind,
                                            throughput=interval_ratio(coset,control),coverage=interval_ratio(coset,control,'coverage')))
    for bits in sorted({c['bits'] for c in gates}):
        cases=[c for c in gates if c['bits']==bits];item={'bits':bits,'fields':len(cases)}
        for kind in ['planted','known_positive_uniform','known_negative_uniform']:
            attempts=[o for c in cases for o in c['outputs'] if o['type']==kind]
            item[kind]=dict(successes=sum(o['success'] for o in attempts),attempts=len(attempts),
                            timeouts=sum(o['timeout'] for o in attempts),cpu=sum(o['cpu'] for o in attempts))
        item['passed']=(item['planted']['successes']/item['planted']['attempts']>=.8 and
                        item['known_positive_uniform']['successes']/item['known_positive_uniform']['attempts']>=.7)
        summary['gates'].append(item)
    for bits in sorted({c['bits'] for c in fresh}):
        cases=[c for c in fresh if c['bits']==bits];controls=[]
        for case in cases:
            generic_case=next(c for c in generic if (c['bits'],c['field'],c['curve'],c['coset_seed'],c['kind'])==
                              (bits,case['field'],0,0,'coset'))
            ts=generic_case['target_results'][:16]
            controls.append(dict(field=case['field'],rank=ts[-1]['rank'],
                                 total_cpu=generic_case['base_setup_cpu']+generic_case['pair_table_cpu']+sum(t['cpu'] for t in ts)))
        attempts=[o for c in cases for o in c['outputs']]
        item=dict(bits=bits,fields=len(cases),attempts=len(attempts),
                  oracle_positive=sum(o['oracle_count']>0 for o in attempts),
                  found=sum(bool(o['decompositions']) for o in attempts),timeouts=sum(o['timeout'] for o in attempts),
                  completed=sum(o['completed'] and not o['timeout'] for o in attempts),rank=sum(c['rank'] for c in cases),
                  total_cpu=sum(c['total_cpu'] for c in cases),rank_per_cpu=rate(cases),
                  worker_cpu=sum(o['worker_cpu'] for o in attempts),wrapper_cpu=sum(o['wrapper_cpu'] for o in attempts),
                  max_worker_cap_overshoot=max(o['cap_overshoot'] for o in attempts),
                  generic_rank=sum(c['rank'] for c in controls),generic_cpu=sum(c['total_cpu'] for c in controls),
                  generic_rank_per_cpu=rate(controls),norm_over_join=interval_ratio(cases,controls))
        summary['algebraic'].append(item)
    save('summary.json',summary)
    with (OUT/'generic_summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(summary['generic'][0]));writer.writeheader();writer.writerows(summary['generic'])
    rows=[]
    for c in generic:
        rows.append(dict(bits=c['bits'],field=c['field'],curve=c['curve'],coset_seed=c['coset_seed'],kind=c['kind'],
                         p=c['p'],b=c['b'],r=c['r'],m=c['m'],covered=sum(t['count']>0 for t in c['target_results']),
                         targets=len(c['target_results']),rank=c['rank'],total_cpu=c['total_cpu'],
                         base_setup_cpu=c['base_setup_cpu'],pair_table_cpu=c['pair_table_cpu'],
                         rank_per_cpu=c['rank']/c['total_cpu']))
    with (OUT/'cases.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    return summary

def figures(summary):
    palette=['#1d6b73','#bf763b','#6675aa','#7f8b8c']
    plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'font.size':10})
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for j,kind in enumerate(KINDS):
        rows=[r for r in summary['generic'] if r['kind']==kind]
        x=np.arange(3)+(j-1.5)*.19
        axes[0].bar(x,[100*r['coverage'] for r in rows],width=.18,label=LABEL[kind],color=palette[j])
        axes[1].bar(x,[r['rank_per_cpu'] for r in rows],width=.18,color=palette[j])
    for ax in axes:ax.set_xticks(range(3),['16 bits','20 bits','24 bits']);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
    axes[0].set_ylabel('Targets with a three-point decomposition (%)')
    axes[1].set_ylabel('New independent rows / total CPU second')
    axes[0].set_title('Exact coverage on common uniform targets');axes[1].set_title('Exact-join prototype: setup included')
    fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=4,frameon=False)
    fig.tight_layout(rect=(0,.09,1,1));fig.savefig(OUT/'base_comparison.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7,3.3))
    for i,kind in enumerate(KINDS[1:]):
        c=next(c for c in summary['contrasts'] if c['bits']==24 and c['control']==kind)['throughput']
        ax.errorbar(c['ratio'],i,xerr=[[c['ratio']-c['lower']],[c['upper']-c['ratio']]],fmt='o',capsize=4,color='#1d6b73')
    ax.axvline(1,color='#888888',linewidth=1);ax.set_yticks(range(3),['Coset / '+LABEL[k] for k in KINDS[1:]])
    ax.set_xlabel('Independent-row throughput ratio; 95% whole-field bootstrap interval')
    ax.set_title('24-bit paired comparisons (8 independent fields)');ax.grid(axis='x',alpha=.15)
    fig.tight_layout();fig.savefig(OUT/'paired_intervals.png',dpi=180);plt.close(fig)

def fnum(x,n=3):return f'{x:,.{n}f}'
def fci(c):
    def fmt(x):return f'{x:.3g}' if abs(x)<.01 else f'{x:.3f}'
    return f"{fmt(c['ratio'])} ({fmt(c['lower'])}–{fmt(c['upper'])})"
def reports(summary):
    validation=read('validation.json');env=read('environment.json');curves=read('curves.json')
    positive_successes=[o for c in read('gates.json') for o in c['outputs']
                        if o['type']!='known_negative_uniform' and o['success']]
    inside_budget=sum(o['worker_cpu']<=o['cpu_cap'] for o in positive_successes)
    protocol=json.loads((ROOT/'protocol.json').read_text())
    s24=[r for r in summary['generic'] if r['bits']==24]
    contrast=next(c for c in summary['contrasts'] if c['bits']==24 and c['control']=='random')
    lines=[]
    lines.append(('title','Controlled evaluation of elliptic-curve factor bases'))
    lines.append(('p','Executed 15 October 2026. A bounded pilot of multiplicative-coset, low-x, low-digit-weight and random point bases.'))
    lines.append(('h','Outcome and practical interpretation'))
    c=contrast['throughput']
    verdict=('The 24-bit exact-join comparison does not establish a repeatable coset throughput advantage.' if c['lower']<=1<=c['upper'] else
             ('The coset base has higher prototype throughput in this cohort; independent scaling and a complete solver remain untested.' if c['lower']>1 else
              'The coset base has lower prototype throughput than random bases in this cohort.'))
    lines.append(('p',verdict+f" Coset/random independent-row throughput: {fci(c)}. Coverage ratio: {fci(contrast['coverage'])}. Intervals resample whole fields."))
    for a in summary['algebraic']:
        lines.append(('p',f"At {a['bits']} bits, the fresh algebraic norm solver produced {a['rank']} independent rows in {a['total_cpu']:.3f} CPU seconds; "
                      f"the exact join produced {a['generic_rank']} rows in {a['generic_cpu']:.3f} CPU seconds on the same targets and coset bases. "
                      f"Norm/join throughput ratio: {fci(a['norm_over_join'])}. Timeouts: {a['timeouts']}/{a['attempts']}."))
    failed=[g for g in summary['gates'] if not g['passed']]
    if failed:lines.append(('p',f"Algebraic scaling stopped at the {failed[0]['bits']}-bit gate as specified in the frozen protocol. Later sizes were not run for that solver."))
    lines.append(('h','1. Fields and curves'))
    lines.append(('p',f"Eight distinct fields at each of 16, 20 and 24 bits, with two independently seeded admitted curves per field: {len(curves)} curves total. "
                  "All use y²=x³−3x+b. Field and full group orders were proved prime; anomalous and supersingular cases, j=0 or 1728, and embedding degree at most 64 were excluded. "
                  "The target curve is fixed across all four base types within each comparison. Each curve has two predeclared coset/base-order seeds."))
    lines.append(('p','The multiplicative subgroup orders are 64, 256 and 512 respectively. The entire coset is retained; only coordinates lifting to actual curve points enter the point base. '
                  'The other three bases match its actual number m of canonical ± point classes, with both signs available. No production base is generated using known scalar labels.'))
    lines.append(('table',[['Field bits','Independent fields','Subgroup order d','Canonical base m range']]+[
        [str(bits),'8',str(2**protocol['subgroup_exponents'][str(bits)]),
         str(next(r for r in summary['generic'] if r['bits']==bits and r['kind']=='coset')['m_min'])+'–'+
         str(next(r for r in summary['generic'] if r['bits']==bits and r['kind']=='coset')['m_max'])] for bits in [16,20,24]]))
    lines.append(('h','2. Matched bases and exact relation supply'))
    lines.append(('p','Each panel uses 64 common uniform finite targets outside the union of all four signed bases. The exact native method stores all signed pair representations with distinct canonical indices, '
                  'then joins a third point of a different class. It records all decompositions. At most the first eight decompositions of a target supply homogeneous cycles, by subtracting the first from each other one. '
                  'Rank is over GF(r), with the same m fixed factor-base columns and no target columns.'))
    lines.append(('table',([['24-bit base','Coverage','Independent rank','Total CPU s','Rank / CPU s']]+[
        [LABEL[r['kind']],f"{r['covered']}/{r['targets']} ({100*r['coverage']:.1f}%)",str(r['rank']),fnum(r['total_cpu']),fnum(r['rank_per_cpu'],1)] for r in s24])))
    lines.append(('image','base_comparison.png'))
    lines.append(('table',[['24-bit paired ratio','Estimate (95% interval)']]+[
        ['Coset / '+LABEL[c['control']],fci(c['throughput'])] for c in summary['contrasts'] if c['bits']==24]))
    lines.append(('image','paired_intervals.png'))
    lines.append(('p','These are descriptive 95% field-cluster bootstrap intervals from 10,000 resamples, preserving curves, seeds and target pairing. The eight independent fields at a size do not support a precise 15% claim. '
                  'All runs include base construction, pair-table construction, unsuccessful target searches, point verification and incremental rank work. Curve admission and oracle labeling are research work, recorded separately. '
                  'Timing excludes JSON serialization and the separate independent Sage verification. Sage field contexts are warm within each process.'))
    lines.append(('p','For the fresh structured-solver comparison, both methods are charged the same previously measured construction time for their identical base; the structured solver also pays its separate polynomial setup and full supervised search cost.'))
    lines.append(('h','3. Structured solver gates and complete cost'))
    lines.append(('p','A separate solver uses the coset equation x^d=γ. For a proposed two-point target T=(u,v), write x(T−P)=A(x)+B(x)y, where y²=x³−3x+b. '
                  'Repeated squaring computes (A+By)^d−γ=D(x)+E(x)y modulo x^d−γ. Taking the quadratic-algebra norm gives D²−(x³−3x+b)E²; '
                  'a polynomial gcd restricts candidate x-coordinates. Actual point lifting, signs, exceptional denominators and distinct indices are checked exactly. '
                  'Three-point decomposition enumerates an outer signed point and applies this two-point solver. It uses no point-pair lookup table or oracle answers.'))
    gate_rows=[['Bits','Planted found','Known-positive found','Negative completed','Gate']]
    for g in summary['gates']:
        p=g['planted'];q=g['known_positive_uniform'];n=g['known_negative_uniform']
        gate_rows.append([str(g['bits']),f"{p['successes']}/{p['attempts']}",f"{q['successes']}/{q['attempts']}",
                          f"{n['successes']}/{n['attempts']}",'PASS' if g['passed'] else 'FAIL'])
    lines.append(('table',gate_rows))
    lines.append(('p','The gate uses two fields per size, with separate planted, oracle-positive uniform and oracle-negative uniform panels. It requires at least 80% planted success, 70% known-positive success, '
                  'and zero soundness failures. Per-target worker CPU budget targets are 0.25, 0.75 and 2 seconds. The fresh comparison uses the remaining six fields, one curve/base seed and 16 common uniform targets each. '
                  'Failures remain in the denominator. A timeout is an unresolved search, not a proof of absence.'))
    lines.append(('p','Gate positive/negative panels use a separate seeded uniform stream and exact existence labels; the fixed-input rule is recorded in gate_sampling_addendum.json. '
                  'This ensures eight targets of each label even when a 64-target batch contains too few negatives. Labeling work is separately recorded and never supplied to the structured solver. '
                  'The addendum preceded the solver gates and inspection of comparison outcomes; solver rules, caps and thresholds did not change.'))
    lines.append(('p','The initial SIGPROF timing attempt was discarded because Sage could defer the signal inside native routines. Its outputs and consumed CPU are retained under discarded_soft_timer_*; they enter no final comparison. '
                  'The final run uses a fork worker supervised through external CPU counters, streams verified partial results, reaps each worker and charges both worker and supervisor CPU. '
                  'Forced termination was checked inside a non-cooperative OpenSSL routine. External CPU monitoring has tick, polling and scheduling delays; every actual overshoot is recorded and charged. '
                  f"{inside_budget}/{len(positive_successes)} successful positive gate attempts finished within their target worker CPU budget. Fresh runs are compared using actual CPU, not nominal budgets; the observed overrun maxima are listed below. "
                  'The timing_wrapper_addendum.json records this correction; fields, targets, solver and thresholds were unchanged.'))
    if summary['algebraic']:
        lines.append(('table',[['Bits','Norm rows / CPU s','Join rows / CPU s','Norm / join ratio']]+[
            [str(a['bits']),f"{a['rank']} / {a['total_cpu']:.3f}",f"{a['generic_rank']} / {a['generic_cpu']:.3f}",fci(a['norm_over_join'])] for a in summary['algebraic']]))
        lines.append(('p','Fresh-run worker/supervisor CPU and maximum worker-budget overshoot: '+
                      '; '.join(f"{a['bits']} bits: {a['worker_cpu']:.3f}/{a['wrapper_cpu']:.3f} seconds, max overshoot {a['max_worker_cap_overshoot']:.3f} seconds" for a in summary['algebraic'])+'.'))
    lines.append(('h','Validation, scope and reproduction'))
    lines.append(('p',f"Independent checks: {validation['native_additions']} native point additions/doublings/negations against Sage; "
                  f"{validation['native_scalar_identities']} admitted-group order identities; {validation['norm_pair_sets']} complete tiny-field two-point solution sets; "
                  f"{validation['norm_triple_sets']} complete tiny-field three-point solution sets; {validation['sage_independent_identities']} saved independent-row identities; "
                  f"{validation['sage_rank_checks']} independent Sage matrix ranks. All passed."))
    lines.append(('p','The norm routine is a Sage polynomial prototype, while the exact join uses optimized native C point arithmetic. These timings compare the delivered implementations and do not prove an intrinsic complexity separation. '
                  'The norm method still enumerates an outer point for each three-point target; it does not evaluate every possible solver for low-degree-map bases. '
                  'Full rank may saturate on tiny curves; checkpoint costs and saturation counts are retained in the CSV. Subgroup order and decomposition intensity change between sizes, so these points do not fit an asymptotic exponent. '
                  'No point logarithms were recovered, no full index-calculus solve was timed, and these 16–24-bit results do not establish behavior at NIST sizes.'))
    lines.append(('p',f"Runtime: {env['sage']}; {env.get('cpu_model','CPU model unavailable')}, {env.get('architecture','')}; pinned CPU 0, offline container. Frozen protocol SHA-256: {env['protocol_sha256']}. "
                  'Exact p,b,r inputs, basis points, targets, decompositions, independent rows, failure records and source are included. See README.txt for commands and results/manifest.json for hashes.'))
    lines.append(('h','Primary references'))
    lines.append(('p','Petit, Kosters and Messeng (PKC 2016), Algebraic approaches for the elliptic curve discrete logarithm problem over prime fields, §§3.3–3.4: '
                  'https://people.maths.ox.ac.uk/petit/files/16PKC_primeECDLP.pdf'))
    lines.append(('p','Semaev (2004), Summation polynomials and the discrete logarithm problem in elliptic curves: https://eprint.iacr.org/2004/031. '
                  'The quadratic-algebra norm implementation in this experiment is an explicit candidate solver; the cited papers do not establish its measured performance.'))
    css='body{max-width:1080px;margin:40px auto;padding:0 24px;font:16px/1.55 system-ui;color:#18313c;background:#fbfaf6}h1{font-size:34px;line-height:1.15}h2{margin-top:32px}table{border-collapse:collapse;width:100%;font-size:14px;margin:24px 0}th,td{padding:10px 12px;border-bottom:1px solid #ccd5d4;text-align:left}th{background:#e6efed}img{width:100%;height:auto;margin:16px 0}p{overflow-wrap:anywhere}'
    chunks=['<!doctype html><html><head><meta charset="utf-8"><title>Factor-base evaluation</title><style>'+css+'</style></head><body>']
    styles=getSampleStyleSheet();styles['BodyText'].fontSize=9;styles['BodyText'].leading=13
    story=[]
    for kind,value in lines:
        if kind in ['title','h','p']:
            tag={'title':'h1','h':'h2','p':'p'}[kind];chunks.append(f'<{tag}>{html.escape(value)}</{tag}>')
            safe=html.escape(value).replace('²','<super>2</super>').replace('³','<super>3</super>')
            for old,new in [('−','-'),('–','-'),('γ','gamma'),('±','+/-'),('≤','<=')]:safe=safe.replace(old,new)
            story.append(Paragraph(safe,styles[{'title':'Title','h':'Heading2','p':'BodyText'}[kind]]));story.append(Spacer(1,8))
        elif kind=='table':
            chunks.append('<table>'+''.join('<tr>'+''.join(f'<{"th" if i==0 else "td"}>{html.escape(str(c))}</{"th" if i==0 else "td"}>' for c in row)+'</tr>' for i,row in enumerate(value))+'</table>')
            data=[[Paragraph(str(c).replace('–','-'),styles['BodyText']) for c in row] for row in value]
            table=Table(data,repeatRows=1,hAlign='LEFT');table.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6efed')),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#bccbca')),
                ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
            story.extend([table,Spacer(1,10)])
        elif kind=='image':
            chunks.append(f'<img src="{value}" alt="Factor-base comparison plot">')
            from PIL import Image as PILImage
            with PILImage.open(OUT/value) as im:w,h=im.size
            story.extend([Image(str(OUT/value),width=6.7*inch,height=6.7*inch*h/w),Spacer(1,10)])
    chunks.append('</body></html>');(OUT/'report.html').write_text('\n'.join(chunks))
    SimpleDocTemplate(str(OUT/'report.pdf'),pagesize=(8.5*inch,11*inch),leftMargin=.65*inch,rightMargin=.65*inch,topMargin=.6*inch,bottomMargin=.6*inch).build(story)

def package():
    files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in str(p) and '.plot-cache' not in p.parts and p.name not in ['manifest.json','factor_base_evaluation.zip','analysis.log'] and not p.name.endswith('.tmp')]
    manifest={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
    save('manifest.json',manifest)
    archive=ROOT/'factor_base_evaluation.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[OUT/'manifest.json']:z.write(p,str(p.relative_to(ROOT)))
    print(json.dumps({'report':str(OUT/'report.pdf'),'archive':str(archive),'archive_bytes':archive.stat().st_size,
                      'summary':read('summary.json')},indent=2))

if __name__=='__main__':
    summary=summarize();figures(summary);reports(summary);package()
