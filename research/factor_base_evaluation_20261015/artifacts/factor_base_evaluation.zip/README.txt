Controlled factor-base evaluation, 15 October 2026

The experiment evaluates all three requested steps: admitted prime-order curves;
four matched factor-base types; and verified decomposition, fixed-column rank and
total algorithm CPU cost. Read results/report.pdf or results/report.html first.

Frozen design: protocol.json, plus gate_sampling_addendum.json. The latter fixes
the separate conditional gate input stream before gate execution; it does not
change algorithms, caps, fields or success requirements. The results/environment.json file records its
SHA-256 before the experiment. The fixed seed is public and no production basis
is generated from known point logarithms.

timing_wrapper_addendum.json records the replacement of deferred SIGPROF timing
with supervised fork workers. CPU thresholds and mathematical algorithms did not
change. The first signal-timer attempt remains in discarded_soft_timer_* files
and is excluded from every final comparison. Worker and parent CPU are both
charged; actual kernel tick/polling overshoots are retained. The external wrapper
was tested against a non-cooperative OpenSSL CPU routine as well as complete
tiny-group solution sets.

Source:
  evaluate.py   Sage preparation, bases, native join wrapper, norm solver, checks
  native.c      complete signed pair-table/third-point join and point arithmetic
  analyze.py    field-cluster bootstrap summaries, CSVs, plots, PDF and HTML

Reproduce using SageMath 10.6 with gcc, in this directory:
  gcc -O3 -std=c11 -fPIC -shared native.c -o native.so
  sage -python evaluate.py prepare
  sage -python evaluate.py validate
  sage -python evaluate.py generic
  sage -python evaluate.py algebraic
  sage -python evaluate.py verify

Then run analyze.py with Python 3.12, NumPy, Matplotlib, ReportLab and Pillow:
  python analyze.py

The reference execution used the offline sagemath/sagemath:10.6 Docker image,
digest sha256:19995db6194f4a4bab18ce9a88556fd15b9ed5e916b4504fefe618a7796ddbdb,
with the experiment directory mounted at /work, CPU affinity pinned to core 0.
Internet access is unnecessary for the numerical runs.

Results include exact curves, all basis points, common uniform targets,
decompositions, all saved independent homogeneous rows, setup and search times,
solver timeouts, complete validation receipts and field-cluster bootstrap
intervals. CSV summaries are in results/cases.csv and generic_summary.csv.

Timing includes basis generation, required pair-table or polynomial setup,
failed searches, point verification and incremental rank. It excludes research
curve admission, oracle labeling, JSON serialization, and the separate final
independent Sage verification. Warm Sage finite-field contexts are shared within
the process. The native join and Sage polynomial solver are different prototype
implementations; their timing ratio is not an intrinsic complexity theorem.

The norm method is an algebraic two-point solver plus outer enumeration for
three points. It does not use the exact join's table or existence labels. Gates
test planted targets separately from oracle-positive uniform targets; fresh
uniform targets include all failures. Only differences between decompositions of
the same target generate rank, on fixed factor-base columns. New target columns
are never added.

This is a bounded 16/20/24-bit pilot. No logarithms are recovered and no
NIST-size or asymptotic claim follows. Details and limitations are in the report.

Primary construction reference:
  Petit, Kosters and Messeng, PKC 2016, sections 3.3-3.4
  https://people.maths.ox.ac.uk/petit/files/16PKC_primeECDLP.pdf
  Semaev, https://eprint.iacr.org/2004/031
