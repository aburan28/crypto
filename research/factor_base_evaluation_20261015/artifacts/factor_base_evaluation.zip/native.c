#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
#include <limits.h>

#define INF UINT64_MAX
typedef struct { uint64_t point; int32_t a, b; } Pair;
static int64_t mod(int64_t x, int64_t p) { x%=p; return x<0?x+p:x; }
static int64_t inv(int64_t a, int64_t p) {
    int64_t t=0, u=1, r=p, s=mod(a,p);
    while(s) {int64_t q=r/s, z=r-q*s; r=s;s=z;z=t-q*u;t=u;u=z;}
    return mod(t,p);
}
static uint64_t pack(int64_t x,int64_t y){return ((uint64_t)x<<32)|(uint32_t)y;}
uint64_t fb_neg(uint32_t p,uint64_t P){
    if(P==INF)return INF;
    uint32_t y=(uint32_t)P;
    return pack(P>>32,y?p-y:0);
}
uint64_t fb_add(uint32_t p,int32_t a,uint64_t P,uint64_t Q){
    if(P==INF)return Q;if(Q==INF)return P;
    int64_t x=P>>32,y=(uint32_t)P,u=Q>>32,v=(uint32_t)Q,s;
    if(x==u){if(mod(y+v,p)==0)return INF;s=mod(mod(3*x*x+a,p)*inv(2*y,p),p);}
    else s=mod((v-y)*inv(u-x,p),p);
    int64_t z=mod(s*s-x-u,p),w=mod(s*(x-z)-y,p);
    return pack(z,w);
}
static int compare(const void* A,const void* B){
    const Pair *a=A,*b=B;
    if(a->point!=b->point)return a->point<b->point?-1:1;
    if(a->a!=b->a)return a->a<b->a?-1:1;
    return (a->b>b->b)-(a->b<b->b);
}
Pair* fb_pairs(uint32_t p,int32_t a,const uint64_t* base,int32_t m,uint64_t* length){
    *length=(uint64_t)2*m*(m-1);
    Pair* pairs=malloc((*length)*sizeof(Pair));if(!pairs)return NULL;
    size_t pos=0;
    for(int32_t i=0;i<m;i++)for(int32_t j=i+1;j<m;j++)
      for(int si=-1;si<=1;si+=2)for(int sj=-1;sj<=1;sj+=2){
        uint64_t P=si==1?base[i]:fb_neg(p,base[i]);
        uint64_t Q=sj==1?base[j]:fb_neg(p,base[j]);
        pairs[pos++]=(Pair){fb_add(p,a,P,Q),si*(i+1),sj*(j+1)};
      }
    qsort(pairs,*length,sizeof(Pair),compare);return pairs;
}
void fb_free(void* ptr){free(ptr);}
uint64_t fb_decompose(uint32_t p,int32_t a,const uint64_t* base,int32_t m,
                     const Pair* pairs,uint64_t n,uint64_t target,int32_t* output,uint64_t capacity){
    uint64_t count=0;
    for(int32_t k=2;k<m;k++)for(int sk=-1;sk<=1;sk+=2){
        uint64_t third=sk==1?base[k]:fb_neg(p,base[k]);
        uint64_t needed=fb_add(p,a,target,fb_neg(p,third));
        uint64_t lo=0,hi=n;
        while(lo<hi){uint64_t mid=lo+(hi-lo)/2;if(pairs[mid].point<needed)lo=mid+1;else hi=mid;}
        for(uint64_t t=lo;t<n && pairs[t].point==needed;t++){
            int ia=abs(pairs[t].a)-1,ib=abs(pairs[t].b)-1;
            if(ia>=k||ib>=k)continue;
            if(count<capacity){output[3*count]=pairs[t].a;output[3*count+1]=pairs[t].b;output[3*count+2]=sk*(k+1);}
            count++;
        }
    }
    return count;
}
