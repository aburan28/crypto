python3 scripts/test_workflows_parse.py 
