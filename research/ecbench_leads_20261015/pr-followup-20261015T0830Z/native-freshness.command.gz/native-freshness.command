cargo +1.98.0 run --release --locked --manifest-path research/ecbench_open_questions_20261014/native-publish/Cargo.toml -- --check 
