python3 scripts/site/test_build.py -v 
