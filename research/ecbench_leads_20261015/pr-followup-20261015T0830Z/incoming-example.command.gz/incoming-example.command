python3 tools/isolated_bench.py busy -- cargo +1.98.0 test --release --example koblitz_orbit_dlp_fast_online
