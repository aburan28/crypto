# Endomorphism search

This package turns the decision tree into a runnable mathematical search. It
enumerates exact ring candidates, discovers explicit maps on small curves,
verifies their subgroup actions, and benchmarks scalar arithmetic. No third-party
public keys or secret scalars are required.

Python 3.10 or later is sufficient. There are no runtime dependencies and Sage
is not required. From this directory, run:

```bash
python -m endomorphism_search scan --discriminant=-619 --degree-bound 1000 --out results/minus-619-order.json
python -m endomorphism_search sweep --max-abs-discriminant 1000 --degree-bound 1000 --out results/order-sweep.json
python -m endomorphism_search probe --p 167 --a 25 --b 36 --benchmark --out results/curve-probe.json
python -m endomorphism_search demo --samples 1024 --repeats 9 --out results/demo.json
python -m unittest discover -s tests -v
```

Optional installation: `python -m pip install -e .` provides the equivalent
`endomorphism-search` command.

## Searches that run

1. **Exact norm search.** For a declared order of discriminant `D`, enumerate all
   non-scalar `a + b*omega` through the degree bound using integer square roots.
   Both signs and conjugates remain in the output. Each result includes its
   degree, trace, characteristic polynomial and enumeration certificate.
2. **Units and ideal classes.** Enumerate degree-one elements and primitive
   reduced binary quadratic forms. The latter give the proper class number.
   An ideal-class representative of leading coefficient 5 or 7 is not thereby
   a self-endomorphism of that degree.
3. **Explicit automorphisms.** Enumerate origin-preserving scaling maps on the
   actual short Weierstrass model, retaining the maps beyond identity and
   negation that are defined over its prime field.
4. **Rational self-isogenies.** Enumerate rational cyclic kernels of prime
   degrees 2, 3, 5, 7, 11 and 13. Build the Vélú quotient and search for an explicit
   isomorphism back to the starting curve. This is a depth-one search.
5. **Ring refinement from constructed maps.** For ordinary curves, enumerate
   conductors consistent with Frobenius. A constructed prime-degree
   endomorphism is non-scalar; its norm may exclude candidate orders. When
   exactly one order remains, the report records this elementary certificate.
6. **Monogenic Frobenius construction.** If the Frobenius discriminant is
   fundamental, the full ring is forced by the inclusion of orders. Construct
   `omega = pi - [c]` and verify its restriction to rational points. Full-field
   Frobenius itself acts as identity there.
7. **Actual scalar benchmarks.** Build the exact two-dimensional decomposition
   lattice, verify every scalar in the selected laboratory subgroup, and compare
   complete joint multiplication with binary and width-3/4 wNAF baselines.

The structural norm search works for any valid negative quadratic-order
discriminant within its work limits. Explicit curve experiments use prime
fields with `3 < p <= 16381`, short Weierstrass models, and an available prime
subgroup of order at least five. Extension-field maps, non-rational kernels,
longer isogeny paths and binary-field arithmetic require additional backends;
their absence from this bounded search is recorded rather than inferred.

## Meaning of the results

`scan` establishes exact facts about the **declared order**. It does not certify
that a named curve has that full endomorphism ring. `curve_binding` preserves
this distinction. `probe` computes the point count and verifies the curve type;
it binds a ring only when the implemented exact conditions determine it.

For `D = -619`, the package independently establishes:

- norm form `a*a + a*b + 155*b*b`;
- minimum non-scalar degree 155;
- two geometric units, `+1` and `-1`;
- five ideal classes, whose reduced forms have leading coefficients
  `1, 5, 5, 7, 7`.

The concrete laboratory model `y^2 = x^3 + 25*x + 36` over `F_167` has 161
points, trace 7 and Frobenius discriminant -619. Its full ring is therefore
certified by the maximal-order inclusion argument. The constructed degree-155
generator is `pi - [3]`; on its order-23 subgroup it acts as `[-2]`, with
eigenvalue 21. This is a small demonstration curve, separate from CryptoPro-B.

For the -7 example over `F_109`, the initially compatible discriminants are
`-7, -28, -112`. The constructed degree-2 maps eliminate the latter two orders.

`rho_structural` counts distinct generated subgroup actions, including
negation. Overlapping symmetries are not multiplied. This count alone does not
establish cheap representative selection or a measured rho gain. The code
records those obligations as unresolved.

Index-calculus results remain `unresolved`: this package supplies no verified
relation model or relation-solving backend. A ring or cover existence result
cannot fill those evidence fields.

## Bounds, verification and benchmarks

`scan` accepts `--max-work`, `--max-candidates`, and `--seconds`. `sweep` adds a
global time and order limit. `probe` limits rational kernel construction through
`--max-kernels` and `--seconds`. An incomplete search never certifies absence.
Map verification and scalar checks are separately bounded by the small-field
cap, not included in the kernel-search time limit.

Map reports distinguish algebraic construction conditions from finite checks.
Every rational image is checked on the curve, subgroup action is checked on
every subgroup element, and 64 additional homomorphism pairs are sampled.
Sample checks alone are not a geometric proof. The tests also reproduce a
published Sage Vélú example and exhaustively check a small quotient map.

Scalar timing includes decomposition, map evaluation, per-call precomputation,
and group arithmetic. One lattice setup is charged per sample-sized batch.
Map discovery and exhaustive verification are recorded separately. The fastest
of the three tested baseline implementations is used. Trials use identical
scalars and randomized arm ordering; raw samples and a paired bootstrap
interval are retained. A gain label requires the interval's lower endpoint to
exceed one. The interval does not account for every systematic timing bias.

The driver pins a CPU core when supported and records OS, CPU, Python, affinity,
NUMA-node information and unavailable memory-generation information. It does
not enforce NUMA memory placement. These are variable-time Python experiments,
with a single repeated base point and very small subgroups; the results neither
establish constant-time production performance nor extrapolate to 256-bit
curves. The run summary reports the observed gains and failures without
extrapolating beyond these workloads.

## Files and data integration

- `endomorphism_search/orders.py`: exact structural search and class forms.
- `endomorphism_search/curves.py`: point arithmetic, concrete map search,
  verification and ring refinement.
- `endomorphism_search/benchmarks.py`: exact decomposition and matched timings.
- `endomorphism_search/cli.py`: search, range sweep, curve probe and demo.
- `schemas/result.schema.json`: result-envelope schema.
- `results/minus-619-order.json`: executed structural result.
- `results/order-sweep.json`: executed bounded discriminant sweep.
- `results/demo.json`: actual maps, subgroup actions, hardware and timings.
- `results/run-summary.json`: compact summary of the executed run.
- `tests/test_search.py`: mathematical and implementation checks.

Search results have schema tag `endomorphism-search/v1`; the derived compact
summary uses `endomorphism-search-summary/v1`. Curve records include the
field, model, coefficients and a model identifier. Map records include their
family, construction parameters, geometric degree and subgroup eigenvalue.
Keep these identifiers and verification scope when importing the JSON into a
curve catalog; do not substitute a model identifier for an existing catalog's
canonical curve identity. `decision_tree` contains the machine-readable leaves
derived from the recorded evidence, including pending benchmark obligations.

## Primary references

- [Sutherland, ordinary curves and the conductor inclusions](https://math.mit.edu/classes/18.783/2023/LectureNotes13.pdf).
- [Sutherland, norm and trace of endomorphisms](https://math.mit.edu/classes/18.783/2013/LectureNotes14.pdf).
- [Bisson–Sutherland, computing and certifying ordinary endomorphism rings](https://arxiv.org/abs/0902.4670).
- [Sage reference: Vélú construction and the degree-7 F_11 example used by the tests](https://doc.sagemath.org/html/en/reference/arithmetic_curves/sage/schemes/elliptic_curves/ell_curve_isogeny.html).
- [Birkner–Longa–Sica, GLV decomposition](https://arxiv.org/abs/1106.5149).

The implementation is self-contained; the references describe the mathematical
methods rather than a software dependency.
