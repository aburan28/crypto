import unittest
import json
import subprocess
import sys
from math import isqrt

from endomorphism_search.benchmarks import joint_multiply, reduced_lattice, split_scalar
from endomorphism_search.curves import Curve, probe_curve, subgroup_symmetries, velu_map
from endomorphism_search.cli import assess_curve
from endomorphism_search.orders import QuadraticOrder, fundamental_decomposition, reduced_forms, scan_order


class OrderTests(unittest.TestCase):
    def test_degree_619_and_class_graph_distinction(self):
        result = scan_order(-619, 1000)
        self.assertEqual(result['order']['minimum_non_scalar_degree'], 155)
        self.assertEqual(result['order']['geometric_unit_count'], 2)
        self.assertEqual(result['order']['class_forms']['class_number'], 5)
        self.assertEqual(sorted(form['a'] for form in result['order']['class_forms']['forms']), [1, 5, 5, 7, 7])
        self.assertFalse(any(item['degree'] in (5, 7) for item in result['norm_search']['candidates']))
        self.assertTrue(result['curve_binding']['status'] == 'not_bound_to_a_curve')

    def test_enumeration_against_independent_rectangle(self):
        for discriminant in (-3, -4, -7, -8, -11, -12, -16, -27, -619):
            order = QuadraticOrder(discriminant)
            for bound in (1, 2, 10, 25, 155):
                result = order.enumerate(bound)
                radius = 2*isqrt(bound)+2
                expected = {(a, b, order.norm(a, b)) for a in range(-radius, radius+1)
                            for b in range(-radius, radius+1) if b and 0 < order.norm(a, b) <= bound}
                observed = {(item['a'], item['b'], item['degree']) for item in result['candidates']}
                self.assertEqual(expected, observed, (discriminant, bound))
                self.assertEqual(result['status'], 'complete')

    def test_nonmaximal_order_does_not_inherit_extra_units(self):
        self.assertEqual(scan_order(-3)['order']['geometric_unit_count'], 6)
        self.assertEqual(scan_order(-4)['order']['geometric_unit_count'], 4)
        self.assertEqual(scan_order(-12)['order']['geometric_unit_count'], 2)
        self.assertEqual(scan_order(-16)['order']['geometric_unit_count'], 2)

    def test_incomplete_search_cannot_be_absence(self):
        result = scan_order(-3, 10000, max_work=1)
        self.assertEqual(result['norm_search']['status'], 'incomplete')
        self.assertEqual(result['decision_tree']['scalar_multiplication']['status'], 'search_incomplete')
        self.assertIsNone(reduced_forms(-619, max_work=1)['class_number'])

    def test_fundamental_decomposition(self):
        for d, expected in [(-619, (-619, 1)), (-112, (-7, 4)), (-12, (-3, 2)), (-16, (-4, 2)), (-27, (-3, 3))]:
            self.assertEqual(fundamental_decomposition(d), expected)

    def test_invalid_inputs(self):
        for d in (0, 1, -1, -2, -5):
            with self.assertRaises(ValueError):
                QuadraticOrder(d)
        with self.assertRaises(ValueError):
            QuadraticOrder(-3).enumerate(0)


class CurveTests(unittest.TestCase):
    def test_group_law_exhaustive_small_curve(self):
        curve = Curve(17, 2, 2)
        points = curve.points()
        self.assertEqual(len(points), 19)
        for p in points:
            self.assertIsNone(curve.add(p, curve.neg(p)))
            self.assertIsNone(curve.mul(19, p))
            for q in points:
                self.assertTrue(curve.contains(curve.add(p, q)))
                for r in points:
                    self.assertEqual(curve.add(curve.add(p, q), r), curve.add(p, curve.add(q, r)))

    def test_velu_isogeny_with_exhaustive_homomorphism(self):
        curve = Curve(29, 4, 22)
        points = curve.points()
        generator = next(point for point in points[1:] if curve.mul(2, point) is None)
        target, operation = velu_map(curve, [None, generator])
        self.assertEqual(len(target.points()), len(points))
        self.assertEqual(sum(operation(point) is None for point in points), 2)
        for p in points:
            self.assertTrue(target.contains(operation(p)))
            for q in points:
                self.assertEqual(operation(curve.add(p, q)), target.add(operation(p), operation(q)))

    def test_extra_map_is_actually_constructed(self):
        report, maps, prime, generator = probe_curve(Curve(29, 16, 2))
        self.assertTrue(any(candidate.family == 'rational_velu_self_isogeny' and candidate.degree == 2 for candidate in maps))
        self.assertTrue(all(candidate.verification['subgroup_action_exhaustive'] for candidate in maps))
        self.assertIsNotNone(generator)
        self.assertEqual(report['ring_binding']['candidate_discriminants_before_map_search'], [-7, -28, -112])
        self.assertEqual(report['ring_binding']['candidate_discriminants_after_map_search'], [-7])
        self.assertEqual(report['ring_binding']['full_ring_discriminant'], -7)

    def test_unresolved_ring_does_not_become_maximal_without_evidence(self):
        report, _, _, _ = probe_curve(Curve(29, 16, 2), degree_bound=1)
        self.assertEqual(report['ring_binding']['status'], 'unresolved')
        self.assertIsNone(report['ring_binding']['full_ring_discriminant'])
        self.assertEqual(report['explicit_map_search']['maps_constructed_and_verified'], 0)

    def test_tree_does_not_promote_unmeasured_maps_to_speedups(self):
        report, _, _, _ = probe_curve(Curve(167, 25, 36))
        decision = assess_curve(report)
        self.assertEqual(decision['scalar_multiplication']['status'], 'verified_map_candidates')
        self.assertIsNone(decision['scalar_multiplication']['measured_gain_scope'])
        self.assertEqual(decision['rho']['extra_geometric_units'], 'excluded_for_certified_ring')
        self.assertEqual(decision['rho']['measured_gain'], 'unresolved')
        self.assertEqual(decision['index_calculus']['status'], 'unresolved')

    def test_referenced_sage_velu_example(self):
        curve = Curve(11, 1, 1)
        generator = (6, 5)
        kernel = [curve.mul(index, generator) for index in range(7)]
        target, operation = velu_map(curve, kernel)
        self.assertEqual((target.a, target.b), (7, 8))
        self.assertEqual(operation((4, 5)), (10, 0))

    def test_cm619_curve_ring_and_frobenius_action(self):
        report, maps, prime, generator = probe_curve(Curve(167, 25, 36))
        self.assertEqual(report['trace'], 7)
        self.assertEqual(prime, 23)
        self.assertEqual(report['ring_binding']['full_ring_discriminant'], -619)
        self.assertEqual(report['ring_binding']['frobenius_conductor'], 1)
        omega = next(candidate for candidate in maps if candidate.family == 'frobenius_minus_scalar')
        self.assertEqual(omega.degree, 155)
        self.assertEqual(omega.lambda_value, 21)
        self.assertEqual(omega.evaluate(generator), Curve(167, 25, 36).mul(-2, generator))
        self.assertEqual(report['full_field_frobenius_action']['eigenvalue'], 1)

    def test_orbit_overlap_not_multiplied(self):
        report = subgroup_symmetries([2, 4, 16], 31)
        self.assertEqual(report['distinct_action_count_including_negation'], 10)
        self.assertEqual(subgroup_symmetries([0, 1, 30], 31)['distinct_action_count_including_negation'], 2)

    def test_exact_scalar_split_including_hexagonal_ties(self):
        for prime in (7, 13, 19, 23, 31, 109):
            for value in range(prime):
                lattice = reduced_lattice(prime, value)
                for scalar in range(-prime, 2*prime):
                    first, second = split_scalar(scalar, prime, value, lattice)
                    self.assertEqual((first+value*second-scalar) % prime, 0)

    def test_joint_multiplication_signed(self):
        curve = Curve(17, 2, 2)
        p = curve.points()[1]
        q = curve.mul(7, p)
        for first in range(-10, 11):
            for second in range(-10, 11):
                self.assertEqual(joint_multiply(curve, first, p, second, q), curve.add(curve.mul(first, p), curve.mul(second, q)))


class CommandLineTests(unittest.TestCase):
    def test_scan_preserves_conditional_curve_binding(self):
        process = subprocess.run([sys.executable, '-m', 'endomorphism_search', 'scan',
                                  '--discriminant=-619', '--degree-bound', '154'], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stderr)
        result = json.loads(process.stdout)
        self.assertEqual(result['norm_search']['candidate_count'], 0)
        self.assertEqual(result['order']['minimum_non_scalar_degree'], 155)
        self.assertEqual(result['curve_binding']['status'], 'not_bound_to_a_curve')

    def test_partial_sweep_is_not_complete_range(self):
        process = subprocess.run([sys.executable, '-m', 'endomorphism_search', 'sweep',
                                  '--max-abs-discriminant', '1000', '--max-orders', '1'], capture_output=True, text=True)
        self.assertEqual(process.returncode, 0, process.stderr)
        result = json.loads(process.stdout)
        self.assertEqual(result['orders_scanned'], 1)
        self.assertEqual(result['status'], 'incomplete_range')
        self.assertEqual(result['stop_reason'], 'order_limit')

    def test_invalid_discriminant_has_no_result(self):
        process = subprocess.run([sys.executable, '-m', 'endomorphism_search', 'scan',
                                  '--discriminant=-5'], capture_output=True, text=True)
        self.assertNotEqual(process.returncode, 0)
        self.assertEqual(process.stdout, '')


if __name__ == '__main__':
    unittest.main()
