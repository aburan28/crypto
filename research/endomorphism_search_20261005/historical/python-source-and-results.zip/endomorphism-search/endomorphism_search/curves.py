"""Explicit small-prime-field laboratory, including rational Vélú maps.

The point enumeration cap is deliberate: finite exhaustive checks are feasible
here and are reported separately from the algebraic conditions of construction.
"""

from dataclasses import dataclass
from math import isqrt
from random import Random
from time import perf_counter
from typing import Callable

from .orders import factor_small, fundamental_decomposition, is_prime_small, scan_order


Point = tuple[int, int] | None
MAX_PRIME = 16381


@dataclass(frozen=True)
class Curve:
    p: int
    a: int
    b: int

    def __post_init__(self) -> None:
        if self.p <= 3 or self.p > MAX_PRIME or not is_prime_small(self.p):
            raise ValueError(f"explicit laboratory curves require a prime 3 < p <= {MAX_PRIME}")
        object.__setattr__(self, "a", self.a % self.p)
        object.__setattr__(self, "b", self.b % self.p)
        if (4 * self.a**3 + 27 * self.b**2) % self.p == 0:
            raise ValueError("singular curve")

    def contains(self, point: Point) -> bool:
        if point is None:
            return True
        x, y = point
        return 0 <= x < self.p and 0 <= y < self.p and (y*y-x*x*x-self.a*x-self.b) % self.p == 0

    def neg(self, point: Point) -> Point:
        return None if point is None else (point[0], -point[1] % self.p)

    def add(self, left: Point, right: Point) -> Point:
        if left is None:
            return right
        if right is None:
            return left
        x1, y1 = left
        x2, y2 = right
        if x1 == x2:
            if (y1 + y2) % self.p == 0:
                return None
            slope = (3*x1*x1+self.a) * pow(2*y1, -1, self.p) % self.p
        else:
            slope = (y2-y1) * pow(x2-x1, -1, self.p) % self.p
        x3 = (slope*slope-x1-x2) % self.p
        return x3, (slope*(x1-x3)-y1) % self.p

    def mul(self, scalar: int, point: Point) -> Point:
        if scalar < 0:
            return self.mul(-scalar, self.neg(point))
        result = None
        for index in range(scalar.bit_length()-1, -1, -1):
            result = self.add(result, result)
            if (scalar >> index) & 1:
                result = self.add(result, point)
        return result

    def wnaf_mul(self, scalar: int, point: Point, width: int) -> Point:
        if scalar < 0:
            return self.wnaf_mul(-scalar, self.neg(point), width)
        if scalar == 0 or point is None:
            return None
        twice = self.add(point, point)
        table = {1: point}
        for odd in range(3, 1 << (width-1), 2):
            table[odd] = self.add(table[odd-2], twice)
        digits = []
        value = scalar
        while value:
            digit = 0
            if value & 1:
                digit = value % (1 << width)
                if digit >= 1 << (width-1):
                    digit -= 1 << width
                value -= digit
            digits.append(digit)
            value //= 2
        result = None
        for digit in reversed(digits):
            result = self.add(result, result)
            if digit:
                result = self.add(result, table[digit] if digit > 0 else self.neg(table[-digit]))
        return result

    def points(self) -> list[Point]:
        squares: dict[int, list[int]] = {}
        for y in range(self.p):
            squares.setdefault(y*y % self.p, []).append(y)
        return [None] + [(x, y) for x in range(self.p) for y in squares.get((x*x*x+self.a*x+self.b) % self.p, [])]

    def record(self) -> dict:
        # Field, equation and model are in the identifier. Named aliases stay separate.
        return {"field": {"characteristic": self.p, "extension_degree": 1, "size": self.p},
                "model": "short_weierstrass", "a": self.a, "b": self.b,
                "curve_id": f"ec:fp:{self.p}:sw:{self.a}:{self.b}"}


def prime_subgroup(curve: Curve, points: list[Point]) -> tuple[int, Point]:
    total = len(points)
    factors = factor_small(total)
    for prime in sorted(factors, reverse=True):
        if prime < 5:
            continue
        for point in points[1:]:
            order = total
            for divisor in factors:
                while order % divisor == 0 and curve.mul(order//divisor, point) is None:
                    order //= divisor
            if order % prime:
                continue
            generator = curve.mul(order//prime, point)
            if generator is not None and curve.mul(prime, generator) is None:
                return prime, generator
    raise ValueError("no nontrivial laboratory prime subgroup of order >= 5")


def roots_mod_prime(trace: int, degree: int, prime: int) -> list[int]:
    # Bounded laboratory polynomial-root enumeration, never a point-log search.
    return [value for value in range(prime) if (value*value-trace*value+degree) % prime == 0]


@dataclass
class MapCandidate:
    identifier: str
    family: str
    degree: int
    evaluate: Callable[[Point], Point]
    construction: dict
    trace_candidates: list[int]
    lambda_value: int | None = None
    verification: dict | None = None

    def record(self) -> dict:
        return {"map_id": self.identifier, "family": self.family, "geometric_degree": self.degree,
                "construction": self.construction, "trace_candidates": self.trace_candidates,
                "subgroup_eigenvalue": self.lambda_value, "verification": self.verification}


def scaling_maps(curve: Curve) -> list[MapCandidate]:
    maps = []
    for scale in range(1, curve.p):
        if scale in (1, curve.p-1):
            continue
        if (pow(scale, 4, curve.p)-1)*curve.a % curve.p or (pow(scale, 6, curve.p)-1)*curve.b % curve.p:
            continue
        x_scale, y_scale = pow(scale, 2, curve.p), pow(scale, 3, curve.p)
        value, unit_order = scale, 1
        while value != 1:
            value = value * scale % curve.p
            unit_order += 1
        trace = {3: -1, 4: 0, 6: 1}[unit_order]

        def evaluate(point, xs=x_scale, ys=y_scale):
            return None if point is None else (xs*point[0] % curve.p, ys*point[1] % curve.p)

        maps.append(MapCandidate(f"scale:{scale}", "scaling_automorphism", 1, evaluate,
                                 {"scale": scale, "x_scale": x_scale, "y_scale": y_scale,
                                  "unit_order": unit_order, "algebraic_conditions_checked": True}, [trace]))
    return maps


def velu_map(curve: Curve, kernel: list[Point]) -> tuple[Curve, Callable[[Point], Point]]:
    finite_kernel = [point for point in kernel if point is not None]
    if not finite_kernel or len(set(kernel)) != len(kernel) or None not in kernel:
        raise ValueError("kernel must contain distinct points and the identity")
    if any(not curve.contains(point) for point in finite_kernel):
        raise ValueError("kernel point is not on the curve")
    kernel_set = set(kernel)
    # Check closure, not merely the number of points.
    if any(curve.add(left, right) not in kernel_set for left in kernel for right in kernel):
        raise ValueError("kernel is not a subgroup")
    t = sum(3*point[0]**2+curve.a for point in finite_kernel)
    w = sum(5*point[0]**3+3*curve.a*point[0]+2*curve.b for point in finite_kernel)
    codomain = Curve(curve.p, curve.a-5*t, curve.b-7*w)

    def evaluate(point: Point) -> Point:
        if point in kernel_set:
            return None
        x, y = point
        for kernel_point in finite_kernel:
            translated = curve.add(point, kernel_point)
            if translated is None:
                raise ArithmeticError("unexpected pole outside the kernel")
            x += translated[0]-kernel_point[0]
            y += translated[1]-kernel_point[1]
        return x % curve.p, y % curve.p

    return codomain, evaluate


def rational_self_isogenies(
    curve: Curve, points: list[Point], primes=(2, 3, 5, 7, 11, 13),
    *, max_kernels: int = 32, seconds: float = 5.0,
) -> tuple[list[MapCandidate], dict]:
    if max_kernels < 1 or seconds <= 0:
        raise ValueError("isogeny search resource bounds must be positive")
    start = perf_counter()
    maps, seen = [], set()
    attempted = 0
    stop = None
    for degree in primes:
        if not is_prime_small(degree) or degree > 13 or degree < 2:
            raise ValueError("rational isogeny laboratory supports prime degrees 2..13")
        if len(points) % degree:
            continue
        for point in points[1:]:
            if perf_counter()-start >= seconds:
                stop = "time_limit"
                break
            if curve.mul(degree, point) is not None:
                continue
            kernel = [curve.mul(index, point) for index in range(degree)]
            key = tuple(sorted(item for item in kernel if item is not None))
            if key in seen:
                continue
            if attempted >= max_kernels:
                stop = "kernel_limit"
                break
            seen.add(key)
            attempted += 1
            codomain, quotient = velu_map(curve, kernel)
            for scale in range(1, curve.p):
                if pow(scale, 4, curve.p)*codomain.a % curve.p != curve.a:
                    continue
                if pow(scale, 6, curve.p)*codomain.b % curve.p != curve.b:
                    continue
                xs, ys = pow(scale, 2, curve.p), pow(scale, 3, curve.p)

                def evaluate(point, quotient=quotient, xs=xs, ys=ys):
                    image = quotient(point)
                    return None if image is None else (xs*image[0] % curve.p, ys*image[1] % curve.p)

                maps.append(MapCandidate(f"velu:{degree}:{attempted}:{scale}", "rational_velu_self_isogeny", degree,
                                         evaluate, {"kernel": kernel, "intermediate_curve": codomain.record(),
                                                    "return_isomorphism_scale": scale, "algebraic_conditions_checked": True},
                                         list(range(-isqrt(4*degree), isqrt(4*degree)+1))))
        if stop:
            break
    return maps, {"status": "incomplete" if stop else "complete_for_declared_family", "stop_reason": stop,
                  "prime_degrees": list(primes), "rational_kernels_only": True, "path_depth": 1,
                  "kernels_examined": attempted, "elapsed_seconds": perf_counter()-start,
                  "unsearched_families": ["non-rational kernels", "longer isogeny paths", "extension-field maps"]}


def verify_map(curve: Curve, points: list[Point], subgroup_order: int, generator: Point, candidate: MapCandidate) -> dict:
    image = candidate.evaluate(generator)
    matches: dict[int, set[int]] = {}
    for trace in candidate.trace_candidates:
        for value in roots_mod_prime(trace, candidate.degree, subgroup_order):
            if curve.mul(value, generator) == image:
                matches.setdefault(value, set()).add(trace)
    if len(matches) == 1:
        candidate.lambda_value = next(iter(matches))
        candidate.trace_candidates = sorted(matches[candidate.lambda_value])
    on_curve = all(curve.contains(candidate.evaluate(point)) for point in points)
    identity = candidate.evaluate(None) is None
    rng = Random(203)
    pairs = [(rng.choice(points), rng.choice(points)) for _ in range(64)]
    homomorphism = all(candidate.evaluate(curve.add(left, right)) == curve.add(candidate.evaluate(left), candidate.evaluate(right))
                       for left, right in pairs)
    subgroup = candidate.lambda_value is not None and all(
        candidate.evaluate(curve.mul(index, generator)) == curve.mul(index*candidate.lambda_value, generator)
        for index in range(subgroup_order))
    candidate.verification = {
        "algebraic_construction_conditions_checked": candidate.construction["algebraic_conditions_checked"],
        "all_rational_images_on_curve": on_curve, "rational_points_checked": len(points),
        "identity_preserved": identity, "sample_homomorphism_checks": len(pairs),
        "sample_homomorphism_checks_passed": homomorphism, "subgroup_action_exhaustive": subgroup,
        "subgroup_elements_checked": subgroup_order,
        "verification_scope": "construction_conditions_and_rational_laboratory_points; samples_are_not_a_geometric_proof",
    }
    if not (on_curve and identity and homomorphism and subgroup):
        raise ArithmeticError(f"map verification failed: {candidate.identifier}")
    return candidate.verification


def subgroup_action_order(value: int, prime: int) -> int | None:
    value %= prime
    if value == 0:
        return None
    order = prime-1
    for divisor in factor_small(order):
        while order % divisor == 0 and pow(value, order//divisor, prime) == 1:
            order //= divisor
    return order


def subgroup_symmetries(values: list[int], prime: int) -> dict:
    # Enumerate the actual generated action subgroup, retaining overlaps exactly.
    generators = sorted({prime-1, *(value % prime for value in values if value % prime)})
    group, frontier = {1}, [1]
    while frontier:
        element = frontier.pop()
        for generator in generators:
            product = element*generator % prime
            if product not in group:
                group.add(product)
                frontier.append(product)
    return {"distinct_action_count_including_negation": len(group), "baseline_action_count": 2,
            "generators": generators, "measured_rho_speedup": "unresolved",
            "orbit_canonicalization_cost": "unmeasured"}


def probe_curve(curve: Curve, degree_bound=1000, *, max_kernels=32, seconds=5.0) -> tuple[dict, list[MapCandidate], int, Point]:
    if degree_bound < 1:
        raise ValueError("degree bound must be positive")
    points = curve.points()
    trace = curve.p+1-len(points)
    prime, generator = prime_subgroup(curve, points)
    report = {"schema": "endomorphism-search/v1", "curve": curve.record(),
              "point_count": len(points), "trace": trace, "ordinary": trace % curve.p != 0,
              "subgroup": {"order": prime, "cofactor": len(points)//prime, "generator": generator},
              "full_field_frobenius_action": {"eigenvalue": 1, "additional_orbit_gain": False}}
    candidates = scaling_maps(curve)
    full_ring = None
    conductor = None
    if report["ordinary"]:
        fundamental, conductor = fundamental_decomposition(trace*trace-4*curve.p)
        if curve.a == 0:
            full_ring, reason = -3, "ordinary_j0_has_primitive_cube_root_unit"
        elif curve.b == 0:
            full_ring, reason = -4, "ordinary_j1728_has_primitive_fourth_root_unit"
        elif conductor == 1:
            full_ring, reason = fundamental, "fundamental_frobenius_discriminant_forces_maximal_order"
        else:
            reason = "conductor_of_full_ring_unresolved"
        report["ring_binding"] = {"status": "certified_by_exact_elementary_conditions" if full_ring else "unresolved",
                                  "frobenius_discriminant": trace*trace-4*curve.p,
                                  "fundamental_discriminant": fundamental, "frobenius_conductor": conductor,
                                  "full_ring_discriminant": full_ring, "reason": reason}
        divisors = [divisor for divisor in range(1, conductor+1) if conductor % divisor == 0]
        report["ring_binding"]["candidate_discriminants_before_map_search"] = [fundamental*divisor*divisor for divisor in divisors]
        if full_ring is not None:
            report["order_search"] = scan_order(full_ring, degree_bound)
            report["order_search"]["curve_binding"] = report["ring_binding"]
        # If Z[pi] is already maximal, an explicit generator is pi - [c].
        # Its restriction to F_p points is [1-c], not a new geometric unit.
        if conductor == 1:
            parity = fundamental % 2
            c = (trace-parity)//2
            degree = (parity*parity-fundamental)//4

            def evaluate(point, c=c):
                return curve.add(point, curve.neg(curve.mul(c, point)))

            candidates.append(MapCandidate("frobenius-ring-generator", "frobenius_minus_scalar", degree, evaluate,
                                           {"formula": "omega=pi-[c]", "c": c, "rational_restriction": "[1-c]",
                                            "algebraic_conditions_checked": True}, [parity]))
    else:
        report["ring_binding"] = {"status": "supersingular", "full_geometric_ring": "quaternion_order"}
    primes = tuple(degree for degree in (2, 3, 5, 7, 11, 13) if degree <= degree_bound)
    isogenies, coverage = rational_self_isogenies(curve, points, primes, max_kernels=max_kernels, seconds=seconds)
    candidates.extend(isogenies)
    # Respect the geometric degree bound in output and subsequent benchmarking.
    candidates = [candidate for candidate in candidates if candidate.degree <= degree_bound]
    for candidate in candidates:
        verify_map(curve, points, prime, generator, candidate)
    # A constructed prime-degree endomorphism is globally non-scalar because
    # integer multiplication has square degree. Its norm can exclude conductors
    # even when the chosen subgroup does not determine its trace uniquely.
    if report["ordinary"] and full_ring is None:
        degree_evidence = [candidate for candidate in candidates
                           if candidate.family == 'rational_velu_self_isogeny']
        compatible = []
        for discriminant in report["ring_binding"]["candidate_discriminants_before_map_search"]:
            consistent = True
            for candidate in degree_evidence:
                result = scan_order(discriminant, candidate.degree)
                if result['norm_search']['status'] == 'complete' and not any(
                        item['degree'] == candidate.degree for item in result['norm_search']['candidates']):
                    consistent = False
                    break
            if consistent:
                compatible.append(discriminant)
        report["ring_binding"]["candidate_discriminants_after_map_search"] = compatible
        report["ring_binding"]["degree_evidence"] = [{'map_id': candidate.identifier, 'degree': candidate.degree}
                                                   for candidate in degree_evidence]
        if not compatible:
            raise ArithmeticError('constructed maps contradict every candidate ordinary endomorphism order')
        if len(compatible) == 1:
            full_ring = compatible[0]
            report["ring_binding"].update(status='certified_by_exact_elementary_conditions',
                                           full_ring_discriminant=full_ring,
                                           reason='non_scalar_map_degrees_exclude_other_candidate_conductors')
            report["order_search"] = scan_order(full_ring, degree_bound)
            report["order_search"]["curve_binding"] = report["ring_binding"]
    report["explicit_map_search"] = {"coverage": coverage, "maps_constructed_and_verified": len(candidates),
                                     "maps": [candidate.record() for candidate in candidates]}
    values = [candidate.lambda_value for candidate in candidates if candidate.lambda_value is not None]
    report["rho_structural"] = subgroup_symmetries(values, prime)
    report["index_calculus"] = {"status": "unresolved", "relation_model": None, "verified_independent_relations": None,
                                 "total_cost_per_relation": None}
    return report, candidates, prime, generator
