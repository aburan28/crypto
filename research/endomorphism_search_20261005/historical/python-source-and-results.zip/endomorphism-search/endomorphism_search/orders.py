"""Integer-exact enumeration in an imaginary quadratic order.

If D < 0 is 0 or 1 modulo 4, O_D = Z[omega], where
omega = (s + sqrt(D))/2 and s = D mod 2.  For alpha = a + b*omega:
  trace(alpha) = 2*a + s*b
  norm(alpha)  = a*a + s*a*b + (s*s-D)*b*b/4
               = (trace(alpha)**2 + abs(D)*b*b)/4.

Completeness is bounded by degree, work and output limits. The order calculation
does not by itself certify that a particular curve has this full ring.
"""

from dataclasses import asdict, dataclass
from math import gcd, isqrt
from time import perf_counter


SCHEMA = "endomorphism-search/v1"


def require_discriminant(discriminant: int) -> int:
    if isinstance(discriminant, bool) or not isinstance(discriminant, int):
        raise ValueError("discriminant must be an integer")
    if discriminant >= 0 or discriminant % 4 not in (0, 1):
        raise ValueError("a quadratic-order discriminant must be negative and 0 or 1 modulo 4")
    return discriminant


def factor_small(number: int, max_trials: int = 1_000_000) -> dict[int, int]:
    """Exact trial division with a strict budget; never assume an unfactored cofactor is prime."""
    if number < 1:
        raise ValueError("factorization input must be positive")
    factors: dict[int, int] = {}
    divisor, trials = 2, 0
    while divisor * divisor <= number:
        if trials >= max_trials:
            raise ValueError("factorization budget exceeded")
        trials += 1
        while number % divisor == 0:
            factors[divisor] = factors.get(divisor, 0) + 1
            number //= divisor
        divisor = 3 if divisor == 2 else divisor + 2
    if number > 1:
        factors[number] = factors.get(number, 0) + 1
    return factors


def is_prime_small(number: int) -> bool:
    if number < 2:
        return False
    return factor_small(number) == {number: 1}


def fundamental_decomposition(discriminant: int) -> tuple[int, int]:
    """Return (D_K, conductor) with D = conductor^2 * D_K, exactly."""
    require_discriminant(discriminant)
    squarefree = -1
    for prime, exponent in factor_small(-discriminant).items():
        if exponent % 2:
            squarefree *= prime
    fundamental = squarefree if squarefree % 4 == 1 else 4 * squarefree
    ratio = discriminant // fundamental
    conductor = isqrt(ratio)
    if conductor * conductor * fundamental != discriminant:
        raise ValueError("invalid discriminant decomposition")
    return fundamental, conductor


@dataclass(frozen=True)
class Element:
    a: int
    b: int
    degree: int
    trace: int

    def record(self) -> dict:
        result = asdict(self)
        result["characteristic_polynomial_coefficients"] = [1, -self.trace, self.degree]
        result["geometrically_non_scalar"] = self.b != 0
        result["map_status"] = "abstract_ring_element"
        return result


@dataclass(frozen=True)
class QuadraticOrder:
    discriminant: int

    def __post_init__(self) -> None:
        require_discriminant(self.discriminant)

    @property
    def parity(self) -> int:
        return self.discriminant % 2

    def norm(self, a: int, b: int) -> int:
        s, d = self.parity, self.discriminant
        return a * a + s * a * b + ((s * s - d) // 4) * b * b

    def element(self, a: int, b: int) -> Element:
        return Element(a, b, self.norm(a, b), 2 * a + self.parity * b)

    def minimum_non_scalar_degree(self) -> int:
        # b != 0. For |b|=1 minimize trace with the required parity;
        # |b|>=2 gives norm >= abs(D), so it cannot improve this minimum.
        return (-self.discriminant + 3) // 4

    def enumerate(
        self,
        degree_bound: int,
        *,
        non_scalar_only: bool = True,
        max_work: int = 1_000_000,
        max_candidates: int = 100_000,
        seconds: float = 10.0,
    ) -> dict:
        if degree_bound < 1 or max_work < 1 or max_candidates < 1 or seconds <= 0:
            raise ValueError("degree and resource bounds must be positive")
        start = perf_counter()
        elements: list[Element] = []
        work = 0
        stop = None
        b_bound = isqrt((4 * degree_bound) // -self.discriminant)
        for b in range(-b_bound, b_bound + 1):
            if work >= max_work:
                stop = "work_limit"
                break
            if perf_counter() - start >= seconds:
                stop = "time_limit"
                break
            # Count skipped b=0 as work, too: even huge empty scans remain bounded.
            if non_scalar_only and b == 0:
                work += 1
                continue
            trace_bound = isqrt(4 * degree_bound + self.discriminant * b * b)
            first_trace = -trace_bound
            if (first_trace - self.parity * b) % 2:
                first_trace += 1
            for trace in range(first_trace, trace_bound + 1, 2):
                if work >= max_work:
                    stop = "work_limit"
                    break
                if perf_counter() - start >= seconds:
                    stop = "time_limit"
                    break
                work += 1
                a = (trace - self.parity * b) // 2
                element = self.element(a, b)
                if element.degree == 0:
                    continue
                if len(elements) >= max_candidates:
                    stop = "candidate_limit"
                    break
                elements.append(element)
            if stop:
                break
        elements.sort(key=lambda item: (item.degree, item.trace, item.a, item.b))
        return {
            "status": "complete" if stop is None else "incomplete",
            "stop_reason": stop,
            "degree_bound": degree_bound,
            "limits": {"max_work": max_work, "max_candidates": max_candidates, "seconds": seconds},
            "non_scalar_only": non_scalar_only,
            "signs_and_conjugates": "both_retained",
            "b_bound": b_bound,
            "work_used": work,
            "elapsed_seconds": perf_counter() - start,
            "candidate_count": len(elements),
            "candidates": [item.record() for item in elements],
            "completeness_certificate": {
                "identity": "4*N=(2*a+s*b)^2+abs(D)*b^2",
                "constraints": "abs(b)<=floor(sqrt(4*bound/abs(D))); abs(trace)<=floor(sqrt(4*bound-abs(D)*b^2)); trace=s*b mod 2",
                "enumeration_complete": stop is None,
            },
        }


def reduced_forms(discriminant: int, *, max_work: int = 1_000_000) -> dict:
    """Primitive reduced positive binary forms; their count is the proper class number."""
    require_discriminant(discriminant)
    forms = []
    work = 0
    for a in range(1, isqrt((-discriminant) // 3) + 1):
        first_b = -a + ((discriminant - a) % 2)
        for b in range(first_b, a + 1, 2):
            if work >= max_work:
                return {"status": "incomplete", "class_number": None, "forms": forms, "work_used": work}
            work += 1
            numerator = b * b - discriminant
            if numerator % (4 * a):
                continue
            c = numerator // (4 * a)
            if a > c or gcd(gcd(a, abs(b)), c) != 1:
                continue
            if (abs(b) == a or a == c) and b < 0:
                continue
            forms.append({"a": a, "b": b, "c": c})
    return {"status": "complete", "class_number": len(forms), "forms": forms, "work_used": work}


def scan_order(discriminant: int, degree_bound: int = 1000, **budgets) -> dict:
    order = QuadraticOrder(discriminant)
    search = order.enumerate(degree_bound, **budgets)
    units = order.enumerate(1, non_scalar_only=False)
    classes = reduced_forms(discriminant, max_work=budgets.get("max_work", 1_000_000))
    minimum = order.minimum_non_scalar_degree()
    result = {
        "schema": SCHEMA,
        "input": {"discriminant": discriminant, "degree_bound": degree_bound},
        "curve_binding": {"status": "not_bound_to_a_curve", "exclusions": "exact_for_O_D; conditional_for_any_named_curve"},
        "order": {
            "basis": {"omega": "(s+sqrt(D))/2", "s": order.parity},
            "norm_coefficients": [1, order.parity, (order.parity**2 - discriminant) // 4],
            "minimum_non_scalar_degree": minimum,
            "minimum_degree_witness": order.element(0, 1).record(),
            "minimum_degree_proof": "b!=0; minimize trace at |b|=1; |b|>=2 gives N>=abs(D)",
            "geometric_units": units["candidates"],
            "geometric_unit_count": units["candidate_count"],
            "class_forms": classes,
            "ideal_classes_are_not_self_endomorphisms": True,
        },
        "norm_search": search,
        "decision_tree": {
            "scalar_multiplication": {
                "status": "abstract_candidates" if search["candidate_count"] else "no_candidates_within_bound",
                "map_construction": "unresolved",
                "benchmark": "unresolved",
                "next": "construct a map, establish subgroup action, verify decomposition, measure complete multiplication",
            },
            "rho": {
                "extra_geometric_automorphisms": "present" if units["candidate_count"] > 2 else "excluded_for_this_order",
                "small_subgroup_orbits_from_other_maps": "unresolved",
                "measured_speedup": "unresolved",
            },
            "index_calculus": {
                "status": "unresolved",
                "missing_evidence": ["verified relation model", "compatible factor base and phases", "independent verified relations", "complete paired cost measurement"],
            },
        },
    }
    # If enumeration was cut short, a zero count cannot claim bounded absence.
    if search["status"] != "complete":
        result["decision_tree"]["scalar_multiplication"]["status"] = "search_incomplete"
    return result
