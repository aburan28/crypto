"""Matched, variable-base scalar arithmetic experiments in the bounded laboratory."""

import os
import platform
from pathlib import Path
from random import Random
from statistics import median
from time import perf_counter, perf_counter_ns

from .curves import Curve, MapCandidate, Point, subgroup_action_order


def nearest_ratio(numerator: int, denominator: int) -> int:
    if denominator == 0:
        raise ValueError("zero denominator")
    if denominator < 0:
        numerator, denominator = -numerator, -denominator
    sign = -1 if numerator < 0 else 1
    quotient, remainder = divmod(abs(numerator), denominator)
    return sign * (quotient + (2*remainder >= denominator))


def dot(left, right):
    return left[0]*right[0] + left[1]*right[1]


def reduced_lattice(order: int, eigenvalue: int) -> tuple[tuple[int, int], tuple[int, int]]:
    """Exact two-dimensional Gauss reduction of x + lambda*y = 0 mod n."""
    if order < 2:
        raise ValueError("subgroup order must be at least two")
    u, v = (order, 0), (-eigenvalue % order, 1)
    for _ in range(1000):
        if dot(v, v) < dot(u, u):
            u, v = v, u
        # Including equality avoids oscillations on hexagonal half-integer ties.
        if 2*abs(dot(u, v)) <= dot(u, u):
            break
        quotient = nearest_ratio(dot(u, v), dot(u, u))
        v = v[0]-quotient*u[0], v[1]-quotient*u[1]
    else:
        raise ArithmeticError("Gauss reduction did not converge")
    determinant = u[0]*v[1]-u[1]*v[0]
    if abs(determinant) != order or any((x+eigenvalue*y) % order for x, y in (u, v)):
        raise ArithmeticError("invalid decomposition lattice")
    return u, v


def split_scalar(scalar: int, order: int, eigenvalue: int, lattice=None) -> tuple[int, int]:
    scalar %= order
    u, v = lattice if lattice is not None else reduced_lattice(order, eigenvalue)
    determinant = u[0]*v[1]-u[1]*v[0]
    first = nearest_ratio(scalar*v[1], determinant)
    second = nearest_ratio(-scalar*u[1], determinant)
    choices = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            x = scalar-(first+dx)*u[0]-(second+dy)*v[0]
            y = -(first+dx)*u[1]-(second+dy)*v[1]
            choices.append((x, y))
    x, y = min(choices, key=lambda item: (max(abs(item[0]), abs(item[1])), abs(item[0])+abs(item[1]), item))
    if (x+eigenvalue*y-scalar) % order:
        raise ArithmeticError("scalar decomposition congruence failed")
    return x, y


def joint_multiply(curve: Curve, first: int, p: Point, second: int, q: Point) -> Point:
    if first < 0:
        first, p = -first, curve.neg(p)
    if second < 0:
        second, q = -second, curve.neg(q)
    table = [None, q, p, curve.add(p, q)]
    result = None
    for index in range(max(first.bit_length(), second.bit_length())-1, -1, -1):
        result = curve.add(result, result)
        digit = 2*((first >> index) & 1) + ((second >> index) & 1)
        if digit:
            result = curve.add(result, table[digit])
    return result


def accelerated_multiply(curve, scalar, point, candidate, order, lattice):
    first, second = split_scalar(scalar, order, candidate.lambda_value, lattice)
    # Both map evaluation and joint precomputation are inside the timed call.
    image = candidate.evaluate(point)
    return joint_multiply(curve, first, point, second, image)


def hardware_record() -> dict:
    cpu = "unknown"
    try:
        for line in Path('/proc/cpuinfo').read_text().splitlines():
            if line.lower().startswith('model name'):
                cpu = line.split(':', 1)[1].strip()
                break
    except OSError:
        pass
    affinity = sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None
    numa = []
    if affinity:
        numa = [path.name for path in Path(f'/sys/devices/system/cpu/cpu{affinity[0]}').glob('node[0-9]*')]
    return {"os": platform.platform(), "python": platform.python_version(), "cpu": cpu,
            "cpu_affinity": affinity, "cpu_numa_nodes": numa,
            "numa_memory_policy": "not_controlled_by_this_process", "memory_generation": "not_detected",
            "gpu": "not_used", "timer": "perf_counter_ns"}


def bootstrap_interval(values: list[float], seed=903, draws=2000) -> list[float]:
    rng = Random(seed)
    medians = sorted(median([rng.choice(values) for _ in values]) for _ in range(draws))
    return [medians[int(.025*(draws-1))], medians[int(.975*(draws-1))]]


def benchmark_maps(curve: Curve, candidates: list[MapCandidate], order: int, generator: Point,
                   *, samples=128, repeats=7, seed=812, pin_core=True) -> dict:
    if samples < 8 or repeats < 3:
        raise ValueError("benchmark requires at least eight scalars and three repeats")
    old_affinity = None
    if pin_core and hasattr(os, 'sched_getaffinity'):
        old_affinity = os.sched_getaffinity(0)
        try:
            os.sched_setaffinity(0, {min(old_affinity)})
        except OSError:
            old_affinity = None
    try:
        hardware = hardware_record()
        hardware['single_core_pinning_applied'] = old_affinity is not None
        rng = Random(seed)
        scalars = [rng.randrange(1, order) for _ in range(samples)]
        arms = {
            "binary": lambda scalar: curve.mul(scalar, generator),
            "wnaf3": lambda scalar: curve.wnaf_mul(scalar, generator, 3),
            "wnaf4": lambda scalar: curve.wnaf_mul(scalar, generator, 4),
        }
        expected = [curve.mul(scalar, generator) for scalar in range(order)]
        setup, records = {}, []
        for candidate in candidates:
            record = candidate.record()
            value = candidate.lambda_value
            if value is None or value in (0, 1, order-1):
                record['scalar_benchmark'] = {"status": "trivial_or_annihilating_subgroup_action"}
                records.append(record)
                continue
            start = perf_counter_ns()
            lattice = reduced_lattice(order, value)
            setup[candidate.identifier] = perf_counter_ns()-start
            operation = lambda scalar, candidate=candidate, lattice=lattice: accelerated_multiply(
                curve, scalar, generator, candidate, order, lattice)
            maximum = [0, 0]
            for scalar in range(order):
                first, second = split_scalar(scalar, order, value, lattice)
                maximum = [max(maximum[0], abs(first)), max(maximum[1], abs(second))]
                if operation(scalar) != expected[scalar]:
                    raise ArithmeticError(f"accelerated multiplication failed for {candidate.identifier}, k={scalar}")
            record['scalar_benchmark'] = {"status": "pending", "lattice": lattice,
                                         "exhaustive_scalar_checks": order, "maximum_absolute_components": maximum,
                                         "maximum_component_bits": max(item.bit_length() for item in maximum),
                                         "subgroup_action_order": subgroup_action_order(value, order)}
            records.append(record)
            arms[candidate.identifier] = operation
        # Validate every baseline over the same full scalar range.
        for name in ('wnaf3', 'wnaf4'):
            if any(arms[name](scalar) != expected[scalar] for scalar in range(order)):
                raise ArithmeticError(f"baseline verification failed: {name}")
        timings = {name: [] for name in arms}
        for operation in arms.values():
            for scalar in scalars[:8]:
                operation(scalar)
        for _ in range(repeats):
            names = list(arms)
            rng.shuffle(names)
            for name in names:
                start = perf_counter_ns()
                for scalar in scalars:
                    arms[name](scalar)
                timings[name].append(perf_counter_ns()-start)
        baseline = min(('binary', 'wnaf3', 'wnaf4'), key=lambda name: median(timings[name]))
        for record in records:
            name = record['map_id']
            if name not in timings:
                continue
            # Charge one lattice setup per sample-sized batch, conservatively.
            candidate_times = [elapsed+setup[name] for elapsed in timings[name]]
            ratios = [base/candidate for base, candidate in zip(timings[baseline], candidate_times)]
            interval = bootstrap_interval(ratios)
            record['scalar_benchmark'].update({
                "status": "measured_gain_on_this_workload" if interval[0] > 1 else "no_clear_gain_on_this_workload",
                "baseline": baseline, "baseline_median_ns_per_multiply": median(timings[baseline])/samples,
                "candidate_median_ns_per_multiply_including_amortized_setup": median(candidate_times)/samples,
                "paired_median_speedup": median(ratios), "bootstrap_interval_95pct": interval,
                "lattice_setup_ns": setup[name], "amortization_operations": samples,
                "raw_candidate_batch_ns": timings[name],
            })
        return {"hardware": hardware, "workload": {"samples_per_repeat": samples, "repeats": repeats, "seed": seed,
                 "base_points": 1, "precomputation": "per_call_for_every_arm", "variable_time_laboratory_code": True,
                 "constant_time_claim": False, "included_online_costs": ["decomposition", "map", "joint precomputation", "group arithmetic"],
                 "construction_and_verification": "separately_recorded_search_setup; not_online_multiplication_cost"},
                "baseline_candidates": {name: {"median_ns_per_multiply": median(timings[name])/samples, "raw_batch_ns": timings[name]}
                                        for name in ('binary', 'wnaf3', 'wnaf4')},
                "fastest_tested_baseline": baseline, "maps": records,
                "interpretation": "small-field workload only; bootstrap interval does not cover systematic benchmark bias"}
    finally:
        if old_affinity is not None:
            os.sched_setaffinity(0, old_affinity)
