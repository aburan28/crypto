"""The command line is also a reproducible experiment driver."""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

from .benchmarks import benchmark_maps
from .curves import Curve, probe_curve
from .orders import SCHEMA, scan_order


def write_result(result, destination=None):
    text = json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + '\n'
    if destination:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text)
        print(destination)
    else:
        print(text, end='')


def run_curve(curve, *, degree_bound=1000, benchmark=False, samples=128, repeats=7, max_kernels=32, seconds=5.0):
    start = perf_counter()
    result, maps, order, generator = probe_curve(curve, degree_bound, max_kernels=max_kernels, seconds=seconds)
    result['search_and_verification_seconds'] = perf_counter()-start
    if benchmark:
        result['scalar_benchmarks'] = benchmark_maps(curve, maps, order, generator, samples=samples, repeats=repeats)
    result['decision_tree'] = assess_curve(result)
    return result


def assess_curve(result):
    """Translate actual evidence into tree leaves without promoting missing data."""
    maps = result['explicit_map_search']['maps']
    scalar = {'status': 'verified_map_candidates' if maps else 'no_match_in_declared_map_families',
              'verified_map_count': len(maps), 'measured_gain_scope': None}
    if 'scalar_benchmarks' in result:
        gains = [item['map_id'] for item in result['scalar_benchmarks']['maps']
                 if item['scalar_benchmark']['status'] == 'measured_gain_on_this_workload']
        scalar.update(status='pilot_gain_candidates' if gains else 'no_clear_gain_on_tested_workload',
                      pilot_map_ids=gains, measured_gain_scope='recorded small-field workload only',
                      independent_confirmation='pending')
    units = result.get('order_search', {}).get('order', {}).get('geometric_unit_count')
    return {'ring_binding': result['ring_binding']['status'], 'scalar_multiplication': scalar,
            'rho': {'extra_geometric_units': 'unresolved' if units is None else ('present' if units > 2 else 'excluded_for_certified_ring'),
                    'distinct_subgroup_actions': result['rho_structural']['distinct_action_count_including_negation'],
                    'cheap_orbit_handling': 'unresolved', 'measured_gain': 'unresolved'},
            'index_calculus': dict(result['index_calculus'])}


def scan_summary(result):
    order = result['order']
    return {'discriminant': result['input']['discriminant'],
            'minimum_non_scalar_degree': order['minimum_non_scalar_degree'],
            'geometric_unit_count': order['geometric_unit_count'],
            'class_number': order['class_forms']['class_number'],
            'abstract_candidate_count': result['norm_search']['candidate_count'],
            'norm_search_status': result['norm_search']['status'],
            'has_extra_geometric_units': order['geometric_unit_count'] > 2,
            'curve_binding': 'not_bound_to_a_curve', 'measured_speedup': None}


def demo(destination, samples=128, repeats=7):
    started = perf_counter()
    orders = [scan_order(d, 1000) for d in (-3, -4, -7, -8, -11, -19, -43, -67, -163, -619)]
    # Both declared rings and actual curve instances are retained. The -619 toy
    # has a fundamental Frobenius discriminant, so its full ring is forced.
    curves = [("j0", Curve(4093, 0, 2)), ("j1728", Curve(16381, 2, 0)),
              ("cm_minus_7", cm_j_curve(109, -3375)), ("cm_minus_619", Curve(167, 25, 36))]
    results = []
    for label, curve in curves:
        print(f'Inspecting {label}: {curve.record()["curve_id"]}', file=sys.stderr, flush=True)
        record = run_curve(curve, benchmark=True, samples=samples, repeats=repeats)
        record['example_name'] = label
        results.append(record)
    report = {'schema': SCHEMA, 'generated_utc': datetime.now(timezone.utc).isoformat(),
              'orders': orders, 'order_summary': [scan_summary(item) for item in orders],
              'curves': results, 'elapsed_seconds': perf_counter()-started,
              'scope': 'declared quadratic orders and bounded small-prime-field arithmetic; measured results retain their workload scope'}
    write_result(report, destination)
    return report


def cm_j_curve(prime, j_value):
    j_value %= prime
    denominator = (1728-j_value) % prime
    if not denominator or not j_value:
        raise ValueError('use the dedicated model for j=0 or j=1728')
    ratio = j_value*pow(denominator, -1, prime) % prime
    return Curve(prime, 3*ratio, 2*ratio)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Search exact ring candidates and explicit small-curve maps.')
    commands = parser.add_subparsers(dest='command', required=True)
    scan = commands.add_parser('scan', help='enumerate norm-bounded elements of a declared quadratic order')
    scan.add_argument('--discriminant', type=int, required=True)
    scan.add_argument('--degree-bound', type=int, default=1000)
    scan.add_argument('--max-work', type=int, default=1_000_000)
    scan.add_argument('--max-candidates', type=int, default=100_000)
    scan.add_argument('--seconds', type=float, default=10.0)
    scan.add_argument('--out')
    sweep = commands.add_parser('sweep', help='inspect valid quadratic orders in a bounded discriminant range')
    sweep.add_argument('--max-abs-discriminant', type=int, default=1000)
    sweep.add_argument('--degree-bound', type=int, default=1000)
    sweep.add_argument('--max-work', type=int, default=100_000)
    sweep.add_argument('--seconds', type=float, default=30.0)
    sweep.add_argument('--max-orders', type=int, default=5000)
    sweep.add_argument('--out')
    probe = commands.add_parser('probe', help='find and verify explicit maps on a small prime-field curve')
    probe.add_argument('--p', type=int, required=True)
    probe.add_argument('--a', type=int, required=True)
    probe.add_argument('--b', type=int, required=True)
    probe.add_argument('--degree-bound', type=int, default=1000)
    probe.add_argument('--max-kernels', type=int, default=32)
    probe.add_argument('--seconds', type=float, default=5.0)
    probe.add_argument('--benchmark', action='store_true')
    probe.add_argument('--samples', type=int, default=128)
    probe.add_argument('--repeats', type=int, default=7)
    probe.add_argument('--out')
    pilot = commands.add_parser('demo', help='run ring searches and actual map/scalar experiments on four fixed laboratory curves')
    pilot.add_argument('--samples', type=int, default=128)
    pilot.add_argument('--repeats', type=int, default=7)
    pilot.add_argument('--out', default='results/demo.json')
    args = parser.parse_args(argv)
    try:
        if args.command == 'scan':
            write_result(scan_order(args.discriminant, args.degree_bound, max_work=args.max_work,
                                    max_candidates=args.max_candidates, seconds=args.seconds), args.out)
        elif args.command == 'sweep':
            if not 3 <= args.max_abs_discriminant <= 100_000:
                raise ValueError('discriminant range must end between 3 and 100000')
            if args.seconds <= 0 or args.max_orders < 1:
                raise ValueError('sweep resource bounds must be positive')
            rows = []
            start = perf_counter()
            stop = None
            for size in range(3, args.max_abs_discriminant+1):
                d = -size
                if d % 4 in (0, 1):
                    remaining = args.seconds-(perf_counter()-start)
                    if remaining <= 0 or len(rows) >= args.max_orders:
                        stop = 'time_limit' if remaining <= 0 else 'order_limit'
                        break
                    rows.append(scan_summary(scan_order(d, args.degree_bound, max_work=args.max_work,
                                                       seconds=min(2.0, remaining))))
            write_result({'schema': SCHEMA, 'discriminant_bound': args.max_abs_discriminant,
                          'degree_bound': args.degree_bound, 'orders_scanned': len(rows),
                          'rows': rows, 'status': 'incomplete_range' if stop else 'complete_range_with_per_order_coverage',
                          'stop_reason': stop, 'elapsed_seconds': perf_counter()-start,
                          'limits': {'seconds': args.seconds, 'max_orders': args.max_orders}}, args.out)
        elif args.command == 'probe':
            write_result(run_curve(Curve(args.p, args.a, args.b), degree_bound=args.degree_bound,
                                   benchmark=args.benchmark, samples=args.samples, repeats=args.repeats,
                                   max_kernels=args.max_kernels, seconds=args.seconds), args.out)
        else:
            demo(args.out, args.samples, args.repeats)
    except (ValueError, ArithmeticError) as error:
        parser.error(str(error))
    return 0
