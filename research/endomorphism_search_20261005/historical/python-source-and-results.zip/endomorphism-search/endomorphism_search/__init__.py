"""Structural endomorphism searches; no third-party key material is needed."""

__version__ = "0.1.0"
