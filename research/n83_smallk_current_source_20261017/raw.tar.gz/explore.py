#!/usr/bin/env python3
"""Bounded sequential K1248/K1280 current-source exposed-point controls."""
import hashlib
import importlib.util
import json
import subprocess
import time
from pathlib import Path

ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')
HERE = Path('/Volumes/SSD990/crypto/artifacts/n83_smallk_current_source_20261017')
BINARY = Path('/private/tmp/n83-k3072-current-source-20261017/target/release/examples/koblitz_orbit_dlp_fast')
SOURCE_SHA256 = '8a2fe55dd90dc33892c197d27260182bf783fc8212fb485d8297daf2bbba8e12'
BINARY_SHA256 = 'd71a9662c9d4e2dde58443bfc646a05737c6b9ca6b3d5e831b632ce09384c906'
KS = (1248, 1280)

spec = importlib.util.spec_from_file_location('finegrid', ROOT / 'research/n83_e2e_finegrid_20261016/run.py')
finegrid = importlib.util.module_from_spec(spec)
spec.loader.exec_module(finegrid)


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def main():
    hashes = finegrid.frozen_inputs()
    source = ROOT / 'examples/koblitz_orbit_dlp_fast.rs'
    target = finegrid.cold.TARGETS
    if digest(source) != SOURCE_SHA256 or digest(BINARY) != BINARY_SHA256:
        raise ValueError('current source or binary differs')
    if (HERE / 'runs').exists():
        raise ValueError('immutable small-base run folder exists')
    (HERE / 'runs').mkdir(parents=True)
    for k in KS:
        folder = HERE / 'runs' / f'k{k}root11'
        folder.mkdir()
        command = [str(BINARY), f'construct:83:1:{k}', str(target), '29', str(folder / 'targets_result.jsonl')]
        env = finegrid.dynamic.environment(folder, 'root11_dynamic')
        started = time.monotonic()
        status = 'PASS_PRODUCER'
        try:
            result = subprocess.run(command, env=env, capture_output=True, timeout=600, check=False)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
            if code != 0:
                status = 'PRODUCER_FAILED'
        except subprocess.TimeoutExpired as error:
            status = 'TIMEOUT_600_SECONDS'
            code = None
            stdout, stderr = error.stdout or b'', error.stderr or b''
        (folder / 'stdout.jsonl').write_bytes(stdout)
        (folder / 'stderr.txt').write_bytes(stderr)
        receipt = {
            'schema': 'n83.smallk-current-source-exploratory/v1', 'k': k,
            'status': status, 'exit_code': code, 'wall_seconds': time.monotonic() - started,
            'source_sha256': digest(source), 'binary_sha256': digest(BINARY),
            'target_sha256': digest(target), 'frozen_input_hashes': hashes,
            'command': command,
            'environment_flags': {key: value for key, value in env.items() if key.startswith('KIC_')},
            'stdout_sha256': digest(folder / 'stdout.jsonl'),
            'stderr_sha256': digest(folder / 'stderr.txt'),
        }
        (HERE / f'receipt_K{k}.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
        print(json.dumps({key: receipt[key] for key in ('k', 'status', 'exit_code', 'wall_seconds')}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
