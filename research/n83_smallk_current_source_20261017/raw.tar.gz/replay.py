#!/usr/bin/env python3
"""Replay both small bases, four-point relations, scalar and IC1 identities."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path

ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')
HERE = Path('/Volumes/SSD990/crypto/artifacts/n83_smallk_current_source_20261017')
SOURCE_COMMIT = '416489e09c3d8885b6c12f262935e6ba29373460'
SOURCE_SHA256 = '8a2fe55dd90dc33892c197d27260182bf783fc8212fb485d8297daf2bbba8e12'
BINARY_SHA256 = 'd71a9662c9d4e2dde58443bfc646a05737c6b9ca6b3d5e831b632ce09384c906'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


finegrid = module('n83_smallk_finegrid', ROOT / 'research/n83_e2e_finegrid_20261016/materialize.py')
verifier = module('n83_smallk_group', ROOT / 'research/n83_root11_dynamic_20261016/verify.py')
group = verifier.group


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def replay(k, frozen, point, scalar, field, curve):
    folder = HERE / 'runs' / f'k{k}root11'
    receipt = json.loads((HERE / f'receipt_K{k}.json').read_text())
    summary = json.loads((folder / 'stdout.jsonl').read_text())
    target = json.loads((folder / 'targets_result.jsonl').read_text())
    expected_flags = {key: value for key, value in
                      finegrid.runner.dynamic.environment(folder, 'root11_dynamic').items()
                      if key.startswith('KIC_')}
    if (digest(ROOT / 'examples/koblitz_orbit_dlp_fast.rs') != SOURCE_SHA256 or
            receipt['k'] != k or receipt['status'] != 'PASS_PRODUCER' or
            receipt['exit_code'] != 0 or receipt['source_sha256'] != SOURCE_SHA256 or
            receipt['binary_sha256'] != BINARY_SHA256 or
            receipt['target_sha256'] != digest(finegrid.runner.cold.TARGETS) or
            receipt['environment_flags'] != expected_flags or
            receipt['stdout_sha256'] != digest(folder / 'stdout.jsonl') or
            receipt['stderr_sha256'] != digest(folder / 'stderr.txt') or
            (folder / 'stderr.txt').read_bytes() or
            summary['n'] != 83 or summary['a'] != 1 or
            summary['rank'] != k or summary['orbit_columns'] != k or
            summary['factor_base_points'] != 166 * k or
            summary['targets_solved'] != 1 or summary['targets_failed'] != 0 or
            target['fixture_index'] != 0 or target['target'] != frozen or
            target['group_verified'] is not True or
            int(target['recovered_scalar']) != scalar or
            group.multiply(group.G, scalar) != point):
        raise ValueError(f'K{k}: source, producer, target or scalar differs')
    base = group.replay_base(json.loads((folder / 'base_dump.jsonl').read_text()), summary)
    indices = target['point_indices']
    if (len(base) != 166 * k or len(indices) != 4 or
            any(not isinstance(i, int) or not 0 <= i < len(base) for i in indices)):
        raise ValueError(f'K{k}: base or witness differs')
    relation = None
    for index in indices:
        relation = group.add(relation, base[index])
    if relation != point:
        raise ValueError(f'K{k}: four-point relation differs')
    keys = ('target_query_ms', 'target_pdp_ms', 'target_relation_check_ms',
            'target_descent_ms', 'target_recovery_check_ms')
    online = float(target['target_ms'])
    phases = [float(target[key]) for key in keys]
    if (not math.isfinite(online) or online <= 0 or
            any(not math.isfinite(value) or value < 0 for value in phases) or
            abs(math.fsum(phases) - online) > 1):
        raise ValueError(f'K{k}: online phase accounting differs')
    candidate = finegrid.dynamic.candidate(k, 'root11_dynamic', summary,
                                            folder / 'base_dump.jsonl', field, curve)
    (HERE / f'candidate_K{k}.json').write_text(json.dumps(candidate, sort_keys=True, indent=2) + '\n')
    result = {
        'schema': 'n83.smallk-current-source-replay/v1',
        'status': 'PASS_INDEPENDENT_ARITHMETIC_REPLAY', 'k': k,
        'source_commit': SOURCE_COMMIT, 'source_sha256': SOURCE_SHA256,
        'binary_sha256': BINARY_SHA256, 'candidate_id': candidate['candidate_id'],
        'base_hash': summary['base_hash'], 'actual_usable_points': len(base),
        'effective_columns': summary['rank'],
        'root_table_entries': summary.get('root_table_entries'),
        'one_target_online_ms': online, 'online_phases_ms': dict(zip(keys, phases)),
        'cold_process_seconds': receipt['wall_seconds'],
        'receipt_sha256': digest(HERE / f'receipt_K{k}.json'),
    }
    (HERE / f'replay_K{k}.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    return result


def main():
    frozen = json.loads(finegrid.runner.cold.TARGETS.read_text())
    answer = json.loads(finegrid.runner.cold.ANSWERS.read_text())
    point = group.point_from_json(frozen)
    scalar = int(answer['scalar'])
    finegrid.panel.SOURCE_COMMIT = SOURCE_COMMIT
    finegrid.panel.SOURCE_SHA256 = SOURCE_SHA256
    field, curve = finegrid.panel.curve_record()
    for k in (1248, 1280):
        print(json.dumps(replay(k, frozen, point, scalar, field, curve), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
