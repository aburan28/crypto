#!/usr/bin/env python3
"""Replay the current-source K2816 factor base, relation, scalar and IC1 identity."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')
HERE = Path('/Volumes/SSD990/crypto/artifacts/n83_k2816_current_source_20261017')
SOURCE_COMMIT = '416489e09c3d8885b6c12f262935e6ba29373460'
SOURCE_SHA256 = '8a2fe55dd90dc33892c197d27260182bf783fc8212fb485d8297daf2bbba8e12'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
finegrid=module('n83_k2816_finegrid',ROOT/'research/n83_e2e_finegrid_20261016/materialize.py')
verifier=module('n83_k2816_group',ROOT/'research/n83_root11_dynamic_20261016/verify.py')
group=verifier.group
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()
def main():
    folder=HERE/'runs/k2816root11'
    receipt=json.loads((HERE/'receipt.json').read_text())
    summary=json.loads((folder/'stdout.jsonl').read_text())
    target=json.loads((folder/'targets_result.jsonl').read_text())
    frozen=json.loads(finegrid.runner.cold.TARGETS.read_text())
    answer=json.loads(finegrid.runner.cold.ANSWERS.read_text())
    point=group.point_from_json(frozen)
    scalar=int(answer['scalar'])
    if (digest(ROOT/'examples/koblitz_orbit_dlp_fast.rs')!=SOURCE_SHA256 or
        receipt['status']!='PASS_PRODUCER' or receipt['exit_code']!=0 or
        receipt['source_sha256']!=SOURCE_SHA256 or
        receipt['target_sha256']!=digest(finegrid.runner.cold.TARGETS) or
        receipt['stdout_sha256']!=digest(folder/'stdout.jsonl') or
        receipt['stderr_sha256']!=digest(folder/'stderr.txt') or
        (folder/'stderr.txt').read_bytes() or
        summary['rank']!=2816 or summary['factor_base_points']!=467456 or
        summary['targets_solved']!=1 or summary['targets_failed']!=0 or
        target['fixture_index']!=0 or target['target']!=frozen or
        int(target['recovered_scalar'])!=scalar or
        group.multiply(group.G,scalar)!=point):
        raise ValueError('source, producer, target or scalar differs')
    base=group.replay_base(json.loads((folder/'base_dump.jsonl').read_text()),summary)
    indices=target['point_indices']
    if len(base)!=467456 or len(indices)!=4 or any(not isinstance(i,int) or not 0<=i<len(base) for i in indices):
        raise ValueError('base or witness differs')
    relation=None
    for index in indices:
        relation=group.add(relation,base[index])
    if relation!=point:
        raise ValueError('four-point relation differs')
    keys=('target_query_ms','target_pdp_ms','target_relation_check_ms','target_descent_ms','target_recovery_check_ms')
    online=float(target['target_ms'])
    phases=[float(target[key]) for key in keys]
    if not math.isfinite(online) or online<=0 or any(not math.isfinite(x) or x<0 for x in phases) or abs(math.fsum(phases)-online)>1:
        raise ValueError('online phase accounting differs')
    finegrid.panel.SOURCE_COMMIT=SOURCE_COMMIT
    finegrid.panel.SOURCE_SHA256=SOURCE_SHA256
    field,curve=finegrid.panel.curve_record()
    candidate=finegrid.dynamic.candidate(2816,'root11_dynamic',summary,folder/'base_dump.jsonl',field,curve)
    (HERE/'candidate.json').write_text(json.dumps(candidate,sort_keys=True,indent=2)+'\n')
    replay={'schema':'n83.k2816-current-source-replay/v1','status':'PASS_INDEPENDENT_ARITHMETIC_REPLAY',
            'source_commit':SOURCE_COMMIT,'source_sha256':SOURCE_SHA256,
            'binary_sha256':receipt['binary_sha256'],'candidate_id':candidate['candidate_id'],
            'base_hash':summary['base_hash'],'actual_usable_points':len(base),
            'effective_columns':summary['rank'],'root_table_entries':summary.get('root_table_entries'),
            'one_target_online_ms':online,'online_phases_ms':dict(zip(keys,phases)),
            'cold_process_seconds':receipt['wall_seconds'],'receipt_sha256':digest(HERE/'receipt.json')}
    (HERE/'replay.json').write_text(json.dumps(replay,sort_keys=True,indent=2)+'\n')
    print(json.dumps(replay,sort_keys=True))
if __name__=='__main__':
    main()
