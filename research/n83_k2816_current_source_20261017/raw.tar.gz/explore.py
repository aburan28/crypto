#!/usr/bin/env python3
"""Bounded K2816 current-source feasibility on one previously exposed point."""
import hashlib
import importlib.util
import json
import subprocess
import time
from pathlib import Path
ROOT = Path('/Volumes/SSD990/crypto/worktrees/n83-k3072-current-source-20261017')
HERE = Path('/Volumes/SSD990/crypto/artifacts/n83_k2816_current_source_20261017')
BINARY = Path('/private/tmp/n83-k3072-current-source-20261017/target/release/examples/koblitz_orbit_dlp_fast')
spec = importlib.util.spec_from_file_location('finegrid', ROOT / 'research/n83_e2e_finegrid_20261016/run.py')
finegrid = importlib.util.module_from_spec(spec)
spec.loader.exec_module(finegrid)
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()
def main():
    hashes = finegrid.frozen_inputs()
    source = ROOT / 'examples/koblitz_orbit_dlp_fast.rs'
    target = finegrid.cold.TARGETS
    folder = HERE / 'runs/k2816root11'
    if folder.exists():
        raise ValueError('immutable exploratory folder exists')
    if digest(source) != '8a2fe55dd90dc33892c197d27260182bf783fc8212fb485d8297daf2bbba8e12':
        raise ValueError('source differs')
    if digest(BINARY) != 'd71a9662c9d4e2dde58443bfc646a05737c6b9ca6b3d5e831b632ce09384c906':
        raise ValueError('binary differs')
    folder.mkdir(parents=True)
    command = [str(BINARY), 'construct:83:1:2816', str(target), '29', str(folder / 'targets_result.jsonl')]
    env = finegrid.dynamic.environment(folder, 'root11_dynamic')
    started = time.monotonic()
    status = 'PASS_PRODUCER'
    try:
        result = subprocess.run(command, env=env, capture_output=True, timeout=1000, check=False)
        code, stdout, stderr = result.returncode, result.stdout, result.stderr
        if code != 0:
            status = 'PRODUCER_FAILED'
    except subprocess.TimeoutExpired as error:
        status = 'TIMEOUT_1000_SECONDS'
        code = None
        stdout, stderr = error.stdout or b'', error.stderr or b''
    (folder / 'stdout.jsonl').write_bytes(stdout)
    (folder / 'stderr.txt').write_bytes(stderr)
    receipt = {'schema': 'n83.k2816-current-source-exploratory/v1', 'status': status,
               'exit_code': code, 'wall_seconds': time.monotonic() - started,
               'source_sha256': digest(source), 'binary_sha256': digest(BINARY),
               'target_sha256': digest(target), 'frozen_input_hashes': hashes,
               'command': command, 'environment_flags': {key: value for key, value in env.items() if key.startswith('KIC_')},
               'stdout_sha256': digest(folder / 'stdout.jsonl'), 'stderr_sha256': digest(folder / 'stderr.txt')}
    (HERE / 'receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'exit_code', 'wall_seconds', 'source_sha256', 'binary_sha256')}, sort_keys=True))
if __name__ == '__main__':
    main()
