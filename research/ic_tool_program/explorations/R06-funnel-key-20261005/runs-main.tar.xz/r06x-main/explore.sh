#!/bin/bash
# R06 exploration on main (995ea207): M1's two rows at the three target sizes, three rounds,
# ABAB, each process isolated on CPU 2 (isorun.sh: isolated_bench run,
# retried while it refuses).  base = main 995ea207, cand = that plus the funnel kernel (878775fc).
set -u
SP=/tmp/claude-0/-home-user-crypto/56047a67-af13-5c18-babc-0bd1175ee451/scratchpad
X=$SP/r06x-main
P=$SP/r02b-run-wt/research/ic_tool_program/suite/v1/params/S
declare -A BIN=([base]=$SP/bin/ic-main-995ea207 [cand]=$SP/bin/ic-r06-cand-on-995ea207-878775fc)
# row id, params dir, rho seed (SUITE.json)
ROWS=("k0n53 M1-T01" "k0n53 M1-T02" "k1n59 M1-T01" "k1n59 M1-T02" "k0n61 M1-T01" "k0n61 M1-T02")
seed_of() { jq -r --arg id "$1-$2" '.rows[] | select(.id == $id) | .rho_seed' $SP/r02b-run-wt/research/ic_tool_program/suite/v1/SUITE.json; }
for round in 1 2 3; do
  for row in "${ROWS[@]}"; do
    set -- $row
    seed=$(seed_of $1 $2)
    for arm in base cand; do
      d=$X/runs/$arm/$1/$2; mkdir -p $d
      [ -s $d/r$round.price.json ] && continue
      RAYON_NUM_THREADS=1 $SP/isorun-r07.sh $d/r$round "$arm/$1/$2/r$round" -- \
        ${BIN[$arm]} price --params $P/$1/$2.json --json --out $d/r$round.price.json --single-target --rho-seed $seed \
        || echo "FAILED $arm $1 $2 r$round"
      echo "$(date -u +%T) r$round $arm $1/$2 setup_ms=$(jq '.median.ic_setup_ms // ([.repetitions[].setup_ns]|sort|.[length/2|floor]/1e6)' $d/r$round.price.json 2>/dev/null) scalar=$(jq -r '.certificates.ic.scalar' $d/r$round.price.json 2>/dev/null)"
    done
  done
done
echo "== exploration done $(date -u)"
