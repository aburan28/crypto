#!/bin/bash
SP=/tmp/claude-0/-home-user-crypto/56047a67-af13-5c18-babc-0bd1175ee451/scratchpad
for s in k0n53 k1n59 k0n61; do
  for f in $SP/keyx/runs/base/$s/*/r*.price.json; do
    jq -r --arg s $s '.repetitions | map({c: (.setup_ns + .ic_online.wall_ns), col: .setup_phases_ns.collect, b: .setup_phases_ns.build}) | sort_by(.c) | .[length/2|floor] | "\($s) \(.c) \(.col) \(.b)"' $f
  done
done | awk '{n[$1]++; c[$1]+=$2; col[$1]+=$3; b[$1]+=$4} END {for (k in n) printf "%s cold_ms=%.0f collect=%.1f%% build=%.1f%%\n", k, c[k]/n[k]/1e6, 100*col[k]/c[k], 100*b[k]/c[k]}' | sort
for s in k0n53 k1n59 k0n61; do f=$(ls $SP/keyx/runs/base/$s/M1-T01/r1.price.json); jq -r --arg s $s '"\($s) summands=\(.counts.pass.collect.summands_scanned) pairs=\(.counts.pass.build.stored_pairs)"' $f; done
