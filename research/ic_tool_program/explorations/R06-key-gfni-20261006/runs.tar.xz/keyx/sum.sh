#!/bin/bash
SP=/tmp/claude-0/-home-user-crypto/56047a67-af13-5c18-babc-0bd1175ee451/scratchpad
echo "size   arm     pairs     cold  sd_log    build  collect"
$SP/keyx/pairs3.sh $SP/keyx/runs key 2>&1
$SP/keyx/pairs3.sh $SP/keyx/runs funnel 2>&1
