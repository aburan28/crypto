#!/bin/bash
# pairs3.sh RUNS_DIR ARM: base over ARM per (row, round), cold / build /
# collection medians over each process's repetitions, geometric mean by
# size.  A pair with a contended process is dropped; a scalar mismatch is
# reported.
R=$1; A=$2
med() { jq "[.repetitions[] | $2] | sort | .[length/2|floor]" $1; }
for b in $(ls $R/base/*/*/r*.price.json); do
  c=${b/\/base\//\/$A\/}
  [ -s $c ] || continue
  ib=${b%.price.json}.isolation.jsonl; ic=${c%.price.json}.isolation.jsonl
  cont=$( (tail -1 $ib; tail -1 $ic) | jq -s 'map(.run.contended) | any')
  [ "$cont" = "true" ] && { echo "skip-contended $c" >&2; continue; }
  [ "$(jq -r '.certificates.ic.scalar' $b)" = "$(jq -r '.certificates.ic.scalar' $c)" ] || echo "SCALAR MISMATCH $c" >&2
  size=$(echo $b | sed 's#.*/base/##; s#/.*##')
  echo "$size $(med $b '(.setup_ns + .ic_online.wall_ns)') $(med $c '(.setup_ns + .ic_online.wall_ns)') $(med $b .setup_phases_ns.build) $(med $c .setup_phases_ns.build) $(med $b .setup_phases_ns.collect) $(med $c .setup_phases_ns.collect)"
done | awk -v arm=$A '{k=$1; n[k]++; cold[k]+=log($2/$3); c2[k]+=log($2/$3)^2; bld[k]+=log($4/$5); col[k]+=log($6/$7)}
  END {for (k in n) {m=cold[k]/n[k]; sd=(n[k]>1)?sqrt((c2[k]-n[k]*m*m)/(n[k]-1)):0; printf "%-6s %-7s %5d %8.3f %7.3f %8.3f %8.3f\n", k, arm, n[k], exp(m), sd, exp(bld[k]/n[k]), exp(col[k]/n[k])}}' | sort
