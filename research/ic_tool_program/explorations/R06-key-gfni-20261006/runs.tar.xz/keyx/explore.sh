#!/bin/bash
# The scan's key on v3: funnel shifts and GFNI (r06-key 34ad98f9), three arms,
# M1's two rows at the three largest sizes, three rounds, the arms' order
# rotating by round, each process isolated on CPU 2 (isorun-r07.sh).
#   base   = main 995ea207 (v3)
#   key    = 995ea207 + funnel (a809324f) + GFNI (34ad98f9)
#   funnel = the key binary with KIC_CANON_COORDS=tables: the funnel alone
set -u
SP=/tmp/claude-0/-home-user-crypto/56047a67-af13-5c18-babc-0bd1175ee451/scratchpad
X=$SP/keyx
P=$SP/r02b-run-wt/research/ic_tool_program/suite/v1/params/S
SUITE=$SP/r02b-run-wt/research/ic_tool_program/suite/v1/SUITE.json
declare -A BIN=([base]=$SP/bin/ic-main-995ea207 [key]=$SP/bin/ic-r06key-on-995ea207-34ad98f9 [funnel]=$SP/bin/ic-r06key-on-995ea207-34ad98f9)
ROWS=("k0n53 M1-T01" "k0n53 M1-T02" "k1n59 M1-T01" "k1n59 M1-T02" "k0n61 M1-T01" "k0n61 M1-T02")
ORDERS=("base key funnel" "key funnel base" "funnel base key")
seed_of() { jq -r --arg id "$1-$2" '.rows[] | select(.id == $id) | .rho_seed' $SUITE; }
for round in 1 2 3; do
  for row in "${ROWS[@]}"; do
    set -- $row
    seed=$(seed_of $1 $2)
    for arm in ${ORDERS[$((round - 1))]}; do
      d=$X/runs/$arm/$1/$2; mkdir -p $d
      [ -s $d/r$round.price.json ] && continue
      if [ $arm = funnel ]; then export KIC_CANON_COORDS=tables; else unset KIC_CANON_COORDS; fi
      RAYON_NUM_THREADS=1 $SP/isorun-r07.sh $d/r$round "$arm/$1/$2/r$round" -- \
        ${BIN[$arm]} price --params $P/$1/$2.json --json --out $d/r$round.price.json --single-target --rho-seed $seed \
        || echo "FAILED $arm $1 $2 r$round"
      unset KIC_CANON_COORDS
      echo "$(date -u +%T) r$round $arm $1/$2 cold_ms=$(jq '[.repetitions[] | (.setup_ns + .ic_online.wall_ns) / 1e6] | sort | .[length/2|floor]' $d/r$round.price.json 2>/dev/null) collect_ms=$(jq '[.repetitions[].setup_phases_ns.collect/1e6] | sort | .[1]' $d/r$round.price.json 2>/dev/null) scalar=$(jq -r '.certificates.ic.scalar' $d/r$round.price.json 2>/dev/null)"
    done
  done
done
echo "== key exploration done $(date -u)"
