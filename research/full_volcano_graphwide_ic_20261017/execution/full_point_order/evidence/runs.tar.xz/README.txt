Original C: complete selected-point-order diagnostic, not full C class.

Primary prefix: 1,869 models, two public one-target workloads/model, two arms.
Each arm verifies all 3,738 targets: 7,476 method records. Separate full replay
matches every non-clock row, fixture and truth field. Source-only primary and
replay are separate four-record populations. Do not pool them or the older
order-7-only diagnostic with the prefix population.

M is the exact order of each selected point, not a maximality or full-group
cyclicity certificate. All its 2/3/7 prime-power components are retained.
EC PH/BSGS and reduced Tate/Miller + finite-field PH/relation algebra use the
same public input. Scalar truth is outside solver arguments. Field images
have their exact prime-power orders checked. EC verification rejects aliases.
Relations include identity/dependent equations; per-component rank and work
are separate. Small digit groups explain dense yields, not a general oracle.

This is not NFS/integer-smoothness IC, a large-k backend, an ecbench-admitted
speedup, or an independent arithmetic proof. CPU4 wrapper journals accompany
every run; PSI is unavailable and the full-prefix replay is contended. All
clocks remain unqualified and are never pooled with replay observations.
Curve-field inversions, sqrt internals, selected scalar/integer work and
allocation remain unpriced. No combined priced cost or asymptotic claim.

Original C remains 1,934,901,248 vertices / 165 strata. The retained prefix
has only 517 locally exact labels / 24 observed strata, 1,352 unknown labels,
and 1,024 expanded vertices. Original A--E completion, the full method matrix,
transported targets and independent replay remain open. The three additional
complete graph datasets and their ongoing bounded survey are separate.

Linux x86-64 inspection: read prefix/meta.json and derived-prefix/summary.json.
Native replay, fresh output required:
  build-final/full-point run inputs/C.sqlite inputs/C-local-conductors.json /fresh/run prefix
  build-final/full-point compare prefix /fresh/run /fresh/receipt.json
  build-final/full-point-summary /fresh/run /fresh/summary
Source-only mode is 'source'. Every command refuses existing output paths.
Run no builds/tests while measuring. See source-code/PROTOCOL.md and BUILD.sh.
Linked library source is 2bf7700b73b3a84810aa86cb29837d1359b28322; exact binary,
compiler, rlib digests and source snapshots are supplied. Byte-reproducible
compilation is not asserted. All eight final report pages were inspected.

The B cache-eviction receipt concerns only a verified reproducible compressed
local copy. Its full raw 9.3-GB graph and original manifests remain retained;
Drive's prior numbered delivery remains separate. No S3 upload is claimed.
