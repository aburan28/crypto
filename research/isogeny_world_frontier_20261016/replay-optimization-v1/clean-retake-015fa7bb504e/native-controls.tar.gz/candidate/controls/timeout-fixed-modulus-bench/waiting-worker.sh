#!/bin/sh
while test ! -f "$4"; do :; done
while :; do :; done
