from pathlib import Path
import json,hashlib,subprocess,re,tarfile,shutil
repo=Path('/Volumes/SSD990-2/crypto/isogeny-degree-challenge-20261015')
build=Path('/Volumes/SSD990-2/crypto/isogeny-fixed-modulus-builds-20261016')
raw=build/'root-gates-3ce9694';out=repo/'research/isogeny_world_frontier_20261016/replay-optimization-v1/custody-approved-20261016'
assert (raw/'test.exit').read_text().strip()=='101'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==(raw/'source-commit.txt').read_text().strip()
s=(raw/'test.log').read_text()
header=re.search(r'^running (\d+) tests$',s,re.M);assert header
results=list(re.finditer(r'^test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s',s,re.M))
main=[m for m in results if sum(int(m[i]) for i in [1,2,3])==int(header[1]) and m[5]=='0']
assert len(main)==1
m=main[0];assert (int(m[1]),int(m[2]),int(m[3]),int(m[5]))==(4161,1,117,0)
stderr=(raw/'test-os-time.txt').read_text();e=re.search(r'Running unittests src/lib.rs \(([^\n)]+)\)',stderr);assert e
exe=Path(e[1]);exe=exe if exe.is_absolute() else repo/exe
assert exe.is_file()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(raw/'compiler.txt').write_text(subprocess.check_output(['rustc','--version','--verbose'],text=True))
(raw/'host.txt').write_text(subprocess.check_output(['uname','-a'],text=True)+subprocess.check_output(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string'],text=True)+'Isolation: shared host; no isolated wall claim\n')
delta=subprocess.run(['git','diff','--exit-code','HEAD','--','src','Cargo.toml','Cargo.lock','build.rs','.cargo'],cwd=repo,capture_output=True)
assert delta.returncode==0
(raw/'root-code-diff.txt').write_bytes(delta.stdout)
(raw/'root-code-diff.exit').write_text(str(delta.returncode)+'\n')
(raw/'source-tree.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True))
retake=build/'root-sqisign-retake-3ce9694'
assert (retake/'test.exit').read_text().strip()=='0'
assert '14 passed; 0 failed; 0 ignored; 0 measured; 4265 filtered out' in (retake/'test.log').read_text()
retake_exe=json.loads((retake/'executable.json').read_text())
assert sha(exe)==retake_exe['sha256'] and exe.stat().st_size==retake_exe['bytes']
shutil.copytree(retake,raw/'bounded-module-retake')
checks={}
for name,base in [('frozen_native_source','015fa7bb504ef63953e0e04e464bb266f4f207bf'),('main_parent','d22253655de460de5fbf4774959c97d8a03de682')]:
 c=subprocess.run(['git','diff','--exit-code',base,'HEAD','--','src/pqc/sqisign.rs','src/hash/sha3.rs','Cargo.lock'],cwd=repo,capture_output=True)
 checks[name]={'base':base,'paths':['src/pqc/sqisign.rs','src/hash/sha3.rs','Cargo.lock'],'exit_code':c.returncode,'diff':c.stdout.decode()}
sq=repo/'src/pqc/sqisign.rs'
diagnostic={'schema':'isogeny-unrelated-root-validation-diagnostic/v1','full_suite':'FAIL:4161/1/117 ignored;exit101','assertion_observation':{'accepted':27,'trials':4000,'rate':0.00675,'strict_lower_threshold':'1/(37*4)'},'bounded_module_retake':{'passed':14,'failed':0,'ignored':0,'filtered':4265,'exit_code':0,'replaces_full_failure':False},'same_current_executable_sha256':sha(exe),'sqisign_module_sha256':sha(sq),'source_comparisons':checks,'imports':['crate::hash::sha3::shake256','rand::{rngs::OsRng,Rng}','std collections and OnceLock'],'cause':'UNESTABLISHED','full_gate_passed':False,'source_gate_complete':False,'scientific_runs':0}
(raw/'diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n')
shutil.copyfile(__file__,raw/'package-root-gate-command.py')
files=sorted(p for p in raw.rglob('*') if p.is_file())
archive=out/'root-gate-3ce9694.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(raw)),recursive=False)
rows=[{'path':str(p.relative_to(raw)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
with tarfile.open(archive) as t:
 ms=t.getmembers();assert len(ms)==len(rows)
 for a,r in zip(ms,rows):assert a.isfile() and a.name==r['path'] and hashlib.sha256(t.extractfile(a).read()).hexdigest()==r['sha256']
x={'schema':'isogeny-merged-source-root-gate/v1','status':'FAIL','source_commit':(raw/'source-commit.txt').read_text().strip(),'command':(raw/'command.txt').read_text().strip(),'exit_code':101,'passed':int(m[1]),'failed':int(m[2]),'ignored':int(m[3]),'filtered':0,'body_seconds_operational_only':float(m[6]),'started_utc':(raw/'started-utc.txt').read_text().strip(),'ended_utc':(raw/'ended-utc.txt').read_text().strip(),'test_executable':{'path':str(exe),'bytes':exe.stat().st_size,'sha256':sha(exe)},'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'all_member_hashes_replayed':True},'raw_files':rows,'isolation':'shared host','performance_claim':False,'scientific_runs':0,'earlier_root_parallel_failure':'preserved; cause and parallel stability unestablished','diagnostic':diagnostic}
(out/'root-gate.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({k:x[k] for k in ['status','source_commit','passed','failed','ignored','scientific_runs']}))
