#!/bin/sh
set -u
repo=/Volumes/SSD990-2/crypto/isogeny-degree-challenge-20261015
out=/Volumes/SSD990-2/crypto/isogeny-fixed-modulus-builds-20261016/root-gates-3ce9694
cd "$repo" || exit
export CARGO_TARGET_DIR=/Volumes/SSD990-2/crypto/isogeny-fixed-modulus-builds-20261016/root-target
git rev-parse HEAD > "$out/source-commit.txt"
git diff --name-only 37d1d9c2c1d1a5a16cbb663ca0ddfaa030e57d33 HEAD > "$out/merge-changed-paths.txt"
printf '%s\n' 'cargo test --release --locked --offline --lib -- --test-threads=1' > "$out/command.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/started-utc.txt"
/usr/bin/time -l cargo test --release --locked --offline --lib -- --test-threads=1 > "$out/test.log" 2> "$out/test-os-time.txt"
result=$?
printf '%s\n' "$result" > "$out/test.exit"
date -u +%Y-%m-%dT%H:%M:%SZ > "$out/ended-utc.txt"
printf 'Root release library exit: %s\n' "$result"
exit "$result"
